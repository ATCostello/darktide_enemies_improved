local mod = get_mod("enemies_improved")

mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/enemies_improved_localization")

local Managers_player = Managers.player
local Managers_state = Managers.state
local Managers_ui = Managers.ui
local Managers_time = Managers.time
local Managers_world = Managers.world
local ScriptUnit_extension = ScriptUnit.extension
local ScriptUnit_has_extension = ScriptUnit.has_extension
local table_clear = table.clear
local table_remove = table.remove
local table_index_of = table.index_of
local math_lerp = math.lerp
local math_min = math.min
local math_max = math.max
local next = next
local math_floor = math.floor
local Unit_alive = Unit.alive
local Actor_unit = Actor.unit
local World_physics_world = World.physics_world
local Quaternion_forward = Quaternion.forward

-- debug mode toggle!!!
mod.DEBUG = false
if mod.DEBUG then
	dbg_mod = mod

	local MemProfile = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/utils/mem_profile")
	mod.mem_profile = MemProfile

	mod.update = function(dt)
		mod.mem_profile.tick(dt)
		mod.mem_profile.render_gui()
	end
end

mod.detect_alive = function(unit)
	if unit and HEALTH_ALIVE[unit] and Unit_alive(unit) then
		return true
	end
	return false
end

mod._on_ei_marker_created = function(marker_id, entry, unit)
	-- Safety: stale callback (force_remove_unit_markers or remove_dead already cleared pending)
	if not entry or not entry._ei_marker_pending then
		if marker_id then
			Managers.event:trigger("remove_world_marker", marker_id)
		end
		return
	end

	-- Safety: unit already has a tracked marker (duplicate prevention)
	if mod.enemy_markers[unit] then
		entry._ei_marker_pending = nil
		Managers.event:trigger("remove_world_marker", marker_id)
		return
	end

	entry.marker = mod.get_marker_by_id(marker_id)

	mod.enemy_markers[unit] = marker_id
	mod.enemy_healthbars[unit] = marker_id
	mod.enemy_debuffs[unit] = marker_id

	entry._ei_marker_created = true
	entry._ei_marker_pending = nil

	if mod.frame_settings.horde_clusters_enable and entry.is_horde then
		local cluster = mod.get_horde_cluster_for_unit(unit)
		if cluster then
			cluster._healthbar_created = true
			cluster._healthbar_marker_id = marker_id
		end
	end
end

-- ENEMIES IMPROVED FUNCTIONS
local FrameSettings = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/utils/frame_settings")
local SettingsFunctions = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/utils/settings_functions")
local DistanceFade = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/utils/fading")

local Outlines = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/modules/outlines")
local Healthbars = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/modules/healthbars")
local Markers = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/modules/markers")
local Debuffs = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/modules/debuffs")
local BossDebuffs = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/modules/bossdebuffs")

local SpecialAttacks = mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/modules/specialattacks")
local AnimationHandler =
	mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/modules/animations/animationhandler")

local BreedQueries = require("scripts/utilities/breed_queries")
local minion_breeds = BreedQueries.minion_breeds_by_name()
local Recoil = require("scripts/utilities/recoil")
local Sway = require("scripts/utilities/sway")
local HudElementWorldMarkers = require("scripts/ui/hud/elements/world_markers/hud_element_world_markers")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIScenegraph = require("scripts/managers/ui/ui_scenegraph")
local HudElementSmartTagging = require("scripts/ui/hud/elements/smart_tagging/hud_element_smart_tagging")
local Component = require("scripts/utilities/component")
local MechanismManager = require("scripts/managers/mechanism/mechanism_manager")

mod._broadphase_results = {}

mod.enemy_cache = {}
mod.enemy_markers = {}
mod.enemy_healthbars = {}
mod.enemy_debuffs = {}

mod.marked_dead = {}
mod.source_unit_cache = mod.source_unit_cache or {}
mod.enabled = true

local MAX_ENEMIES_PER_FRAME = 100
local _enemy_units_temp = {}
local _last_enemy_index = 0
local _horde_units_all = {}
local _cull_pool = {}
local _cull_pool_count = 0

local _player_pos_vec = Vector3.zero()
local _pos_vec = Vector3.zero()

local _horde_clusters = {}
local _horde_cluster_by_unit = {}

-- Reusable tables for _build_horde_clusters (avoid per-frame allocations)
local _spatial_hash = {}
local _visited = {}
local _z_samples = {}
local _bfs_queue = {}

-- track variables with the memory profiler for growth/leak monitoring
if mod.DEBUG then
	local mem = mod.mem_profile
	mem.track("cluster._horde_clusters", _horde_clusters)
	mem.track("cluster._horde_cluster_by_unit", _horde_cluster_by_unit)
	mem.track("cluster._cull_pool", _cull_pool)
	mem.track("cluster._spatial_hash", _spatial_hash)
	mem.track("cluster._visited", _visited)
	mem.track("cluster._z_samples", _z_samples)
	mem.track("cluster._bfs_queue", _bfs_queue)
	mem.track("mod._broadphase_results", mod._broadphase_results)
	mem.track("mod.enemy_cache", mod.enemy_cache)
	mem.track("mod.enemy_markers", mod.enemy_markers)
	mem.track("mod.enemy_healthbars", mod.enemy_healthbars)
	mem.track("mod.enemy_debuffs", mod.enemy_debuffs)
	mem.track("mod.marked_dead", mod.marked_dead)
	mem.track("mod.source_unit_cache", mod.source_unit_cache)
end

local COLOUR_LOOKUP = {
	Gold = { 255, 232, 188, 109 },
	Silver = { 255, 187, 198, 201 },
	Steel = { 255, 161, 166, 169 },
	Black = { 255, 35, 31, 32 },
	Brass = { 255, 226, 199, 126 },
	Terminal = Color.terminal_background(200, true),
	Default = { 255, 161, 166, 169 },
}

-- Soft culling grid
local CULL_CELL_SIZE = 5
local INV_CULL_CELL = 1 / CULL_CELL_SIZE
local _cull_cells = {}
local MAX_PER_CELL = 3

local DEPTH_LAYERS = {
	{ max = 4, min_score = -math.huge }, -- front row ALWAYS visible
	{ max = 6, min_score = 200 }, -- mid row
	{ max = 8, min_score = 400 }, -- back row
	{ max = 100, min_score = 750 }, -- far away...
}

-- priority weights
local PRIORITY = {
	monster = 500,
	captain = 500,
	witch = 500,
	sniper = 500,
	disabler = 200,
	far = 100,
	special = 100,
	elite = 100,
	shield = 50,
	horde = 20,
	enemy = 20,
}

local function _get_priority(entry, dist_sq, forward_bonus)
	local base = PRIORITY[entry.breed_type] or 0

	-- distance bias (closer = higher priority)
	local dist_bias = 1 / (1 + dist_sq * 0.05)

	return base + (dist_bias * 200) + (forward_bonus * 20)
end

local fs = mod.frame_settings

-----------------------------------------------------------------------
-- preload resources + reset caches on game state change
-----------------------------------------------------------------------
mod.on_game_state_changed = function(state, state_name)
	-- ensure packages are loaded
	local pkg = Managers.package

	pkg:load("packages/ui/views/inventory_view/inventory_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/inventory_weapons_view/inventory_weapons_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/inventory_background_view/inventory_background_view", "enemies_improved", nil, true)
	pkg:load(
		"packages/ui/views/inventory_weapon_details_view/inventory_weapon_details_view",
		"enemies_improved",
		nil,
		true
	)
	pkg:load("packages/ui/hud/player_weapon/player_weapon", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/inventory_weapon_marks_view/inventory_weapon_marks_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/cosmetics_inspect_view/cosmetics_inspect_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/masteries_overview_view/masteries_overview_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/mastery_view/mastery_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/dlc_purchase_view/dlc_purchase_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/talent_builder_view/ogryn", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/talent_builder_view/talent_builder_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/expedition_view/expedition_view", "enemies_improved", nil, true)
	pkg:load("packages/ui/views/character_appearance_view/character_appearance_view", "enemies_improved", nil, true)

	-- empty caches
	mod.clear_caches()

	if mod.DEBUG and mod.anim_db_dirty then
		--mod.save_anim_db()
	end
end

local function check_selected_font()
	local fonts = mod._get_font_options()
	local selected_font = mod:get("font_type")
	local exists = false

	for i = 1, #fonts do
		if fonts[i].value == selected_font then
			exists = true
		end
	end

	if not exists and #fonts > 1 then
		mod:echo(mod:localize(font_no_longer_available) .. " \n" .. fonts[1].text)
		mod:set("font_type", fonts[1].value)
	end
end

mod.dmf = get_mod("DMF")
mod.loaded = false

mod.on_unload = function()
	mod.clear_caches()
	mod.loaded = false
end

mod.on_all_mods_loaded = function()
	mod.migrate_override_settings()

	check_selected_font()

	mod.clear_caches()

	mod.init_healthbar_defaults()
	mod.update_breed_colours()
	mod.update_breed_icons()

	-- frame settings were built at script-load time, before the defaults above were
	-- applied; rebuild so newly-applied defaults (e.g. vanguard healthbars off) take effect
	mod.build_frame_settings()

	local outline_settings = require("scripts/settings/outline/outline_settings")
	mod.apply_enemy_outlines(outline_settings)

	mod.load_toggled_debuffs_state()
	mod.load_debuff_colours()

	mod.load_anim_db()

	mod.dmf = get_mod("DMF")
	mod.loaded = true
end

-- DMF's own "Reset to default" only resets the option widgets, and the mod's
-- on_setting_changed propagation then only touches the enemy currently selected
-- in the dropdowns. Wipe every group and individual override as well.
mod.on_settings_reset = function()
	mod.reset_all_overrides()
end

mod.custom_localize = function(loc_string)
	if mod and mod.loaded then
		return mod:localize(loc_string) or ""
	else
		return ""
	end
end

local EnemyImprovedTemplate =
	mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/templates/enemies_improved_template")

local function add_custom_templates(self)
	if EnemyImprovedTemplate then
		if not self._marker_templates[EnemyImprovedTemplate.name] then
			self._marker_templates[EnemyImprovedTemplate.name] = EnemyImprovedTemplate
		end
	end
end

mod:hook_safe(CLASS.HudElementWorldMarkers, "init", function(self)
	add_custom_templates(self)
end)

-- Vanilla _unregister_marker never frees the marker widget: it stays referenced in HudElementBase._widgets_by_name (and the element's _widgets render list) forever, leaking memory every time a marker is removed.
-- This hook captures the marker before vanilla drops all references to it, then release the widget afterwards.
mod:hook(CLASS.HudElementWorldMarkers, "_unregister_marker", function(previous_hook, self, marker)
	local widget = marker and marker.widget

	previous_hook(self, marker)

	if widget then
		local widgets_by_name = self._widgets_by_name

		if widgets_by_name then
			local widget_name = marker.widget_name

			if not widget_name and marker.id then
				widget_name = "marker_widget_id_" .. marker.id
			end

			if widget_name and widgets_by_name[widget_name] == widget then
				widgets_by_name[widget_name] = nil
			else
				for name, w in pairs(widgets_by_name) do
					if w == widget then
						widgets_by_name[name] = nil
						break
					end
				end
			end
		end

		local widgets = self._widgets

		if widgets then
			for i = 1, #widgets do
				if widgets[i] == widget then
					table_remove(widgets, i)
					break
				end
			end
		end
	end
end)

mod.aimed_unit = {}
mod.tagged_units = {}
mod.crosshair_target = nil
mod.crosshair_aimed = {}
mod._periodic_cache_clear_timer = 0

if mod.DEBUG then
	mod.mem_profile.track("mod.aimed_unit", mod.aimed_unit)
	mod.mem_profile.track("mod.tagged_units", mod.tagged_units)
	mod.mem_profile.track("mod.crosshair_aimed", mod.crosshair_aimed)
end

-----------------------------------------------------------------------
-- Hook into the markers update to recalculate enemies.
-----------------------------------------------------------------------
mod:hook_safe(CLASS.HudElementWorldMarkers, "update", function(self, dt, t)
	-- Re-register custom marker templates in case the HUD marker table was rebuilt
	add_custom_templates(self)

	if fs.only_in_meatgrinder then
		local current_level = Managers.state.mission and Managers.state.mission:mission()

		if current_level and current_level.game_mode_name and current_level.game_mode_name == "shooting_range" then
			mod.enabled = true
		else
			mod.enabled = false
		end
	else
		mod.enabled = true
	end

	if mod.enabled then
		-- Aim detection (clear enemy cache of non-aimed at enemies)
		if fs.markers_show_only_aimed then
			-- Crosshair hitscan: the enemy directly under the crosshair always passes
			-- the view-cone / LOS hard rejects (covers close-range head aiming).
			mod.do_crosshair_hitscan()

			table_clear(mod.aimed_unit)
			mod.do_aim_raycast()

			-- Anything the crosshair ray is actually over always counts as aimed.
			for unit in next, mod.crosshair_aimed do
				mod.aimed_unit[unit] = true
			end
		end

		-- Tagged detection (clear enemy cache of non-tagged enemies)
		if fs.only_tagged_enemies then
			mod.do_tagged_scan()
		end

		-- throttle updates according to enemy amounts to help keep performance in check...
		local enemy_count = 0
		for _ in next, mod.enemy_cache do
			enemy_count = enemy_count + 1
		end

		local update_interval

		update_interval = fs.general_throttle_rate

		self._update_time = (self._update_time or 0) + dt
		self._total_update_time = (self._total_update_time or 0) + dt

		if self._update_time > update_interval then
			self._update_time = 0
			mod.update_enemies(dt, t)
		end

		-- pulse special attacks + stagger outlines (combined into single cache iteration)
		local has_specials = fs.outline_specials_enable or fs.marker_specials_enable or fs.healthbar_specials_enable
		local has_stagger = fs.outline_stagger_horde_enable or fs.outline_stagger_enable
		if has_specials or has_stagger then
			local pulse_interval = fs.special_attack_pulse_speed or 0.2
			local stagger_interval = fs.stagger_pulse_speed or 0.2

			for _, entry in next, mod.enemy_cache do
				-- special attack pulse
				if has_specials then
					if entry.special_attack_imminent then
						entry._pulse_timer = (entry._pulse_timer or 0) + dt
						if entry._pulse_timer >= pulse_interval then
							mod.pulse_enemy_outline(entry)
							entry._pulse_timer = 0
						end
					else
						mod.remove_alert_outline(entry)
					end
				end

				-- stagger pulse
				if has_stagger then
					if
						(entry.is_horde and fs.outline_stagger_horde_enable)
						or (not entry.is_horde and fs.outline_stagger_enable)
					then
						if entry.staggered then
							entry._pulse_timer = (entry._pulse_timer or 0) + dt
							if entry._pulse_timer >= stagger_interval then
								mod.pulse_enemy_outline(entry)
								entry._pulse_timer = 0
							end
						else
							mod.remove_stagger_outline(entry)
						end
					else
						mod.remove_stagger_outline(entry)
					end
				end
			end
		end

		-- OUTLINE SAFETY CLEANUP - runs every ~2 seconds to clean stuck outlines
		self._outline_safety_timer = (self._outline_safety_timer or 0) + dt
		if self._outline_safety_timer >= 2 then
			self._outline_safety_timer = 0
			mod.outline_safety_cleanup()
		end

		-- MARKER CLEANUP - runs every ~1 second to remove orphaned markers for dead/invalid units
		self._marker_cleanup_timer = (self._marker_cleanup_timer or 0) + dt
		if self._marker_cleanup_timer >= 1 then
			self._marker_cleanup_timer = 0
			mod.cleanup_orphaned_markers()
		end

		-- Hide default health bars if custom healthbars are enabled!
		local markers = self._markers
		if not markers or #markers == 0 then
			return
		end

		for i = 1, #markers do
			local marker = markers[i]
			local template = marker and marker.template

			if template then
				local name = template.name

				-- REMOVE BASE HEALTHBAR
				if
					fs.healthbar_enable
					and name
					and name ~= "enemies_improved"
					and string.find(name, "damage_indicator", 1, true)
				then
					marker.draw = false
					marker.alpha_multiplier = 0
				end

				-- REMOVE THREAT SKULLS
				if fs.remove_tag_skull and marker.type and string.find(marker.type, "unit_threat", 1, true) then
					marker.draw = false
					marker.alpha_multiplier = 0
				end
			end
		end

		-- PERIODIC FULL CACHE CLEAR — runs every ~2 minutes to flush any accumulated stale data
		mod._periodic_cache_clear_timer = mod._periodic_cache_clear_timer + dt
		if mod._periodic_cache_clear_timer >= 60 then
			mod._periodic_cache_clear_timer = 0
			mod.clear_caches()
		end
	end
end)

mod.get_marker_by_id = function(id)
	local ui_manager = Managers.ui
	local hud = ui_manager:get_hud()
	local world_markers = hud and hud:element("HudElementWorldMarkers")
	local markers_by_id = world_markers and world_markers._markers_by_id

	-- DEBUG TO CREATE MARKER LIST
	--if mod.DEBUG then
	--dbg_markers = world_markers._markers_by_type
	--end

	if markers_by_id then
		return markers_by_id[id]
	else
		return nil
	end
end

mod.force_remove_unit_markers = function(unit)
	if not unit then
		return
	end

	local function remove(id)
		if id then
			Managers.event:trigger("remove_world_marker", id)
		end
	end

	local entry = mod.enemy_cache[unit]
	if entry then
		if entry.marker then
			remove(entry.marker.id)
		end

		mod.enemy_markers[unit] = nil
		mod.enemy_healthbars[unit] = nil
		mod.enemy_debuffs[unit] = nil

		-- reset cluster state if this unit was a rep
		local cluster = mod.get_horde_cluster_for_unit(unit)
		if cluster and cluster.rep_unit == unit then
			cluster._healthbar_created = false
			cluster._healthbar_marker_id = nil
		end

		entry._ei_marker_created = false
		entry._ei_marker_pending = nil
		-- Release marker entry references so the (now removed) marker + widget can be GC'd
		entry.marker = nil

		mod.disable_enemy_outlines(unit, entry)
		mod.remove_alert_outline(entry)
		mod.remove_stagger_outline(entry)
	end
end

-- Remove ALL enemies_improved markers from the world markers system (used during mod reload/unload)
mod.remove_all_ei_markers = function()
	local ui_manager = Managers.ui
	local hud = ui_manager and ui_manager:get_hud()
	local world_markers = hud and hud:element("HudElementWorldMarkers")
	if not world_markers then
		return
	end

	local event = Managers.event

	-- Collect marker IDs to remove by iterating _markers_by_type directly
	local by_type = world_markers._markers_by_type
	local ei_list = by_type and by_type["enemies_improved"]
	if ei_list then
		-- Copy IDs first so removal during iteration doesn't cause issues
		local ids = {}
		local n = 0
		for i = 1, #ei_list do
			local m = ei_list[i]
			local id = m and (m.id or m)
			if id then
				n = n + 1
				ids[n] = id
			end
		end
		for i = 1, n do
			event:trigger("remove_world_marker", ids[i])
		end
	end

	-- Also clear our tracking tables so we don't hold stale references
	table_clear(mod.enemy_markers)
	table_clear(mod.enemy_healthbars)
	table_clear(mod.enemy_debuffs)

	-- Free orphaned marker widgets are still referenced by name in _widgets_by_name.
	-- Vanilla never removes marker widgets on unregister, so this reclaims any widget whose marker id is no longer registered (including previously leaked ones).
	local widgets_by_name = world_markers._widgets_by_name
	local markers_by_id = world_markers._markers_by_id

	if widgets_by_name and markers_by_id then
		local prefix = "marker_widget_id_"

		for name, w in pairs(widgets_by_name) do
			if type(name) == "string" and string.sub(name, 1, #prefix) == prefix then
				local id = tonumber(string.sub(name, #prefix + 1))
				if id and not markers_by_id[id] then
					widgets_by_name[name] = nil
				end
			end
		end
	end
end

-- Clean up markers whose unit has no cache entry at all (mod reload, stale callbacks, etc.)
-- Units with cache entries (dead or alive) are handled by remove_dead to avoid racing with DPS windows.
mod.cleanup_orphaned_markers = function()
	local to_remove = {}
	local count = 0

	for unit, marker_id in pairs(mod.enemy_markers) do
		if not mod.enemy_cache[unit] then
			count = count + 1
			to_remove[count] = unit
		end
	end

	for unit, marker_id in pairs(mod.enemy_healthbars) do
		if not mod.enemy_markers[unit] and not mod.enemy_cache[unit] then
			count = count + 1
			to_remove[count] = unit
		end
	end

	for unit, marker_id in pairs(mod.enemy_debuffs) do
		if not mod.enemy_markers[unit] and not mod.enemy_cache[unit] then
			count = count + 1
			to_remove[count] = unit
		end
	end

	for i = 1, count do
		mod.force_remove_unit_markers(to_remove[i])
	end
end

-----------------------------------------------------------------------
-- Enemy scanning
-----------------------------------------------------------------------

mod.scan_enemies = function()
	table_clear(_horde_units_all)
	table_clear(_cull_pool)

	local local_player = Managers_player:local_player(1)
	if not local_player then
		return
	end

	local player_unit = local_player.player_unit
	if not player_unit or not mod.detect_alive(player_unit) then
		return
	end

	mod.set_is_ads(player_unit)

	local wp = Unit.world_position(player_unit, 1, _player_pos_vec)
	local current_pos = wp and Vector3(wp.x, wp.y, wp.z) or nil

	--[[local last_pos = mod._last_scan_pos

	-- Skip scan if player hasn't moved enough
	if last_pos then
		local dx = current_pos.x - last_pos.x
		local dy = current_pos.y - last_pos.y
		local dz = current_pos.z - last_pos.z

		local dist_sq = dx * dx + dy * dy + dz * dz

		if dist_sq < 1 then
			return
		end
	end

	mod._last_scan_pos = current_pos]]

	local extension_manager = Managers_state.extension
	if not extension_manager then
		return
	end

	local broadphase_system = extension_manager:system("broadphase_system")
	local side_system = extension_manager:system("side_system")
	if not broadphase_system or not side_system then
		return
	end

	local side = side_system.side_by_unit[player_unit]
	if not side then
		return
	end

	local broadphase = broadphase_system.broadphase
	local from_pos = current_pos
	local enemy_side_names = side:relation_side_names("enemy")
	local range = mod.frame_settings.draw_distance_broadphase or mod.frame_settings.draw_distance

	local results = mod._broadphase_results
	table_clear(results)

	local num_hits = broadphase.query(broadphase, from_pos, range, results, enemy_side_names)

	if num_hits == 0 then
		return
	end

	local cache = mod.enemy_cache

	-- mark unseen (preserve DPS-window dead units so they continue rendering)
	for _, data in next, cache do
		if not data._dead_at then
			data.seen = false
		end
	end

	-- Return cull cell entries to pool before clearing
	for key, list in pairs(_cull_cells) do
		for i = 1, #list do
			local e = list[i]
			_cull_pool_count = _cull_pool_count + 1
			_cull_pool[_cull_pool_count] = e
		end
		table_clear(list)
	end
	table_clear(_cull_cells)

	-- Cap pool size to prevent unbounded growth
	if _cull_pool_count > 512 then
		for i = 513, _cull_pool_count do
			_cull_pool[i] = nil
		end
		_cull_pool_count = 512
	end

	local world = Managers.world:world("level_world")
	local physics_world_cache = world and World.get_data(world, "physics_world")

	for i = 1, num_hits do
		local unit = results[i]

		if unit and HEALTH_ALIVE[unit] and Unit_alive(unit) then
			local forward_bonus = mod.get_forward_dot and mod.get_forward_dot(player_unit, unit) or 1

			-- The view cone is flattened to the XY plane, so at close range an
			-- enemy's origin (feet) can sit behind the camera while its head is under
			-- the crosshair. The hitscan in do_crosshair_hitscan() records every enemy
			-- the crosshair ray touches, so those always pass the hard rejects.
			local is_crosshair_target = mod.crosshair_aimed[unit] == true

			-- VIEW CONE FILTER (HARD REJECT)
			if forward_bonus <= 0 and not is_crosshair_target then
				mod.force_remove_unit_markers(unit)

				if mod._cleanup_unit_health_data then
					mod._cleanup_unit_health_data(unit)
				end

				cache[unit] = nil
				mod.marked_dead[unit] = nil
				goto skip_breed
			end

			-- LOS FILTER (HARD REJECT)
			if physics_world_cache and not is_crosshair_target then
				if not mod.has_line_of_sight(player_unit, unit, physics_world_cache) then
					mod.force_remove_unit_markers(unit)

					if mod._cleanup_unit_health_data then
						mod._cleanup_unit_health_data(unit)
					end

					cache[unit] = nil
					mod.marked_dead[unit] = nil
					goto skip_breed
				end
			end

			local entry = cache[unit]

			local pos = Unit.world_position(unit, 1, _pos_vec)
			if entry then
				entry.pos = Vector3(pos.x, pos.y, pos.z)
			end

			local dx = pos.x - current_pos.x
			local dy = pos.y - current_pos.y
			local dz = pos.z - current_pos.z
			local dist_sq = dx * dx + dy * dy + dz * dz

			local unit_data_ext = ScriptUnit_has_extension(unit, "unit_data_system")
			if not unit_data_ext then
				goto skip_breed
			end

			local breed = unit_data_ext:breed()
			local breed_type = mod.find_breed_category(unit)

			-- build animation map for this enemy
			if mod.DEBUG then
				--mod.init_breed_anim_db(unit, breed, breed.name)
			end

			-- collect ALL horde units BEFORE culling
			if breed and breed.tags and (breed.tags.horde or breed.tags.roamer) then
				_horde_units_all[#_horde_units_all + 1] = unit
			end

			-- DO NOT ADD WIDGETS FOR THESE BREEDS:
			if breed.name == "sand_vortex" or breed.name == "nurgle_flies" or breed.name == "attack_valkyrie" then
				goto skip_breed
			end

			if fs.spatial_culling then
				local gx = math_floor(pos.x * INV_CULL_CELL)
				local gy = math_floor(pos.y * INV_CULL_CELL)

				local temp_entry = entry or {
					unit = unit,
					breed = breed,
					breed_type = breed_type,
				}

				local score = _get_priority(temp_entry, dist_sq, forward_bonus)

				if entry then
					score = score + 5 -- small boost if already has a marker. Just to make hordes act a little more stable.
				end

				temp_entry._priority_score = score

				local key = gx * 73856093 + gy * 19349663
				local list = _cull_cells[key]

				if not list then
					list = {}
					_cull_cells[key] = list
				end

				local e = _cull_pool[_cull_pool_count]
				if e then
					_cull_pool[_cull_pool_count] = nil
					_cull_pool_count = _cull_pool_count - 1
				else
					e = {}
				end
				e.unit = unit
				e.score = score
				e.dist_sq = dist_sq
				e.entry = entry
				e.unit_data_ext = unit_data_ext
				e.breed = breed
				e.breed_type = breed_type
				e.pos = Vector3(pos.x, pos.y, pos.z)
				list[#list + 1] = e

				goto skip_breed
			else
				if not entry then
					cache[unit] = {
						unit = unit,
						seen = true,

						dead = false,

						-- cache extensions
						health_ext = ScriptUnit_has_extension(unit, "health_system"),
						unit_data_ext = unit_data_ext,
						behavior_ext = ScriptUnit_has_extension(unit, "behavior_system"),

						is_horde = mod.is_horde(unit),

						breed = breed,
						breed_name = breed and breed.name,
						breed_type = mod.find_breed_category(unit),

						special_attack_event = nil,
						special_attack_imminent = false,
						special_attack_timer = 0,

						-- outlines
						alert_outline = false,
						stagger_outline = false,
						outline_name = nil,

						alert_healthbar = false,

						_ei_marker_created = false,
					}

					mod.marked_dead[unit] = nil
				else
					entry.seen = true
					mod.marked_dead[unit] = nil
					entry._dead_at = nil
				end
			end
			::skip_breed::
		end
	end

	if fs.spatial_culling then
		for _, list in pairs(_cull_cells) do
			table.sort(list, function(a, b)
				if a.score == b.score then
					return a.dist_sq < b.dist_sq
				end
				return a.score > b.score
			end)

			for i = 1, #list do
				local data = list[i]
				local unit = data.unit

				-- An enemy the crosshair is over is never culled, even if its priority
				-- score is low (e.g. aiming at an enemy's head at point-blank range).
				local keep = mod.crosshair_aimed[unit] == true

				for l = 1, #DEPTH_LAYERS do
					local layer = DEPTH_LAYERS[l]

					if i <= layer.max then
						if data.score >= layer.min_score then
							keep = true
						end
						break
					end
				end

				if keep then
					local entry = mod.enemy_cache[unit]

					if not entry then
						mod.enemy_cache[unit] = {
							unit = unit,
							seen = true,
							dead = false,

							health_ext = ScriptUnit_has_extension(unit, "health_system"),
							unit_data_ext = data.unit_data_ext,
							behavior_ext = ScriptUnit_has_extension(unit, "behavior_system"),

							is_horde = mod.is_horde(unit),

							breed = data.breed,
							breed_name = data.breed and data.breed.name,
							breed_type = data.breed_type,

							_priority_score = data.score,
							pos = Vector3(data.pos.x, data.pos.y, data.pos.z),
							_ei_marker_created = false,
						}
					else
						entry.seen = true
						entry._priority_score = data.score
						entry.pos = Vector3(data.pos.x, data.pos.y, data.pos.z)
						entry._dead_at = nil
					end

					mod.marked_dead[unit] = nil
				else
					-- culled
					mod.force_remove_unit_markers(unit)
				end
			end
		end
	end
end

-----------------------------------------------------------------------
-- Horde clustering helpers
-----------------------------------------------------------------------

-- Distance-based clustering radius (in meters)
local CLUSTER_RADIUS = 10
local CLUSTER_RADIUS_SQ = CLUSTER_RADIUS * CLUSTER_RADIUS
local HASH_CELL_SIZE = CLUSTER_RADIUS
local INV_HASH_CELL_SIZE = 1 / HASH_CELL_SIZE
local HORDE_MIN_UNITS_FOR_CLUSTER = fs.hb_horde_clusters_size or 8

local function _build_horde_clusters(units, num_units)
	table_clear(_horde_clusters)
	table_clear(_horde_cluster_by_unit)

	HORDE_MIN_UNITS_FOR_CLUSTER = fs.hb_horde_clusters_size

	-- Return early if player is dead
	local player = Managers.player:local_player(1)
	if not player then
		return
	end
	local player_unit = player.player_unit
	if not player_unit or not mod.detect_alive(player_unit) then
		return
	end

	if num_units < HORDE_MIN_UNITS_FOR_CLUSTER then
		return
	end

	local clusters = _horde_clusters
	local spatial = _spatial_hash
	local visited = _visited

	-- Clear reusable tables for this frame
	for _, cell in pairs(spatial) do
		table_clear(cell)
	end
	table_clear(spatial)
	table_clear(visited)

	-- Step 1: build spatial hash
	for i = 1, num_units do
		local unit = units[i]

		if unit and HEALTH_ALIVE[unit] and Unit_alive(unit) then
			local entry = mod.enemy_cache[unit]

			local breed
			if entry then
				breed = entry.breed
			else
				local ext = ScriptUnit_has_extension(unit, "unit_data_system")
				breed = ext and ext:breed()
			end

			local tags = breed and breed.tags

			if tags and (tags.horde or tags.roamer) then
				local pos

				if entry and entry.pos then
					pos = entry.pos
				else
					local wp = Unit.world_position(unit, 1, _pos_vec)
					pos = wp and Vector3(wp.x, wp.y, wp.z) or nil
					if entry then
						entry.pos = pos
					end
				end

				if pos then
					local gx = math_floor(pos.x * INV_HASH_CELL_SIZE)
					local gy = math_floor(pos.y * INV_HASH_CELL_SIZE)
					local key = gx * 73856093 + gy * 19349663

					if key then
						local cell = spatial[key]
						if not cell then
							cell = {}
							spatial[key] = cell
						end

						cell[#cell + 1] = unit
					end
				end
			end
		end
	end

	-- Step 2: cluster via BFS
	for i = 1, num_units do
		local unit = units[i]
		local z_samples = _z_samples
		table_clear(z_samples)

		if not visited[unit] and mod.detect_alive(unit) then
			local entry = mod.enemy_cache[unit]
			local breed = entry and entry.breed
			local tags = breed and breed.tags

			if not (tags and (tags.horde or tags.roamer)) then
				goto continue
			end

			local cluster_units = {}
			local queue = _bfs_queue
			table_clear(queue)
			queue[1] = unit
			visited[unit] = true

			local sum_x, sum_y, sum_z = 0, 0, 0
			local count = 0

			local max_z = 0

			-- Bounds for midpoint center
			local min_x = math.huge
			local max_x = -math.huge
			local min_y = math.huge
			local max_y = -math.huge

			-- Track top 2 heights
			--local highest_z = -math.huge
			--local second_highest_z = -math.huge

			while #queue > 0 do
				local current = queue[#queue]
				queue[#queue] = nil

				local e = mod.enemy_cache[current]
				local wp = Unit.world_position(current, 1)
				local pos = wp and Vector3(wp.x, wp.y, wp.z) or nil
				if pos and e then
					e.pos = pos
				end

				if pos then
					cluster_units[#cluster_units + 1] = current

					-- Proper centroid accumulation (X, Y, Z)
					sum_x = sum_x + pos.x
					sum_y = sum_y + pos.y
					sum_z = sum_z + pos.z
					count = count + 1
					z_samples[#z_samples + 1] = pos.z

					-- Bounds tracking (X/Y center)
					if pos.x < min_x then
						min_x = pos.x
					end
					if pos.x > max_x then
						max_x = pos.x
					end
					if pos.y < min_y then
						min_y = pos.y
					end
					if pos.y > max_y then
						max_y = pos.y
					end

					local gx = math_floor(pos.x * INV_HASH_CELL_SIZE)
					local gy = math_floor(pos.y * INV_HASH_CELL_SIZE)

					-- check neighboring cells
					for dx = -1, 1 do
						for dy = -1, 1 do
							local key = (gx + dx) * 73856093 + (gy + dy) * 19349663
							local cell = spatial[key]

							if cell then
								for j = 1, #cell do
									local other = cell[j]

									if not visited[other] and mod.detect_alive(other) then
										local oe = mod.enemy_cache[other]
										if oe and oe.breed == breed then
											local wp2 = Unit.world_position(other, 1)
											local op = wp2 and Vector3(wp2.x, wp2.y, wp2.z) or nil
											if op then
												oe.pos = op
												local dx = op.x - pos.x
												local dy = op.y - pos.y
												local dist_sq = dx * dx + dy * dy

												if dist_sq <= CLUSTER_RADIUS_SQ then
													visited[other] = true
													queue[#queue + 1] = other
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end

			if count >= HORDE_MIN_UNITS_FOR_CLUSTER then
				local inv = 1 / count

				local cx = (min_x + max_x) * 0.5
				local cy = (min_y + max_y) * 0.5
				local avg_z = sum_z * inv

				local width = max_x - min_x
				local height = max_y - min_y

				-- If cluster is too thin, fall back slightly toward centroid feel
				if width < 1.5 or height < 1.5 then
					-- small bias toward first unit
					local rep = cluster_units[1]
					if rep then
						local entry = mod.enemy_cache[rep]
						local pos = entry and entry.pos
						if pos then
							cx = cx * 0.7 + pos.x * 0.3
							cy = cy * 0.7 + pos.y * 0.3
						end
					end
				end

				-- average
				--local target_z = avg_z + 2.0

				--max
				--local target_z = max_z + 2.0

				-- tallest / second tallest
				-- Fallback if cluster is tiny or something went weird
				--local base_z
				--if second_highest_z > -math.huge then
				--	base_z = (highest_z + second_highest_z) * 0.5
				--else
				--	base_z = highest_z
				--end

				--local target_z = base_z + 2.0

				table.sort(z_samples)

				local trim = math.floor(#z_samples * 0.2) -- trim 20% top/bottom
				local start_i = 1 + trim
				local end_i = #z_samples - trim

				local trimmed_sum = 0
				local trimmed_count = 0

				for i = start_i, end_i do
					trimmed_sum = trimmed_sum + z_samples[i]
					trimmed_count = trimmed_count + 1
				end

				local avg_z = trimmed_count > 0 and (trimmed_sum / trimmed_count) or (sum_z * inv)
				local target_z = avg_z + 2.0

				local idx = #clusters + 1

				-- smooth
				local prev = clusters[idx] and clusters[idx].center

				local smooth_z = target_z
				if prev then
					smooth_z = prev.z + (target_z - prev.z) * 0.2
				end

				local cluster = {
					breed_name = breed.name,
					units = cluster_units,
					count = count,
					rep_unit = cluster_units[1],
					center = {
						x = cx,
						y = cy,
						z = smooth_z,
					},
					total_current = 0,
					total_max = 0,
				}

				clusters[idx] = cluster

				for j = 1, #cluster_units do
					_horde_cluster_by_unit[cluster_units[j]] = idx
				end

				-- aggregate health (cached extensions)
				local total_current = 0
				local total_max = 0

				for j = 1, #cluster_units do
					local u = cluster_units[j]
					local e = mod.enemy_cache[u]

					if e and mod.detect_alive(u) then
						local he = e.health_ext
						if he then
							local ok, v = pcall(he.current_health, he)
							if ok then
								total_current = total_current + (v or 0)
							end
							ok, v = pcall(he.max_health, he)
							if ok then
								total_max = total_max + (v or 0)
							end
						end
					end
				end

				cluster.total_current = total_current
				cluster.total_max = total_max
			end
		end

		::continue::
	end
end

mod.get_horde_cluster_for_unit = function(unit)
	local idx = _horde_cluster_by_unit[unit]
	return idx and _horde_clusters[idx] or nil
end

-----------------------------------------------------------------------
-- Enemy markers
-----------------------------------------------------------------------

mod.get_time = function()
	local tm = Managers and Managers.time
	local fallback = os.clock() or 0
	if tm then
		if tm:has_timer("gameplay") then
			return tm:time("gameplay") or fallback
		end
		if tm:has_timer("ui") then
			return tm:time("ui") or fallback
		end
		if tm:has_timer("main") then
			return tm:time("main") or fallback
		end
	end
	return fallback
end

mod.ts = function()
	return string.format("[%.3f]", mod.get_time())
end

function string.starts(String, Start)
	return string.sub(String, 1, string.len(Start)) == Start
end

local _units_to_remove = {}

mod.remove_dead = function()
	table_clear(_units_to_remove)

	-- Get player
	local player = Managers.player:local_player(1)
	if not player then
		return
	end

	local player_unit = player.player_unit
	if not player_unit or not mod.detect_alive(player_unit) then
		return
	end

	local player_pos = Unit.world_position(player_unit, 1)
	local max_dist_sq = (mod.frame_settings.draw_distance or 50) ^ 2
	local fs = mod.frame_settings
	local t = mod.get_time()
	local mark_dead = false
	local remove_table = _units_to_remove

	-- Main loop
	for unit, entry in next, mod.enemy_cache do
		local remove = false

		-- Dead check
		if not mod.detect_alive(unit) then
			if fs.hb_show_dps or fs.widget_removal_delay > 0 then
				if not entry._dead_at then
					entry._dead_at = t
				end
			else
				remove = true
				mark_dead = true
			end
		else
			local health_extension = entry and entry.health_ext
			if health_extension then
				local ok, pct = pcall(health_extension.current_health_percent, health_extension)
				if ok and pct <= 0 then
					if fs.hb_show_dps or fs.widget_removal_delay > 0 then
						if not entry._dead_at then
							entry._dead_at = t
						end
					else
						remove = true
						mark_dead = true
					end
				end
			else
				remove = true
				mark_dead = true
			end
		end

		-- Deferred removal: clean up after the widget removal delay (or the DPS window,
		-- whichever is longer) so the widget can linger a moment on freshly dead enemies.
		if not remove and entry._dead_at then
			local dead_window = math.max(fs.damage_number_duration or 0, fs.widget_removal_delay or 0)
			if dead_window > 0 and t - entry._dead_at > dead_window then
				remove = true
				mark_dead = true
			end
		end

		-- Distance check
		if not remove and player_pos and mod.detect_alive(unit) then
			local wp = Unit.world_position(unit, 1)
			if wp then
				entry.pos = Vector3(wp.x, wp.y, wp.z)
			end
			local pos = entry.pos

			if pos then
				local dx = pos.x - player_pos.x
				local dy = pos.y - player_pos.y
				local dz = pos.z - player_pos.z
				local dist_sq = dx * dx + dy * dy + dz * dz

				-- individual distance override (replaces global for this enemy)
				local breed_name = entry.breed_name
				local effective_max_dist_sq = max_dist_sq
				if breed_name then
					if fs.breed_dist_enabled[breed_name] then
						local ind_dist = fs.breed_dist_value[breed_name]
						if ind_dist then
							effective_max_dist_sq = ind_dist * ind_dist
						end
					end
				end

				if dist_sq > effective_max_dist_sq then
					remove = true

					-- disable outlines too
					mod.disable_enemy_outlines(unit, entry)
					mod.remove_alert_outline(entry)
					mod.remove_stagger_outline(entry)
				end
			end
		end

		-- If this unit was a cluster rep, clear cluster healthbar state
		local cluster = mod.get_horde_cluster_for_unit(unit)
		if cluster and cluster.rep_unit == unit then
			cluster._healthbar_created = false
			cluster._healthbar_marker_id = nil
		end

		if remove then
			local id
			id = mod.enemy_markers[unit]
			if id then
				Managers.event:trigger("remove_world_marker", id)
			end
			id = mod.enemy_healthbars[unit]
			if id then
				Managers.event:trigger("remove_world_marker", id)
			end
			id = mod.enemy_debuffs[unit]
			if id then
				Managers.event:trigger("remove_world_marker", id)
			end

			remove_table[#remove_table + 1] = unit
		end
	end

	-- Cleanup
	for _, unit in next, remove_table do
		if mark_dead then
			mod.marked_dead[unit] = true
		else
			mod.marked_dead[unit] = nil
		end

		mod.enemy_healthbars[unit] = nil
		mod.enemy_debuffs[unit] = nil
		mod.enemy_markers[unit] = nil

		-- Clean up per-unit data that accumulates if healthbars module is loaded
		if mod._cleanup_unit_health_data then
			mod._cleanup_unit_health_data(unit)
		end

		mod.enemy_cache[unit] = nil
	end
end

mod.is_horde = function(unit)
	if Unit_alive(unit) then
		local tags = mod.get_breed_tags(unit)
		local is_horde = tags and (tags.horde or tags.roamer) or false
		if mod.is_vanguard(unit) then
			is_horde = false
		end
		return is_horde
	else
		return false
	end
end

-----------------------------------------------------------------------
-- Cache clearing
-----------------------------------------------------------------------

mod.clear_caches = function()
	mod.remove_all_ei_markers()

	table_clear(mod._broadphase_results)
	table_clear(mod.source_unit_cache)
	table_clear(mod.enemy_markers)
	table_clear(mod.enemy_healthbars)
	table_clear(mod.enemy_debuffs)
	table_clear(mod.enemy_cache)
	table_clear(mod.marked_dead)

	--table_clear(mod.latest_damaged_enemies)
	--table_clear(mod.latest_damaged_enemies_set)
	table_clear(mod.aimed_unit)
	table_clear(mod.tagged_units)
	table_clear(mod.crosshair_aimed)
	mod.crosshair_target = nil

	if mod._clear_unit_health_data then
		mod._clear_unit_health_data()
	end

	table_clear(_enemy_units_temp)
	table_clear(_horde_clusters)
	table_clear(_horde_cluster_by_unit)

	table_clear(_spatial_hash)
	table_clear(_visited)
	table_clear(_z_samples)
	table_clear(_bfs_queue)

	table_clear(_cull_pool)
	table_clear(_cull_cells)
	table_clear(_units_to_remove)

	if mod._clear_outline_caches then
		mod._clear_outline_caches()
	end
end

mod.update_horde_clusters = function(temp, to_process)
	if fs.horde_clusters_enable then
		_build_horde_clusters(temp, to_process)
	else
		table_clear(_horde_clusters)
		table_clear(_horde_cluster_by_unit)
	end
end

-- Exact crosshair ray (origin + direction) using the first-person unit transform with
-- weapon recoil and sway applied, mirroring the DynamicCrosshair mod. This is the same
-- vector the game uses to place the crosshair, so the raycast lands under the reticle.
-- Falls back to the player camera if the first-person/weapon extensions are missing.
mod.get_crosshair_shooting_vector = function(hud)
	local player_extensions = hud and hud:player_extensions()

	if player_extensions then
		local unit_data_extension = player_extensions.unit_data
		local first_person_extension = player_extensions.first_person
		local weapon_extension = player_extensions.weapon

		if unit_data_extension and first_person_extension and weapon_extension then
			local first_person_unit = first_person_extension:first_person_unit()

			if first_person_unit and Unit_alive(first_person_unit) then
				local shoot_position = Unit.world_position(first_person_unit, 1)
				local shoot_rotation = Unit.world_rotation(first_person_unit, 1)

				shoot_rotation = Recoil.apply_weapon_recoil_rotation(
					weapon_extension:recoil_template(),
					unit_data_extension:read_component("recoil"),
					unit_data_extension:read_component("movement_state"),
					unit_data_extension:read_component("locomotion"),
					unit_data_extension:read_component("inair_state"),
					shoot_rotation
				)

				shoot_rotation = Sway.apply_sway_rotation(
					weapon_extension:sway_template(),
					unit_data_extension:read_component("sway"),
					shoot_rotation
				)

				return shoot_position, Quaternion_forward(shoot_rotation)
			end
		end
	end

	local camera = hud and hud:player_camera()

	if camera then
		return Camera.local_position(camera), Quaternion_forward(Camera.local_rotation(camera))
	end

	return nil, nil
end

-- Crosshair hitscan: raycast along the exact crosshair vector and remember every living
-- enemy the crosshair is actually over. The closest hit must be that enemy (walls/props
-- block it), so an enemy we are literally aiming at always passes the view cone and LOS
-- hard filters, regardless of where its origin (feet) sits relative to the camera.
mod.do_crosshair_hitscan = function()
	mod.crosshair_target = nil
	table_clear(mod.crosshair_aimed)

	local ui_manager = Managers.ui
	local hud = ui_manager and ui_manager:get_hud()
	if not hud then
		return
	end

	local world = Managers.world:world("level_world")
	local physics_world = world and World.get_data(world, "physics_world")
	if not physics_world then
		return
	end

	local player = Managers.player:local_player(1)
	local player_unit = player and player.player_unit
	if not player_unit or not mod.detect_alive(player_unit) then
		return
	end

	local shoot_position, shoot_direction = mod.get_crosshair_shooting_vector(hud)
	if not shoot_position or not shoot_direction then
		return
	end

	local max_dist = fs.draw_distance_broadphase or fs.draw_distance

	local hits = PhysicsWorld.raycast(
		physics_world,
		shoot_position,
		shoot_direction,
		max_dist,
		"all",
		"max_hits",
		64,
		"collision_filter",
		"filter_player_character_shooting_raycast"
	)

	if not hits then
		return
	end

	-- Find the closest thing the crosshair ray actually hits (including walls/props).
	-- The player's own actor is ignored so its weapon/body cannot block the shot.
	local closest_dist = math.huge
	local num_hits = #hits

	for i = 1, num_hits do
		local hit = hits[i]
		local hit_dist = hit[2]
		local hit_actor = hit[4]
		local hit_unit = hit_actor and Actor_unit(hit_actor)

		if hit_dist and hit_dist > 0.1 and hit_unit ~= player_unit and hit_dist < closest_dist then
			closest_dist = hit_dist
		end
	end

	if closest_dist == math.huge then
		return
	end

	-- Everything at the closest hit point counts; a wall/prop first means no enemy passes.
	for i = 1, num_hits do
		local hit = hits[i]
		local hit_dist = hit[2]
		local hit_actor = hit[4]
		local hit_unit = hit_actor and Actor_unit(hit_actor)

		if hit_unit and hit_unit ~= player_unit and hit_dist and hit_dist <= closest_dist + 0.05 then
			if HEALTH_ALIVE[hit_unit] and Unit_alive(hit_unit) then
				mod.crosshair_aimed[hit_unit] = true

				if not mod.crosshair_target then
					mod.crosshair_target = hit_unit
				end
			end
		end
	end
end

-- Crosshair cone check: find the closest enemy within ~12° of camera centre using the camera's own position/rotation and the engine's position lookup cache.
mod.do_aim_raycast = function()
	local ui_manager = Managers.ui
	local hud = ui_manager and ui_manager:get_hud()
	local world_markers = hud and hud:element("HudElementWorldMarkers")
	if not world_markers then
		return
	end

	local camera = world_markers:_get_camera()
	if not camera then
		return
	end

	local cam_pos = Camera.local_position(camera)
	local px, py, pz = cam_pos.x, cam_pos.y, cam_pos.z
	local forward = Quaternion.forward(Camera.local_rotation(camera))
	local cone_cos = math.cos(math.rad(fs.aim_cone_angle or 8))
	local draw_dist_sq = fs.draw_distance * fs.draw_distance

	for unit in pairs(mod.enemy_cache) do
		if Unit_alive(unit) then
			local enemy_pos = POSITION_LOOKUP[unit]
			if enemy_pos then
				local dx = enemy_pos.x - px
				local dy = enemy_pos.y - py
				local dz = (enemy_pos.z - pz) * 0.3
				local dist_sq = dx * dx + dy * dy + dz * dz

				-- Use the same per-enemy effective distance as the draw-distance filter,
				-- so individual overrides larger than the global draw distance still count as aimed.
				local entry = mod.enemy_cache[unit]
				local effective_max_dist_sq = draw_dist_sq
				local breed_name = entry and entry.breed_name
				if breed_name and fs.breed_dist_enabled and fs.breed_dist_enabled[breed_name] then
					local ind_dist = fs.breed_dist_value[breed_name]
					if ind_dist then
						effective_max_dist_sq = ind_dist * ind_dist
					end
				end

				if dist_sq < effective_max_dist_sq and dist_sq > 0 then
					local dist = math.sqrt(dist_sq)
					local dot = (dx * forward.x + dy * forward.y + dz * forward.z) / dist
					if dot > cone_cos then
						mod.aimed_unit[unit] = true
					end
				end
			end
		end
	end
end

-- Build a set of units that are currently tagged via the smart-tag system.
mod.do_tagged_scan = function()
	table_clear(mod.tagged_units)

	local smart_tag_system = Managers.state.extension:system("smart_tag_system")
	if not smart_tag_system then
		return
	end

	for unit in next, mod.enemy_cache do
		if Unit_alive(unit) then
			local tag_id = smart_tag_system:unit_tag_id(unit)
			if tag_id then
				mod.tagged_units[unit] = true
			end
		end
	end
end

-----------------------------------------------------------------------
-- Main update orchestration
-----------------------------------------------------------------------

mod.update_enemies = function(dt, t)
	mod.scan_enemies()

	if not next(mod.enemy_cache) then
		return
	end

	local temp = _enemy_units_temp
	local count = 0

	for unit in next, mod.enemy_cache do
		count = count + 1
		temp[count] = unit
	end

	if count == 0 then
		return
	end

	-- rotate index so we don't always process the same subset first
	_last_enemy_index = (_last_enemy_index % count) + 1

	local to_process = math_min(count, MAX_ENEMIES_PER_FRAME)

	-- select a rotating window of units into first to_process entries
	if to_process < count then
		local idx = _last_enemy_index
		for i = 1, to_process do
			if idx > count then
				idx = 1
			end
			-- swap into front
			temp[i], temp[idx] = temp[idx], temp[i]
			idx = idx + 1
		end
	end

	-- trim any extra entries in temp
	for i = to_process + 1, count do
		temp[i] = nil
	end

	-- update horde clusters...
	if fs.horde_clusters_enable then
		mod.update_horde_clusters(_horde_units_all, #_horde_units_all)
	end

	local player = Managers.player:local_player(1)
	local player_unit = player and player.player_unit
	local wp = player_unit and Unit.world_position(player_unit, 1)
	local player_pos = wp and Vector3(wp.x, wp.y, wp.z) or nil

	-- go through enemy_cache and perform updates...
	for i = 1, to_process do
		local unit = temp[i]

		if player_pos and Unit_alive(unit) then
			local entry = mod.enemy_cache[unit]

			if not entry then
				goto continue_enemy_loop
			end

			local wp = Unit.world_position(unit, 1)
			if wp then
				entry.pos = Vector3(wp.x, wp.y, wp.z)
			else
				goto continue_enemy_loop
			end
			local pos = entry.pos

			local dx = pos.x - player_pos.x
			local dy = pos.y - player_pos.y
			local dz = pos.z - player_pos.z
			local dist_sq = dx * dx + dy * dy + dz * dz

			-- effective max distance (individual overrides replace global)
			local breed_name = entry.breed_name
			local effective_max_dist_sq = fs.draw_distance * fs.draw_distance
			if breed_name then
				if fs.breed_dist_enabled[breed_name] then
					local ind_dist = fs.breed_dist_value[breed_name]
					if ind_dist then
						effective_max_dist_sq = ind_dist * ind_dist
					end
				end
			end

			-- LOD cutoff
			if dist_sq > effective_max_dist_sq then
				goto continue_enemy_loop
			end
		end

		if mod.enemy_cache[unit] then
			local entry = mod.enemy_cache[unit]

			if not entry.seen then
				goto continue_enemy_loop
			end

			mod.update_enemy_markers(entry, t)

			if fs.outlines_enable then
				mod.update_enemy_outlines(entry)
			end

			if fs.healthbar_enable or fs.show_damage_numbers then
				mod.update_enemy_healthbars(entry, t)
			end

			if fs.debuff_enable then
				mod.update_enemy_debuffs(entry, t)
			end

			mod.update_special_attack_detection(entry)
		end

		::continue_enemy_loop::
	end

	-- Apply distance / stacking fade to all active markers
	if fs.enable_depth_fading then
		mod.apply_marker_fade(self)
	end
	mod.remove_dead()
end

mod.get_unit_breed = function(unit)
	if not mod.detect_alive(unit) then
		return nil
	end

	local unit_data_extension = ScriptUnit_has_extension(unit, "unit_data_system")

	if not unit_data_extension then
		return nil
	end

	return unit_data_extension:breed()
end

mod.get_breed_tags = function(unit)
	local breed = mod.get_unit_breed(unit)

	if breed and breed.tags then
		return breed.tags
	end

	return nil
end

-- Tags are ordered from priority (Top to bottom)
-- so first match is what will be returned.
-- breed points to the breed tags list, get from mod.get_breed_tags(unit)
mod.find_breed_category = function(unit)
	if unit then
		if mod.is_vanguard(unit) then
			return "shield"
		end

		local tags = mod.get_breed_tags(unit) or {}
		if tags.horde or tags.roamer then
			return "horde"
		elseif tags.captain or tags.cultist_captain then
			return "captain"
		elseif tags.witch then
			return "witch"
		elseif tags.monster then
			return "monster"
		elseif tags.disabler then
			return "disabler"
		elseif tags.special and tags.sniper then
			return "sniper"
		elseif tags.elite and tags.far or tags.special and tags.far or tags.elite and tags.close then
			return "far"
		elseif tags.elite then
			return "elite"
		elseif tags.special then
			return "special"
		else
			return "enemy"
		end
	end
end

-- Returns true if the unit is a weakened boss (spawned with reduced max health).
mod.is_weakened = function(unit, breed)
	local breed = breed or mod.get_unit_breed(unit)

	if not breed or not breed.is_boss or breed.ignore_weakened_boss_name then
		return false
	end

	local health_extension = ScriptUnit_has_extension(unit, "health_system")

	if not health_extension then
		return false
	end

	local ok, max_health = pcall(health_extension.max_health, health_extension)

	if not ok or not max_health then
		return false
	end

	local difficulty = Managers.state.difficulty

	if not (breed.name and difficulty) then
		return false
	end

	local initial_max_health = math.floor(difficulty:get_minion_max_health(breed.name))

	if max_health < initial_max_health then
		return true
	end

	local ok_havoc, parsed_havoc = pcall(function()
		return difficulty:get_parsed_havoc_data()
	end)

	if ok_havoc and parsed_havoc then
		local ok_game_mode, game_mode = pcall(function()
			return Managers.state.game_mode:game_mode()
		end)

		if ok_game_mode and game_mode and game_mode.extension then
			local ok_havoc_ext, havoc_extension = pcall(function()
				return game_mode:extension("havoc")
			end)

			if ok_havoc_ext and havoc_extension then
				local ok_value, havoc_health_override_value = pcall(function()
					return havoc_extension:get_modifier_value("modify_monster_health")
				end)

				if ok_value and havoc_health_override_value then
					local multiplied_max_health = initial_max_health + initial_max_health * havoc_health_override_value

					if max_health < multiplied_max_health then
						return true
					end
				end
			end
		end
	end

	return false
end

-- Returns true if the unit currently has any active debuff tracked by the mod
mod.unit_has_active_debuff = function(unit)
	if not unit or not mod.debuffs then
		return false
	end

	local buff_extension = ScriptUnit_has_extension(unit, "buff_system")
	if not buff_extension then
		return false
	end

	local ok, keywords = pcall(function()
		return buff_extension:keywords()
	end)
	if ok and keywords then
		for name, _ in pairs(keywords) do
			if mod.debuffs[name] then
				return true
			end
		end
	end

	local ok2, buffs = pcall(function()
		return buff_extension:buffs()
	end)
	if ok2 and buffs then
		for i = 1, #buffs do
			local buff = buffs[i]
			local ok3, name = pcall(function()
				return buff:template_name()
			end)
			if ok3 and name and mod.debuffs[name] then
				return true
			end
		end
	end

	return false
end
