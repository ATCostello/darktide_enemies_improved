local mod = get_mod("enemies_improved")
mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/enemies_improved_localization")

local table_remove = table.remove
local table_index_of = table.index_of

-- Cache
local Managers = Managers
mod.enemy_healthbars = mod.enemy_healthbars or {}
mod.marked_dead = mod.marked_dead or {}

local fs = mod.frame_settings

local function _on_ei_marker_created(marker_id, entry, unit)
	mod._on_ei_marker_created(marker_id, entry, unit)
end

-----------------------------------------------------------------------
-- Enemy healthbars
-----------------------------------------------------------------------
local Managers_event = Managers.event

mod.update_enemy_healthbars = function(entry, t)
	-- clear stuck pending state after short time
	if entry._ei_marker_pending and entry._ei_marker_pending_t then
		if t - entry._ei_marker_pending_t > 2 then
			entry._ei_marker_pending = nil
		end
	end

	if not fs.healthbar_enable and not fs.show_damage_numbers then
		return
	end

	if fs.healthbar_only_in_meatgrinder then
		local current_level = Managers.state.mission and Managers.state.mission:mission()
		if
			not (current_level and current_level.game_mode_name and current_level.game_mode_name == "shooting_range")
		then
			return
		end
	end

	local breed_name = entry.breed_name
	local is_horde = entry.is_horde
	local individual_state = breed_name and fs.breed_healthbar_force and fs.breed_healthbar_force[breed_name]
	local horde_group = entry.breed_type
	if not mod.is_horde_group(horde_group) then
		horde_group = "melee_horde"
	end
	local group_state = is_horde and fs.breed_type_healthbar_enabled and fs.breed_type_healthbar_enabled[horde_group]
	local unit = entry.unit
	local clusters_enable = fs.horde_clusters_enable

	local effective = individual_state
	if effective ~= "true_override" and effective ~= "false_override" then
		effective = group_state
	end

	if effective == "false_override" and not fs.force_on_in_training then
		return
	end

	if is_horde and (not fs.horde_enable and not clusters_enable) and effective ~= "true_override" then
		if not (fs.hb_show_when_debuffed and mod.unit_has_active_debuff(unit, t)) then
			return
		end
	end

	if clusters_enable and is_horde then
		local cluster = mod.get_horde_cluster_for_unit(unit)

		if entry._ei_marker_created then
			if not cluster or cluster.rep_unit ~= unit then
				--local marker_id = mod.enemy_healthbars[unit] or (entry.marker and entry.marker.id)
				--if marker_id then
				--	Managers_event:trigger("remove_world_marker", marker_id)
				--end
				mod.enemy_healthbars[unit] = nil
				--mod.enemy_markers[unit] = nil
				--mod.enemy_debuffs[unit] = nil
				--entry._ei_marker_created = false
				--entry._ei_marker_pending = nil
				--entry.marker = nil
				return
			end
		end
	end

	if entry._ei_marker_created or entry._ei_marker_pending then
		return
	end

	if clusters_enable and is_horde then
		local cluster = mod.get_horde_cluster_for_unit(unit)

		-- If clustering is enabled but no cluster yet, DO NOT create bars
		if not cluster then
			return
		end

		-- Only the representative unit is allowed to create a healthbar
		if cluster.rep_unit ~= unit then
			return
		end

		-- Prevent duplicate creation for same cluster
		if cluster._healthbar_created then
			return
		end
	end

	local enemy_healthbars = mod.enemy_healthbars
	local marked_dead = mod.marked_dead

	if enemy_healthbars[unit] then
		return
	end

	if marked_dead[unit] and not mod.detect_alive(unit) then
		return
	end

	entry._ei_marker_pending = true
	entry._ei_marker_pending_t = t

	Managers_event:trigger("add_world_marker_unit", "enemies_improved", unit, function(marker_id)
		_on_ei_marker_created(marker_id, entry, unit)

		-- Mark cluster as having a healthbar
		if clusters_enable and is_horde then
			local cluster = mod.get_horde_cluster_for_unit(unit)
			if cluster then
				cluster._healthbar_created = true
				cluster._healthbar_marker_id = marker_id
			end
		end
	end)
end
