local mod = get_mod("enemies_improved")
mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/enemies_improved_localization")

-- Cache
local Managers = Managers
mod.enemy_markers = mod.enemy_markers or {}
mod.marked_dead = mod.marked_dead or {}

local function _on_ei_marker_created(marker_id, entry, unit)
	mod._on_ei_marker_created(marker_id, entry, unit)
end

-------------------------------------------------------------------
-- Enemy Markers
-------------------------------------------------------------------
mod.update_enemy_markers = function(entry, t)
	local fs = mod.frame_settings
	local unit = entry.unit

	if not unit then
		return
	end

	-- Safety: clear stuck pending state after short time
	if entry._ei_marker_pending and entry._ei_marker_pending_t then
		if t - entry._ei_marker_pending_t > 2 then
			entry._ei_marker_pending = nil
		end
	end

	local unit_data_extension = ScriptUnit.extension(unit, "unit_data_system")
	local breed = unit_data_extension and unit_data_extension:breed()
	local enemy_individual = breed and breed.name

	-- Check individual toggle (cached in fs)
	local individual_enabled = false
	if enemy_individual then
		if fs.breed_marker_toggle[enemy_individual] == true then
			individual_enabled = true
		end
	end

	-- Allow if global enabled OR individual override enabled
	if not fs.markers_enable and not individual_enabled then
		return
	end

	-- Horde filter
	if entry.is_horde and not fs.markers_horde_enable then
		return
	end

	-- Non-horde filter (elites, specials, monsters, etc.)
	if not entry.is_horde and not fs.markers_non_horde_enable then
		return
	end

	if entry._ei_marker_created or entry._ei_marker_pending then
		return
	end

	local enemy_markers = mod.enemy_markers
	local marked_dead = mod.marked_dead

	if enemy_markers[unit] then
		return
	end

	-- Only block if ACTUALLY dead
	if mod.marked_dead[unit] and not mod.detect_alive(unit) then
		return
	end

	local event_manager = Managers.event
	if not event_manager then
		return
	end

	entry._ei_marker_pending = true
	entry._ei_marker_pending_t = t

	event_manager:trigger("add_world_marker_unit", "enemies_improved", unit, function(marker_id)
		_on_ei_marker_created(marker_id, entry, unit)
	end)
end
