local mod = get_mod("enemies_improved")

local HudHealthBarLogic = require("scripts/ui/hud/elements/hud_health_bar_logic")
local UIHudSettings = require("scripts/settings/ui/ui_hud_settings")
local UIRenderer = require("scripts/managers/ui/ui_renderer")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local BreedQueries = require("scripts/utilities/breed_queries")
local minion_breeds = BreedQueries.minion_breeds_by_name()
local breed_category_cache = {}

local template = {}
local fs = mod.frame_settings

local size = { fs.hb_size_width, fs.hb_size_height }

local min_size = { 0, 0 }

template.size = size

template.min_size = min_size
template.name = "enemy_healthbar"
template.unit_node = "root_point"
template.position_offset = { 0, 0, fs.hb_y_offset }

template.check_line_of_sight = fs.check_line_of_sight
template.max_distance = fs.draw_distance_broadphase or fs.draw_distance
template.screen_clamp = false

local GHOSTBAR_BASE_DURATION = 1.5

template.bar_settings = {
	alpha_fade_delay = 1,
	alpha_fade_duration = 0.6,
	alpha_fade_min_value = 50,
	animate_on_health_increase = true,
	bar_spacing = 0,
	duration_health = 0.1,
	duration_health_ghost = GHOSTBAR_BASE_DURATION,
	health_animation_threshold = 0.1,
}

template.evolve_distance = 1

template.scale_settings = {
	scale_from = 0.4,
	scale_to = 1,
	distance_max = 25,
	distance_min = 5,
}

template.fade_settings = {
	default_fade = 1,
	fade_from = 0,
	fade_to = 1,
	distance_max = template.max_distance,
	distance_min = template.max_distance - template.evolve_distance * 2,
	easing_function = math.easeCubic,
}

-----------------------------------------------------------------------
-- Cached locals / helpers
-----------------------------------------------------------------------

local ScriptUnit_extension = ScriptUnit.extension
local ScriptUnit_has_extension = ScriptUnit.has_extension
local Managers_state = Managers.state
local Managers_player = Managers.player
local Color_color = Color
local Vector3 = Vector3
local Vector3Box = Vector3Box

local math_clamp = math.clamp
local math_lerp = math.lerp
local math_min = math.min
local math_max = math.max
local math_random = math.random
local math_sqrt = math.sqrt
local math_floor = math.floor

local string_format = string.format
local table_remove = table.remove
local table_insert = table.insert
local table_contains = table.contains
local table_index_of = table.index_of
local table_clone = table.clone
local next = next

-----------------------------------------------------------------------
-- Damage numbers config
-----------------------------------------------------------------------

local damage_number_types = table.enum("readable", "floating", "flashy")
template.show_dps = fs.hb_show_dps
template.skip_damage_from_others = true

local hb_damage_number_type = fs.hb_damage_number_type

template.damage_number_settings = {
	add_numbers_together_timer = 1,
	add_numbers_together_timer_flashy = 0,
	crit_color = "orange",
	crit_hit_size_scale = 1.5,
	default_color = "white",
	default_font_size = 16 * fs.text_scale,
	dps_font_size = 22 * fs.text_scale,
	dps_y_offset = -125,
	duration = fs.damage_number_duration,
	expand_bonus_scale = 4,
	expand_duration = 0.2,
	fade_delay = 2,
	first_hit_size_scale = 1.2,
	has_taken_damage_timer_remove_after_time = 5,
	has_taken_damage_timer_y_offset = 34,
	hundreds_font_size = 16 * fs.text_scale,
	max_float_y = 20,
	shrink_duration = 0.5,
	visibility_delay = 2,
	weakspot_color = "yellow",
	x_offset = 0,
	x_offset_between_numbers = 14 * fs.text_scale * 3,
	y_offset = 0,
	flashy_font_size_dmg_multiplier = { 1, 1.2 },
	flashy_font_size_dmg_scale_range = { 15, 50 },
}

local previous_damage_taken = {}
local last_damaged_time = {}
local peak_cluster_max_by_rep = {}
local damage_number_pool = {}
mod.damage_number_pool = damage_number_pool

if mod.DEBUG then
	local mem = mod.mem_profile
	mem.track("healthbar.previous_damage_taken", previous_damage_taken)
	mem.track("healthbar.last_damaged_time", last_damaged_time)
	mem.track("healthbar.peak_cluster_max_by_rep", peak_cluster_max_by_rep)
	mem.track("healthbar.damage_number_pool", damage_number_pool)
end

local armor_type_string_lookup = {
	armored = "loc_weapon_stats_display_armored",
	berserker = "loc_weapon_stats_display_berzerker",
	disgustingly_resilient = "loc_weapon_stats_display_disgustingly_resilient",
	resistant = "loc_glossary_armour_type_resistant",
	super_armor = "loc_weapon_stats_display_super_armor",
	unarmored = "loc_weapon_stats_display_unarmored",
}

mod.latest_damaged_enemies = {}

if mod.DEBUG then
	mod.mem_profile.track("mod.latest_damaged_enemies", mod.latest_damaged_enemies)
end

local function healthbar_enabled_for(unit, breed, breed_type, t)
	local enemy_individual = breed and breed.name

	local individual_state = enemy_individual
		and fs.breed_healthbar_force
		and fs.breed_healthbar_force[enemy_individual]
	local group_state = breed_type and fs.breed_type_healthbar_enabled and fs.breed_type_healthbar_enabled[breed_type]
	local debuffed = fs.hb_show_when_debuffed and mod.unit_has_active_debuff(unit, t)

	local effective = individual_state
	if effective ~= "true_override" and effective ~= "false_override" then
		effective = group_state
	end

	if effective == "false_override" and not fs.force_on_in_training then
		return false
	end

	if mod.is_horde_group(breed_type) then
		local cluster = mod.get_horde_cluster_for_unit and mod.get_horde_cluster_for_unit(unit)

		if cluster and cluster.rep_unit ~= unit then
			return false
		end

		local in_horde_cluster = cluster and fs.horde_clusters_enable and fs.healthbar_enable

		if not fs.horde_enable and not in_horde_cluster and effective ~= "true_override" and not debuffed then
			return false
		end
	end

	return true
end

local function show_dps_for(breed, breed_type)
	local enemy_individual = breed and breed.name
	local individual_state = enemy_individual and fs.breed_show_dps and fs.breed_show_dps[enemy_individual]
	local group_state = breed_type and fs.breed_type_show_dps and fs.breed_type_show_dps[breed_type]

	local effective = individual_state

	if effective ~= "true_override" and effective ~= "false_override" then
		effective = group_state
	end

	if effective == "true_override" then
		return true
	elseif effective == "false_override" then
		return false
	end

	return fs.hb_show_dps
end

-----------------------------------------------------------------------
-- Damage number dispatcher
-----------------------------------------------------------------------

local damage_number_functions =
	mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/templates/healthbars/damage_numbers")
damage_number_functions.init(template)

template.damage_number_function = function(pass, ui_renderer, ui_style, ui_content, position, size)
	damage_number_functions.damage_number_function(pass, ui_renderer, ui_style, ui_content, position, size)
end

template.readable_damage_number_function = function(pass, ui_renderer, ui_style, ui_content, position, size)
	damage_number_functions.readable_damage_number_function(pass, ui_renderer, ui_style, ui_content, position, size)
end

-----------------------------------------------------------------------
-- Widget definition
-----------------------------------------------------------------------
local healthbar_template_definition =
	mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/templates/healthbars/healthbar_template_definition")

template.create_widget_defintion = function(template, scenegraph_id)
	return healthbar_template_definition.create_definition(template, scenegraph_id)
end
-----------------------------------------------------------------------
-- Lifecycle
-----------------------------------------------------------------------

local function is_weakspot(breed, zone)
	local t = breed and breed.hit_zone_weakspot_types
	return t and t[zone]
end

local function safe_was_crit(extension)
	if not extension then
		return false
	end

	local ok, was_crit = pcall(function()
		return extension:was_hit_by_critical_hit_this_render_frame()
	end)

	return ok and was_crit or false
end

local function format_number(n)
	return tostring(n):gsub("%.", ",")
end

local function get_text_option(content, option)
	if not option or option == "nothing" then
		return ""
	end

	local breed_type = content._breed_type or "enemy"
	local breed = content.breed

	if option == "enemy_type" then
		local custom = mod:get("healthbar_" .. tostring(breed_type) .. "_custom_name")

		if type(custom) == "string" and custom ~= "" then
			return custom
		end

		return mod.custom_localize(breed_type) or ""
	elseif option == "enemy_name" then
		local name = mod.enemy_custom_name and mod.enemy_custom_name(breed, breed_type)

		if not name then
			name = ""

			local display_name = breed.display_name

			if display_name then
				local custom = mod.custom_localize(display_name)

				if custom ~= "" and custom:sub(1, 1) ~= "<" then
					name = custom
				else
					name = Localize(display_name) or display_name or ""
				end
			end
		end

		local is_weakened = mod.is_weakened and content.unit and mod.is_weakened(content.unit, breed)
		if is_weakened then
			name = name .. " " .. (mod.custom_localize("weakened_name_suffix") or "(Weakened)")
		end

		if content.in_horde_cluster then
			local cluster_string = name
				.. " "
				.. (mod.custom_localize(content._breed_type) or mod.custom_localize("horde") or "")

			if content.cluster_count then
				cluster_string = cluster_string .. " (x " .. content.cluster_count .. ")"
			end

			return cluster_string
		else
			return name
		end
	elseif option == "armour_type" then
		local armor_type = breed and breed.armor_type
		local armor_type_loc_string = armor_type and armor_type_string_lookup[armor_type] or ""
		local armor_type_text = Localize(armor_type_loc_string)

		if content.last_hit_zone_name then
			local hit_zone_name = content.last_hit_zone_name

			if breed and breed.hitzone_armor_override and breed.hitzone_armor_override[hit_zone_name] then
				armor_type = breed.hitzone_armor_override[hit_zone_name]
			end

			armor_type_loc_string = armor_type and armor_type_string_lookup[armor_type] or ""
			armor_type_text = Localize(armor_type_loc_string)
		end

		return armor_type_text
	elseif option == "health" then
		local health_extension = content.health_extension
		local health_current = content.health_current
		local health_max = content.health_max
		local health_percent = content.health_percent
		local is_dead = true
		local new_text = ""
		local show_toughness = fs.toughness_enabled
			and fs.toughness_text_enabled
			and content.current_toughness
			and content.current_toughness > 0

		if content._last_health_current and content._last_health_max and content._last_damage_value then
			if not fs.hb_text_show_damage then
				if fs.hb_text_show_max_health then
					if show_toughness then
						new_text = ""
							.. math_floor(content.current_toughness)
							.. " / "
							.. math_floor(content.max_toughness)
					else
						new_text = math_floor(content._last_health_current)
							.. " / "
							.. math_floor(content._last_health_max)
					end
				else
					if show_toughness then
						new_text = "" .. math_floor(content.current_toughness)
					else
						new_text = math_floor(content._last_health_current)
					end
				end
			else
				if fs.hb_text_show_max_health then
					if show_toughness then
						new_text = ""
							.. math_floor(content.current_toughness)
							.. " / "
							.. math_floor(content.max_toughness)
							.. " ({#color(255, 255, 50)}-"
							.. math_floor(content._last_damage_value)
							.. "{#reset()})"
					else
						new_text = math_floor(content._last_health_current)
							.. " / "
							.. math_floor(content._last_health_max)
							.. " ({#color(255, 255, 50)}-"
							.. math_floor(content._last_damage_value)
							.. "{#reset()})"
					end
				else
					if show_toughness then
						new_text = ""
							.. math_floor(content.current_toughness)
							.. " ({#color(255, 255, 50)}-"
							.. math_floor(content._last_damage_value)
							.. "{#reset()})"
					else
						new_text = math_floor(content._last_health_current)
							.. " ({#color(255, 255, 50)}-"
							.. math_floor(content._last_damage_value)
							.. "{#reset()})"
					end
				end
			end
		elseif health_current and health_max then
			if fs.hb_text_show_max_health then
				if show_toughness then
					new_text = "" .. math_floor(content.current_toughness) .. " / " .. math_floor(content.max_toughness)
				else
					new_text = math_floor(health_current) .. " / " .. math_floor(health_max)
				end
			else
				if show_toughness then
					new_text = "" .. math_floor(content.current_toughness)
				else
					new_text = math_floor(health_current)
				end
			end
		end

		return new_text
	end
end

local function apply_breed_style(widget, breed, breed_type, scale)
	scale = scale or 1

	local content = widget.content
	local style = widget.style

	-- set frame background
	content.frame = fs.frame_type

	-------------------------------------------------------------------
	-- Icon logic / colors
	-------------------------------------------------------------------

	-- default to hidden
	content.icon_special = false
	content.icon_disabler = false
	content.icon_sniper = false
	content.icon_elite = false
	content.icon_elite_ranged = false
	content.icon_boss = false
	content.icon_witch = false
	content.icon_captain = false
	content.icon_enabled = false
	content.icon_shield = false

	-- get values from data store
	local icon_color = mod.ICON_COLOURS[breed_type]
	local icon_enabled = mod.ICON_SETTINGS[breed_type].enabled
	local icon_full_scale = mod.ICON_SETTINGS[breed_type].scale * fs.healthbar_type_icon_scale
	local icon_scale = mod.ICON_SETTINGS[breed_type].icon_scale
	local icon_glow_colour = mod.ICON_COLOURS["glow"]
	local icon_glow_intensity = mod.ICON_SETTINGS[breed_type].glow_intensity

	local shape_scale = 1
	local shape_y_offset = 0

	-- apply values to relevant icon
	local icon_offset_x_target = 0
	local icon_offset_y_target = 0

	local function apply_icon_settings(content_icon, style_icon)
		if content._last_icon_scale == scale then
			local dx = icon_offset_x_target - (content._last_icon_offset_x or 0)
			local dy = icon_offset_y_target - (content._last_icon_offset_y or 0)

			if dx ~= 0 or dy ~= 0 then
				style_icon.offset[1] = (style_icon.offset[1] or 0) + dx
				style.icon_background1.offset[1] = (style.icon_background1.offset[1] or 0) + dx
				style.icon_background.offset[1] = (style.icon_background.offset[1] or 0) + dx
			end
			style_icon.offset[2] = (style_icon.default_offset[2] or 0) + shape_y_offset + icon_offset_y_target
			style.icon_background1.offset[2] = (style.icon_background1.default_offset[2] or 0)
				+ shape_y_offset
				+ icon_offset_y_target
			style.icon_background.offset[2] = (style.icon_background.default_offset[2] or 0)
				+ shape_y_offset
				+ icon_offset_y_target

			content._last_icon_offset_x = icon_offset_x_target
			content._last_icon_offset_y = icon_offset_y_target
			content._fs_gen = fs._gen

			return content_icon, style_icon
		end

		content._last_icon_scale = scale

		content._last_icon_offset_x = icon_offset_x_target
		content._last_icon_offset_y = icon_offset_y_target

		content_icon = icon_enabled
		content.icon_enabled = content_icon

		-- set colours
		style_icon.color[2] = icon_color[2]
		style_icon.color[3] = icon_color[3]
		style_icon.color[4] = icon_color[4]

		-- apply full scale:

		style_icon.size[1] = ((style_icon.default_size[1] * icon_scale) * icon_full_scale) * scale
		style_icon.size[2] = ((style_icon.default_size[2] * icon_scale) * icon_full_scale) * scale
		style.icon_background1.size[1] = (style.icon_background1.default_size[1] * icon_full_scale) * scale
		style.icon_background1.size[2] = (style.icon_background1.default_size[2] * icon_full_scale) * scale
		style.icon_background.size[1] = (style.icon_background.default_size[1] * icon_full_scale * shape_scale) * scale
		style.icon_background.size[2] = (style.icon_background.default_size[2] * icon_full_scale * shape_scale) * scale

		style_icon.default_size[1] = ((style_icon.default_size[1] * icon_scale) * icon_full_scale) * scale
		style_icon.default_size[2] = ((style_icon.default_size[2] * icon_scale) * icon_full_scale) * scale
		style.icon_background1.default_size[1] = (style.icon_background1.default_size[1] * icon_full_scale) * scale
		style.icon_background1.default_size[2] = (style.icon_background1.default_size[2] * icon_full_scale) * scale
		style.icon_background.default_size[1] = (style.icon_background.default_size[1] * icon_full_scale * shape_scale)
			* scale
		style.icon_background.default_size[2] = (style.icon_background.default_size[2] * icon_full_scale * shape_scale)
			* scale

		style_icon.offset[1] = style_icon.default_offset[1] - (16 * icon_full_scale) * scale + icon_offset_x_target
		style_icon.default_offset[1] = style_icon.default_offset[1] - (16 * icon_full_scale) * scale
		style.icon_background1.offset[1] = style.icon_background1.default_offset[1]
			- (16 * icon_full_scale) * scale
			+ icon_offset_x_target
		style.icon_background1.default_offset[1] = style.icon_background1.default_offset[1]
			- (16 * icon_full_scale) * scale
		style.icon_background.offset[1] = style.icon_background.default_offset[1]
			- (16 * icon_full_scale) * scale
			+ icon_offset_x_target
		style.icon_background.default_offset[1] = style.icon_background.default_offset[1]
			- (16 * icon_full_scale) * scale

		style_icon.offset[2] = (style_icon.default_offset[2] or 0) + shape_y_offset
		style.icon_background1.offset[2] = (style.icon_background1.default_offset[2] or 0) + shape_y_offset
		style.icon_background.offset[2] = (style.icon_background.default_offset[2] or 0) + shape_y_offset

		content._fs_gen = fs._gen

		return content_icon, style_icon
	end

	-- icon background shape
	local shape = mod.ICON_BACKGROUND_SHAPES[fs.healthbar_type_icon_background_shape]
		or mod.ICON_BACKGROUND_SHAPES.hexagon

	shape_scale = shape.scale or 1
	shape_y_offset = shape.y_offset or 0

	content.icon_background_shape_value = shape.value

	if shape.material_values and style.icon_background.material_values then
		local mv = style.icon_background.material_values
		mv.frame = shape.material_values.frame
		mv.icon_mask = shape.material_values.icon_mask
		mv.intensity = shape.material_values.intensity
		mv.saturation = shape.material_values.saturation
	end

	style.icon_background.color[1] = (
		fs.healthbar_type_icon_background_colour and fs.healthbar_type_icon_background_colour[1]
	) or 255
	style.icon_background.color[2] = (
		fs.healthbar_type_icon_background_colour and fs.healthbar_type_icon_background_colour[2]
	) or 15
	style.icon_background.color[3] = (
		fs.healthbar_type_icon_background_colour and fs.healthbar_type_icon_background_colour[3]
	) or 15
	style.icon_background.color[4] = (
		fs.healthbar_type_icon_background_colour and fs.healthbar_type_icon_background_colour[4]
	) or 15

	style.icon_background.offset[2] = (style.icon_background.default_offset[2] or 0) + shape_y_offset
	style.icon_background.default_offset[2] = (style.icon_background.default_offset[2] or 0) + shape_y_offset

	if content._fs_gen ~= fs._gen then
		content._last_icon_scale = nil
	end

	-- do stuff per breed type
	if fs.healthbar_type_icon_enable then
		if breed_type == "far" then
			content.icon_elite_ranged, style.icon_elite_ranged =
				apply_icon_settings(content.icon_elite_ranged, style.icon_elite_ranged)
		end
		if breed_type == "elite" then
			content.icon_elite, style.icon_elite = apply_icon_settings(content.icon_elite, style.icon_elite)
		end
		if breed_type == "special" then
			content.icon_special, style.icon_special = apply_icon_settings(content.icon_special, style.icon_special)
		end
		if breed_type == "disabler" then
			content.icon_disabler, style.icon_disabler = apply_icon_settings(content.icon_disabler, style.icon_disabler)
		end
		if breed_type == "sniper" then
			content.icon_sniper, style.icon_sniper = apply_icon_settings(content.icon_sniper, style.icon_sniper)
		end
		if breed_type == "captain" or breed_type == "cultist_captain" then
			content.icon_captain, style.icon_captain = apply_icon_settings(content.icon_captain, style.icon_captain)
		end
		if breed_type == "witch" then
			content.icon_witch, style.icon_witch = apply_icon_settings(content.icon_witch, style.icon_witch)
		end
		if breed_type == "monster" then
			content.icon_boss, style.icon_boss = apply_icon_settings(content.icon_boss, style.icon_boss)
		end
		if breed_type == "shield" then
			content.icon_shield, style.icon_shield = apply_icon_settings(content.icon_shield, style.icon_shield)
		end
		if mod.is_horde_group(breed_type) then
			content.icon_enabled = false
		end
	end

	-- toughness bar colour
	style.current_toughness.color[2] = fs.toughness_colour[2]
	style.current_toughness.color[3] = fs.toughness_colour[3]
	style.current_toughness.color[4] = fs.toughness_colour[4]
	style.current_toughness_electric.color[2] = fs.toughness_colour[2]
	style.current_toughness_electric.color[3] = fs.toughness_colour[3]
	style.current_toughness_electric.color[4] = fs.toughness_colour[4]

	local bar_color = mod.BREED_COLOURS and mod.BREED_COLOURS[breed_type]
		or mod.BREED_COLOURS and mod.BREED_COLOURS.melee_horde
		or { 255, 255, 0, 0 }

	-- INDIVIDUAL COLOUR OVERRIDES
	-------------------------------------------------------------------

	if breed then
		local enemy_individual = breed.name

		if enemy_individual and fs.breed_healthbar_enabled[enemy_individual] then
			local individual_breed_type = breed_category_cache[enemy_individual]

			if individual_breed_type == nil then
				local breed_settings = minion_breeds[enemy_individual]

				if breed_settings then
					individual_breed_type = mod.find_breed_category_by_tags(breed_settings.tags, enemy_individual)
				end

				breed_category_cache[enemy_individual] = individual_breed_type or false
			end

			if individual_breed_type == breed_type then
				bar_color = mod.BREED_COLOURS_OVERRIDE[enemy_individual] or bar_color
			end
		end
	end

	-- WEAKENED BOSS COLOUR OVERRIDE
	local is_weakened = content.unit and mod.is_weakened and mod.is_weakened(content.unit, breed)

	if fs.healthbar_weakened_enable and is_weakened then
		bar_color = fs.healthbar_weakened_colour
	end

	style.current_health.color[2] = bar_color[2]
	style.current_health.color[3] = bar_color[3]
	style.current_health.color[4] = bar_color[4]

	local ghost_color = style.ghost_bar.color

	if fs.hb_ghostbar_opacity then
		if fs.hb_toggle_ghostbar_colour then
			-- colourful
			ghost_color[2] = bar_color[2] * fs.hb_ghostbar_opacity
			ghost_color[3] = bar_color[3] * fs.hb_ghostbar_opacity
			ghost_color[4] = bar_color[4] * fs.hb_ghostbar_opacity
		else
			-- custom colour (defaults to white)
			local ghost_rgb = fs.hb_ghostbar_colour or { 255, 255, 255, 255 }
			ghost_color[2] = ghost_rgb[2] * fs.hb_ghostbar_opacity
			ghost_color[3] = ghost_rgb[3] * fs.hb_ghostbar_opacity
			ghost_color[4] = ghost_rgb[4] * fs.hb_ghostbar_opacity
		end
	end

	-- update damage number settings
	--template.damage_number_settings
	template.damage_number_settings.duration = fs.damage_number_duration
	template.damage_number_settings.x_offset = (fs.readable_damage_number_x_offset or 0) * fs.hb_size_width
	template.damage_number_settings.x_offset_between_numbers = 16
		* fs.text_scale
		* fs.damage_number_scale
		* 3
		* (fs.readable_damage_number_gap or 1)
	template.damage_number_settings.default_font_size = 16 * fs.text_scale * fs.damage_number_scale
	template.damage_number_settings.hundreds_font_size = 16 * fs.text_scale * fs.damage_number_scale
	template.damage_number_settings.dps_font_size = 18 * fs.text_scale * fs.damage_number_scale
	template.damage_number_settings.expand_bonus_scale = 4 * fs.text_scale * fs.damage_number_scale
	template.show_dps = fs.hb_show_dps
end

local function apply_state_body(widget, scale, alert_active)
	local content = widget.content
	local style = widget.style
	local health_fraction = content.health_fraction
	local health_ghost_fraction = content.health_ghost_fraction
	local breed_type = content._breed_type or "enemy"

	scale = scale or 1
	content.distance_scale = scale

	local size = template.size
	size[1] = fs.hb_size_width
	size[2] = fs.hb_size_height
	local scaled_bar_width = 0

	-- higher ghostbar speed = shorter shrink duration
	template.bar_settings.duration_health_ghost = GHOSTBAR_BASE_DURATION / (fs.hb_ghostbar_speed or 1)

	-- only do healthbar calculations if theyre enabled... Still lets the damage numbers do their thing :)
	if health_fraction and health_ghost_fraction then
		local bar_settings = template.bar_settings
		local spacing = bar_settings.bar_spacing
		local bar_width = template.size[1]
		local bar_height = template.size[2]

		local default_width_offset = -bar_width * 0.5
		scale = scale or 1
		content.scale = scale

		local health_max_style = style.health_max
		--health_max_style.default_size[1] = bar_width * scale
		--health_max_style.size[1] = bar_width * scale
		--health_max_style.size[2] = bar_height * scale

		local current_health_style = style.current_health
		local ghost_bar_style = style.ghost_bar

		local scaled_bar_width = bar_width * scale
		content.scaled_bar_width = scaled_bar_width
		content.scaled_bar_height = bar_height * scale

		local scaled_health_width = scaled_bar_width * health_fraction

		local frame_style = style.frame
		--frame_style.size[1] = (bar_width + 12) * scale

		local ghost_fraction = math_max(health_ghost_fraction - health_fraction, 0)
		local scaled_ghost_width = scaled_bar_width * ghost_fraction
	end

	local icon_glow_colour = mod.ICON_COLOURS.glow
	local icon_glow_intensity = mod.ICON_SETTINGS[breed_type].glow_intensity

	-- apply values to relevant icon
	--local function icon_special_attack(content_icon, style_icon)
	if fs.healthbar_specials_enable and alert_active then
		-- get special colour
		local spec_col = fs.outline_specials_colour

		if not content.alert_healthbar then
			----- TURN ON
			-- set alert glow intensity
			style.icon_background1.default_alpha = 255

			-- set alert glow colour
			style.icon_background1.color[1] = 255
			style.icon_background1.color[2] = spec_col[2]
			style.icon_background1.color[3] = spec_col[3]
			style.icon_background1.color[4] = spec_col[4]
			content.alert_healthbar = true
		elseif content.alert_healthbar and fs.specials_flash then
			----- TURN OFF
			-- set alert glow intensity
			style.icon_background1.default_alpha = 0
			style.icon_background1.color[1] = 0

			content.alert_healthbar = false
		end
	else
		if content.alert_healthbar then
			content.alert_healthbar = false
		end

		-- set alert glow colour
		style.icon_background1.default_alpha = 0
		style.icon_background1.color[1] = 0
		style.icon_background1.color[2] = icon_glow_colour[2]
		style.icon_background1.color[3] = icon_glow_colour[3]
		style.icon_background1.color[4] = icon_glow_colour[4]

		if icon_glow_intensity > 0 then
			content.glow_enabled = true
		else
			content.glow_enabled = false
		end
	end

	--return content_icon, style_icon
	--end

	-- do stuff per breed type
	--[[if fs.healthbar_type_icon_enable then
		if breed_type == "far" then
			content.icon_elite_ranged, style.icon_elite_ranged =
				icon_special_attack(content.icon_elite_ranged, style.icon_elite_ranged)
		end
		if breed_type == "elite" then
			content.icon_elite, style.icon_elite = icon_special_attack(content.icon_elite, style.icon_elite)
		end
		if breed_type == "special" then
			content.icon_special, style.icon_special = icon_special_attack(content.icon_special, style.icon_special)
		end
		if breed_type == "disabler" then
			content.icon_disabler, style.icon_disabler = icon_special_attack(content.icon_disabler, style.icon_disabler)
		end
		if breed_type == "sniper" then
			content.icon_sniper, style.icon_sniper = icon_special_attack(content.icon_sniper, style.icon_sniper)
		end
		if breed_type == "captain" or breed_type == "cultist_captain" then
			content.icon_captain, style.icon_captain = icon_special_attack(content.icon_captain, style.icon_captain)
		end
		if breed_type == "witch" then
			content.icon_witch, style.icon_witch = icon_special_attack(content.icon_witch, style.icon_witch)
		end
		if breed_type == "monster" then
			content.icon_boss, style.icon_boss = icon_special_attack(content.icon_boss, style.icon_boss)
		end
		if mod.is_horde_group(breed_type) then
			content.icon_enabled = false
		end
	end]]

	-------------------------------------------------------------------
	-- Height / healthbar position logic
	-------------------------------------------------------------------

	if fs.hb_text_top_left_01 then
		content.header_text = get_text_option(content, fs.hb_text_top_left_01)
		if
			fs.hb_text_top_left_01 == "health"
			and fs.toughness_text_colour_enabled
			and content.current_toughness
			and content.current_toughness > 0
		then
			style.header_text.text_color[2] = fs.toughness_colour[2]
			style.header_text.text_color[3] = fs.toughness_colour[3]
			style.header_text.text_color[4] = fs.toughness_colour[4]
		else
			style.header_text.text_color[2] = fs.main_colour[2]
			style.header_text.text_color[3] = fs.main_colour[3]
			style.header_text.text_color[4] = fs.main_colour[4]
		end

		style.header_text.text_horizontal_alignment = fs.hb_text_alignment

		--style.header_text.default_size[1] = 500

		local text_alignment = fs.hb_text_alignment or "left"
		style.header_text.text_horizontal_alignment = text_alignment
		if text_alignment == "right" then
			style.header_text.default_offset[1] = fs.hb_size_width * 0.5 - 500
		elseif text_alignment == "center" then
			style.header_text.default_offset[1] = -250
		else
			style.header_text.default_offset[1] = -fs.hb_size_width * 0.5
		end
	end

	if fs.hb_text_bottom_left_01 then
		content.health_counter = get_text_option(content, fs.hb_text_bottom_left_01)
		if
			fs.hb_text_bottom_left_01 == "health"
			and fs.toughness_text_colour_enabled
			and content.current_toughness
			and content.current_toughness > 0
		then
			style.health_counter.text_color[2] = fs.toughness_colour[2]
			style.health_counter.text_color[3] = fs.toughness_colour[3]
			style.health_counter.text_color[4] = fs.toughness_colour[4]
		else
			style.health_counter.text_color[2] = fs.main_colour[2]
			style.health_counter.text_color[3] = fs.main_colour[3]
			style.health_counter.text_color[4] = fs.main_colour[4]
		end
		style.health_counter.text_horizontal_alignment = fs.hb_text_alignment

		--style.health_counter.default_size[1] = 500

		local text_alignment = fs.hb_text_alignment or "left"
		style.health_counter.text_horizontal_alignment = text_alignment
		if text_alignment == "right" then
			style.health_counter.default_offset[1] = fs.hb_size_width * 0.5 - 500
		elseif text_alignment == "center" then
			style.health_counter.default_offset[1] = -250
		else
			style.health_counter.default_offset[1] = -fs.hb_size_width * 0.5
		end
	end

	if fs.hb_text_bottom_left_02 then
		content.armour_type = get_text_option(content, fs.hb_text_bottom_left_02)
		if
			fs.hb_text_bottom_left_02 == "health"
			and fs.toughness_text_colour_enabled
			and content.current_toughness
			and content.current_toughness > 0
		then
			style.armour_type.text_color[2] = fs.toughness_colour[2]
			style.armour_type.text_color[3] = fs.toughness_colour[3]
			style.armour_type.text_color[4] = fs.toughness_colour[4]
		else
			style.armour_type.text_color[2] = fs.main_colour[2]
			style.armour_type.text_color[3] = fs.main_colour[3]
			style.armour_type.text_color[4] = fs.main_colour[4]
		end
		style.armour_type.text_horizontal_alignment = fs.hb_text_alignment

		--style.armour_type.default_size[1] = 500

		local text_alignment = fs.hb_text_alignment or "left"
		style.armour_type.text_horizontal_alignment = text_alignment
		if text_alignment == "right" then
			style.armour_type.default_offset[1] = fs.hb_size_width * 0.5 - 500
		elseif text_alignment == "center" then
			style.armour_type.default_offset[1] = -250
		else
			style.armour_type.default_offset[1] = -fs.hb_size_width * 0.5
		end
	end
end

local function apply_built_scale(widget, marker_scale)
	local content = widget.content
	local style = widget.style

	if fs.healthbar_enable and not content.dead then
		content.hb_built = true
	end
	if fs.show_damage_numbers or content.show_dps then
		content.dn_built = true
	end

	content.distance_scale = marker_scale or 1

	local scale = content.distance_scale * fs.text_scale
	content.scale = scale
	local damage_numbers = style.readable_damage_numbers

	if damage_numbers then
		damage_numbers.font_size = damage_numbers.default_font_size * scale
	end
end

local function push_damage_number(
	widget,
	damage_diff,
	t,
	hit_was_critical,
	hit_was_weakspot,
	dot_only,
	max_health_setting,
	was_critical
)
	local content = widget.content
	local damage_number_settings = template.damage_number_settings
	local damage_numbers = content.damage_numbers
	local latest_damage_number = damage_numbers[#damage_numbers]

	if was_critical == nil then
		was_critical = hit_was_critical
	end

	local should_add = true

	if latest_damage_number then
		local add_numbers_together_timer = fs.hb_damage_number_type == damage_number_types.flashy
				and damage_number_settings.add_numbers_together_timer_flashy
			or damage_number_settings.add_numbers_together_timer

		if add_numbers_together_timer > t - latest_damage_number.start_time then
			should_add = false
		end
	end

	if fs.hb_damage_numbers_add_total then
		content.add_on_next_number = false
	else
		content.add_on_next_number = true
	end

	if fs.show_damage_numbers or fs.hb_text_show_damage then
		if content.add_on_next_number or was_critical or should_add then
			local damage_number = damage_number_pool[#damage_number_pool]
			if damage_number then
				damage_number_pool[#damage_number_pool] = nil
			else
				damage_number = {}
			end
			damage_number.expand_time = 0
			damage_number.time = 0
			damage_number.start_time = t
			damage_number.duration = damage_number_settings.duration
			damage_number.value = damage_diff
			damage_number.expand_duration = damage_number_settings.expand_duration
			damage_number.random_number = math_random()
			damage_number.float_right = math_random() > 0.5
			damage_number.hit_world_position = nil
			damage_number.shrink_start_t = nil
			damage_number.y_position = nil

			damage_number.hit_weakspot = hit_was_weakspot
			damage_number.is_dot = dot_only
			damage_number.was_critical = hit_was_critical
			local dn_index = #damage_numbers + 1
			damage_numbers[dn_index] = damage_number

			-- Prevent runaway memory usage
			if #damage_numbers > 20 then
				local removed = table_remove(damage_numbers, 1)
				damage_number_pool[#damage_number_pool + 1] = removed
			end

			if content.add_on_next_number then
				content.add_on_next_number = nil
			end

			if was_critical then
				content.add_on_next_number = true
			end

			if content.last_hit_world_position then
				damage_number.hit_world_position = Vector3Box(content.last_hit_world_position:unbox())
			end
		else
			latest_damage_number.value = math_clamp(latest_damage_number.value + damage_diff, 0, max_health_setting)
			latest_damage_number.time = 0
			latest_damage_number.expand_time = 0
			latest_damage_number.expand_duration = damage_number_settings.expand_duration
			latest_damage_number.shrink_start_t = nil
			latest_damage_number.y_position = nil
			latest_damage_number.start_time = t

			if not content.last_hit_world_position then
				latest_damage_number.hit_world_position = nil
			end

			latest_damage_number.hit_weakspot = hit_was_weakspot
			latest_damage_number.is_dot = dot_only
			latest_damage_number.was_critical = hit_was_critical
		end
	end

	if not content.damage_has_started then
		content.damage_has_started = true
	end

	content.last_damage_taken_time = t
end

template.get_text_option = get_text_option
template.apply_breed_style = apply_breed_style
template.push_damage_number = push_damage_number

template.apply_state = function(widget, scale, dt, t, alert_active)
	widget.content.draw_hb = true
	apply_state_body(widget, scale, alert_active)

	do
		local content = widget.content
		local style = widget.style
		local alignment = fs.hb_text_alignment or "left"

		local function anchor_text(text_style)
			if not text_style then
				return
			end

			text_style.text_horizontal_alignment = alignment

			--text_style.size[1] = 500
			--text_style.default_size[1] = 500

			if alignment == "right" then
				text_style.offset[1] = fs.hb_size_width * 0.5 - 500
				text_style.default_offset[1] = fs.hb_size_width * 0.5 - 500
			elseif alignment == "center" then
				text_style.offset[1] = -250
				text_style.default_offset[1] = -250
			else
				text_style.offset[1] = -fs.hb_size_width * 0.5
				text_style.default_offset[1] = -fs.hb_size_width * 0.5
			end
		end

		anchor_text(style.header_text)
		anchor_text(style.health_counter)
		anchor_text(style.armour_type)
	end

	apply_built_scale(widget, scale)
end

local function get_initial_distance_scale(marker, template)
	local distance = marker.distance
	local hud = Managers.ui and Managers.ui:get_hud()
	local world_markers = hud and hud:element("HudElementWorldMarkers")

	if not distance and world_markers then
		local camera = world_markers._get_camera and world_markers:_get_camera()

		if not camera and world_markers._parent then
			camera = world_markers._parent:player_camera()
		end

		local position

		if marker.world_position and marker.world_position.unbox then
			position = marker.world_position:unbox()
		elseif marker.unit and Unit.alive(marker.unit) then
			local unit = marker.unit
			local unit_node = template.unit_node
			local node = unit_node and Unit.has_node(unit, unit_node) and Unit.node(unit, unit_node) or 1

			position = Unit.world_position(unit, node)

			if position then
				local offset = template.position_offset

				if offset then
					position.x = position.x + offset[1]
					position.y = position.y + offset[2]
					position.z = position.z + offset[3]
				end
			end
		end

		if camera and position and Camera and Camera.local_position then
			local camera_position = Camera.local_position(camera)

			distance = Vector3.distance(position, camera_position)
		end
	end

	local scale_settings = template and template.scale_settings

	if distance and world_markers and world_markers._get_scale and scale_settings then
		return world_markers:_get_scale(scale_settings, distance)
	end

	return marker.scale or 1
end

template.on_enter = function(widget, marker, template)
	local content = widget.content

	local initial_distance_scale = get_initial_distance_scale(marker, template)
	local initial_scale = initial_distance_scale * (fs.text_scale or 1)

	content.scale = initial_scale
	content.distance_scale = initial_distance_scale

	local style = widget.style

	local function initialise_text_scale(text_style)
		if text_style then
			local font_size = text_style.default_font_size or 16
			text_style.font_size = font_size * initial_distance_scale
		end
	end

	initialise_text_scale(style.header_text)
	initialise_text_scale(style.health_counter)
	initialise_text_scale(style.armour_type)

	template.position_offset[3] = fs.hb_y_offset

	content.hb_built = false
	content.draw_hb = false
	content.dead = false

	content.damage_taken = 0
	content.dps_damage = 0
	content.damage_numbers = {}
	content.spawn_progress_timer = 0

	local unit = marker.unit
	local unit_data_extension = ScriptUnit_extension(unit, "unit_data_system")
	local breed = unit_data_extension and unit_data_extension:breed()

	content.breed = breed
	content.unit_data_extension = unit_data_extension
	content.unit = unit

	local bar_settings = template.bar_settings
	marker.bar_logic = HudHealthBarLogic:new(bar_settings)

	content._breed_type = mod.find_breed_category(unit)
	local breed_type = content._breed_type

	content.special_attack_imminent = false

	content.health_extension = ScriptUnit_has_extension(unit, "health_system")
	content.toughness_extension = ScriptUnit_has_extension(unit, "toughness_system")

	local current_level = Managers.state.mission and Managers.state.mission:mission()

	if current_level and current_level.game_mode_name and current_level.game_mode_name == "shooting_range" then
		content.is_in_shooting_range = true
	else
		content.is_in_shooting_range = false
	end

	apply_breed_style(widget, breed, breed_type, marker.scale)
end

local function _get_network_values(game_session, game_object_id)
	local toughness_damage = GameSession.game_object_field(game_session, game_object_id, "toughness_damage")
	local max_toughness = GameSession.game_object_field(game_session, game_object_id, "toughness")

	return toughness_damage, max_toughness
end

-----------------------------------------------------------------------
-- Main update
-----------------------------------------------------------------------

template.update_function = function(parent, ui_renderer, widget, marker, template, dt, t)
	if not marker or not widget then
		return
	end

	widget._next_update = widget._next_update or 0

	local content = widget.content
	local unit = marker.unit
	local crit_extension = unit and ScriptUnit_has_extension(unit, "health_system")

	if safe_was_crit(crit_extension) then
		content._pending_crit = true
	end

	if t < widget._next_update then
		return
	end

	-- if not on screen or draw == false, throttle heavily....
	if not marker.is_inside_frustum then
		widget._next_update = t + fs.off_screen_throttle_rate
	-- distance based updates
	elseif marker.distance < 50 then
		widget._next_update = t + fs.general_throttle_rate
	elseif marker.distance < 70 then
		widget._next_update = t + fs.general_throttle_rate * 2
	else
		widget._next_update = t + fs.general_throttle_rate * 3
	end

	if not unit then
		content.draw_hb = false
	end

	if not content.draw_hb and not marker.is_inside_frustum then
		content.draw_hb = false
		return
	end

	if fs.healthbar_only_in_meatgrinder then
		local current_level = Managers_state.mission and Managers_state.mission:mission()
		if
			not (current_level and current_level.game_mode_name and current_level.game_mode_name == "shooting_range")
		then
			content.draw_hb = false
			return
		end
	end

	content.draw_hb = true

	local entry = mod.enemy_cache[unit]

	content.show_dps = show_dps_for(content.breed, content._breed_type)

	local is_alive = mod.detect_alive(unit)

	if not is_alive then
		content.draw_hb = false
		content.dead = true
		content.hb_built = false

		if fs.widget_removal_delay > 0 then
			if not content.last_damage_taken_time then
				content.last_damage_taken_time = t
			end
		elseif not content.show_dps then
			return
		end
	end

	local broadphase = fs.draw_distance_broadphase or fs.draw_distance
	if template.max_distance ~= broadphase then
		template.max_distance = broadphase
	end

	local check_los = template.check_line_of_sight
	local line_of_sight_progress = content.line_of_sight_progress or 0

	if check_los then
		if marker.raycast_initialized then
			local raycast_result = marker.raycast_result
			local line_of_sight_speed = 8

			if raycast_result then
				line_of_sight_progress = math_max(line_of_sight_progress - dt * line_of_sight_speed, 0)
			else
				line_of_sight_progress = math_min(line_of_sight_progress + dt * line_of_sight_speed, 1)
			end
		end
	else
		line_of_sight_progress = 1
	end

	-------------------------------------------------------------------
	-- Breed / type
	-------------------------------------------------------------------
	local unit_data_extension = content.unit_data_extension
	if not unit_data_extension then
		unit_data_extension = ScriptUnit_has_extension(unit, "unit_data_system")
		content.unit_data_extension = unit_data_extension
	end
	local breed = content.breed or (unit_data_extension and unit_data_extension:breed())
	content.breed = breed

	local breed_type = content._breed_type or "enemy"

	local group_state = fs.breed_type_healthbar_enabled[breed_type]
	local enemy_individual = breed and breed.name
	local individual_state = enemy_individual and fs.breed_healthbar_force[enemy_individual]

	local effective = individual_state
	if effective ~= "true_override" and effective ~= "false_override" then
		effective = group_state
	end

	if effective == "false_override" and not fs.force_on_in_training then
		content.draw_hb = false
	end

	-------------------------------------------------------------------
	-- Health / Toughness
	-------------------------------------------------------------------

	local health_extension = content.health_extension

	local health_current = 0
	local health_max = 0
	local health_percent = 0
	local is_dead = true

	if health_extension and is_alive then
		health_current = health_extension:current_health() or 0
		health_max = health_extension:max_health() or 0

		if health_current > health_max then
			health_max = health_current
		end

		health_percent = health_extension:current_health_percent() or 0
		is_dead = not health_extension:is_alive()
	elseif health_extension then
		health_max = content.health_max or 0
	end

	-------------------------------------------------------------------
	-- Toughness
	-------------------------------------------------------------------

	local toughness_extension = content.toughness_extension

	local toughness_max = 0
	local toughness_current = 0
	local toughness_fraction = 0
	local toughness_damage = 0

	if toughness_extension and is_alive then
		if toughness_extension.max_toughness then
			-- MinionToughnessExtension
			toughness_max = toughness_extension:max_toughness() or 0
			toughness_damage = toughness_extension:toughness_damage() or 0

			toughness_current = toughness_max - toughness_damage
		else
			-- MinionToughnessHuskExtension
			toughness_damage, toughness_max =
				_get_network_values(toughness_extension._game_session, toughness_extension._game_object_id)

			toughness_damage = toughness_damage or 0
			toughness_max = toughness_max or 0

			toughness_current = toughness_max - toughness_damage
		end

		if toughness_extension.current_toughness_percent then
			toughness_fraction = toughness_extension:current_toughness_percent() or 0
		elseif toughness_max > 0 then
			toughness_fraction = toughness_current / toughness_max
		end
	end

	content.max_toughness = toughness_max
	content.current_toughness = toughness_current
	content.toughness_fraction = toughness_fraction

	-------------------------------------------------------------------
	-- Horde clusters
	-------------------------------------------------------------------
	local cluster = mod.get_horde_cluster_for_unit and mod.get_horde_cluster_for_unit(unit)
	local in_horde_cluster = false

	if cluster and fs.horde_clusters_enable and fs.healthbar_enable then
		in_horde_cluster = true

		if cluster.rep_unit ~= unit then
			content.draw_hb = false
			content.in_horde_cluster = false
		else
			content.in_horde_cluster = in_horde_cluster
		end

		local next_cluster_update = content._next_cluster_update or 0

		if t >= next_cluster_update then
			content._next_cluster_update = t + 0.1 -- 100ms update interval

			local total_current = 0
			local total_max_instant = 0

			local units = cluster.units
			local unit_count = #units
			content.cluster_count = unit_count

			for i = 1, unit_count do
				local u = units[i]
				local entry = mod.enemy_cache[u]

				if entry and entry.health_ext and mod.detect_alive(u) then
					local he = entry.health_ext
					local ok, v = pcall(he.current_health, he)
					if ok then
						total_current = total_current + (v or 0)
					end
					ok, v = pcall(he.max_health, he)
					if ok then
						total_max_instant = total_max_instant + (v or 0)
					end
				end
			end

			content._cluster_cached_current = total_current
			content._cluster_cached_max = total_max_instant
		end

		local total_current = content._cluster_cached_current or 0
		local total_max_instant = content._cluster_cached_max or 0

		local peak = peak_cluster_max_by_rep[unit] or 0
		if total_max_instant > peak then
			peak = total_max_instant
			peak_cluster_max_by_rep[unit] = peak
		end

		if peak > 0 then
			health_current = total_current
			health_max = peak
			health_percent = total_current / peak
		else
			health_current = 0
			health_max = 0
			health_percent = 0
		end
		if cluster.center then
			local c = cluster.center
			local cx, cy, cz = c.x, c.y, c.z
			if cx ~= cx or cy ~= cy or cz ~= cz then
				return
			end
			local rep_unit = cluster.rep_unit
			if rep_unit and Unit.alive(rep_unit) then
				local rp = Unit.world_position(rep_unit, 1)

				local min_z = rp.z + 1.2
				if cz < min_z then
					cz = min_z
				end
			end

			cz = cz + 0.3

			if not marker.world_position then
				marker.world_position = Vector3Box(Vector3(cx, cy, cz))
			else
				local lerp_xy = 0.25
				local lerp_z = 0.1

				local prev_pos

				if content._smoothed_pos then
					prev_pos = content._smoothed_pos:unbox()
				else
					prev_pos = Vector3(cx, cy, cz)
				end

				local smoothed = Vector3(
					prev_pos.x + (cx - prev_pos.x) * lerp_xy,
					prev_pos.y + (cy - prev_pos.y) * lerp_xy,
					prev_pos.z + (cz - prev_pos.z) * lerp_z
				)

				-- store safely
				if not content._smoothed_pos then
					content._smoothed_pos = Vector3Box(smoothed)
				else
					content._smoothed_pos:store(smoothed)
				end

				-- apply to marker
				if not marker.world_position then
					marker.world_position = Vector3Box(smoothed)
				else
					marker.world_position:store(smoothed)
				end
			end
		end
	else
		-- Non-horde or clusters disabled

		peak_cluster_max_by_rep[unit] = nil
	end

	-- if horde individual bars is disabled, but clustered is enabled, only show clustered...
	if entry and entry.is_horde and not fs.horde_enable and fs.horde_clusters_enable and not in_horde_cluster then
		content.draw_hb = false
	end

	local bar_logic = marker.bar_logic

	-- Failsafe percent clamp
	health_percent = health_percent or 0
	health_percent = math_clamp(health_percent, 0, 1)

	if bar_logic then
		bar_logic:update(dt, t, health_percent)
	end

	local health_fraction = 0
	local health_ghost_fraction = 0
	local health_max_fraction = 0

	if bar_logic then
		health_fraction, health_ghost_fraction, health_max_fraction = bar_logic:animated_health_fractions()
	end

	marker.health_fraction = health_fraction
	marker.health_ghost_fraction = health_ghost_fraction

	-- Fallback if animation system fails
	if not health_fraction then
		health_fraction = health_percent
		health_ghost_fraction = health_percent
		health_max_fraction = 1
	end

	-------------------------------------------------------------------
	-- DAMAGE NUMBERS LOGIC
	-------------------------------------------------------------------

	local max_health_setting = health_max
	max_health_setting = (content.breed and content.breed.name and Managers.state.difficulty)
			and Managers.state.difficulty:get_minion_max_health(content.breed.name)
		or health_max

	local total_damage_taken

	if not is_dead and health_extension then
		total_damage_taken = health_extension:total_damage_taken()
	else
		total_damage_taken = max_health_setting or health_max
	end

	local damage_taken_since_last = 0

	if total_damage_taken then
		local prev_damage = previous_damage_taken[unit]

		if prev_damage then
			damage_taken_since_last = math_max(total_damage_taken - prev_damage, 0)
		elseif is_dead then
			damage_taken_since_last = total_damage_taken
		end

		previous_damage_taken[unit] = total_damage_taken
	end

	-- toughness (boss shield damage)
	if content.current_toughness and content.current_toughness > 0 then
		if content.previous_toughness == nil then
			content.previous_toughness = content.current_toughness
		end

		if content.previous_toughness < content.current_toughness then
			content.previous_toughness = content.current_toughness
		elseif content.previous_toughness > content.current_toughness then
			damage_taken_since_last = math_max(content.previous_toughness - content.current_toughness, 0)
			content.previous_toughness = content.current_toughness
		end
	end

	content._marker_world_pos = marker.world_position

	if parent and parent._parent and parent._parent.player_camera then
		content.player_camera = parent._parent:player_camera()
	end

	if health_extension and not is_dead then
		local last_damaging_unit = health_extension:last_damaging_unit()

		if last_damaging_unit then
			content.last_hit_zone_name = health_extension:last_hit_zone_name() or "center_mass"
			content.last_damaging_unit = last_damaging_unit

			local breed_local = content.breed
			local hit_zone_weakspot_types = breed_local and breed_local.hit_zone_weakspot_types

			if is_weakspot(breed_local, content.last_hit_zone_name) then
				content.hit_weakspot = true
			else
				content.hit_weakspot = false
			end

			content.was_critical = content._pending_crit or false
		end

		local last_hit_world_position

		if health_extension.last_hit_world_position then
			last_hit_world_position = health_extension:last_hit_world_position()
		end

		if not last_hit_world_position and mod.hit_positions then
			local hit = mod.hit_positions[unit]

			if hit and (mod.get_time() - hit.time) <= (mod.HIT_POSITION_MAX_AGE or 1) then
				last_hit_world_position = hit.position:unbox()
			end
		end

		if last_hit_world_position then
			local box = content.last_hit_world_position
			if not box then
				content.last_hit_world_position = Vector3Box(last_hit_world_position)
			else
				box:store(last_hit_world_position)
			end
		elseif content.last_hit_world_position and not health_extension.last_hit_world_position then
			content.last_hit_world_position = nil
		end
	end

	local damage_number_settings = template.damage_number_settings

	local show_damage_number = true

	local damage_numbers = content.damage_numbers
	if not damage_numbers then
		damage_numbers = {}
		content.damage_numbers = damage_numbers
	end
	local latest_damage_number = damage_numbers[#damage_numbers]

	if damage_taken_since_last > 0 and health_extension then
		content.visibility_delay = damage_number_settings.visibility_delay
		content.damage_taken = total_damage_taken
		if not is_dead then
			content.dps_damage = (content.dps_damage or 0) + damage_taken_since_last
		end

		if show_damage_number then
			if fs.hb_damage_show_only_latest then
				if healthbar_enabled_for(unit, breed, breed_type, t) then
					-- add new unit to the end
					if not table_contains(mod.latest_damaged_enemies, unit) then
						table_insert(mod.latest_damaged_enemies, unit)
					end
				end

				-- remove oldest entries if we exceed the limit
				while #mod.latest_damaged_enemies > fs.hb_damage_show_only_latest_value do
					table_remove(mod.latest_damaged_enemies, 1)
				end
			end

			local damage_diff = math.ceil(damage_taken_since_last)
			local was_critical = content._pending_crit or safe_was_crit(health_extension)
			local hit_was_weakspot = is_weakspot(content.breed, content.last_hit_zone_name) or false

			push_damage_number(
				widget,
				damage_diff,
				t,
				was_critical or false,
				hit_was_weakspot,
				false,
				max_health_setting,
				was_critical or false
			)
		end

		-------------------------------------------------------------------
		-- Health counter text
		-------------------------------------------------------------------
		if
			content._last_health_current ~= health_current
			or content._last_health_max ~= health_max
			or content._last_damage_value ~= (latest_damage_number and latest_damage_number.value)
		then
			content._last_health_current = health_current
			content._last_health_max = health_max
			content._last_damage_value = latest_damage_number and latest_damage_number.value
		end

		content._pending_crit = nil
	end

	if damage_taken_since_last > 0 and health_extension and is_dead and content.show_dps then
		content.damage_taken = total_damage_taken
		content.dps_damage = (content.dps_damage or 0) + damage_taken_since_last
		content.last_damage_taken_time = t
		if not content.damage_has_started then
			content.damage_has_started = true
		end
	end

	-------------------------------------------------------------------
	-- Health bar / ghost / toughness
	-------------------------------------------------------------------

	content.health_fraction = health_fraction
	content.health_ghost_fraction = health_ghost_fraction
	content.toughness_fraction = toughness_fraction
	content.health_current = health_current
	content.health_max = health_max
	content.health_percent = health_percent

	apply_state_body(widget, marker.scale, entry and entry.alert_outline)

	--end

	-------------------------------------------------------------------
	-- Hide logic / LOS fade
	-------------------------------------------------------------------

	local time_since_last_damage = t - (content.last_damage_taken_time or 0)

	-- remove after dps check / widget removal delay!
	if not is_alive and (not marker.health_fraction or marker.health_fraction == 0) then
		local dead_window = math.max(fs.damage_number_duration or 0, fs.widget_removal_delay or 0)
		if time_since_last_damage > dead_window then
			content.draw_hb = false
			mod.enemy_healthbars[unit] = nil
			marker.remove = true
			local cache_entry = mod.enemy_cache[unit]
			if cache_entry then
				cache_entry.marker = nil
				cache_entry.healthbar = nil
				cache_entry.dot_debuffs = nil
			end
			--Managers.event:trigger("remove_world_marker", marker.id)
		end
	end

	if mod.is_horde_group(breed_type) and not fs.horde_enable and not in_horde_cluster then
		local horde_individual = breed and breed.name
		local individual_state = horde_individual
			and fs.breed_healthbar_force
			and fs.breed_healthbar_force[horde_individual]
		local group_state = fs.breed_type_healthbar_enabled and fs.breed_type_healthbar_enabled[breed_type]

		local effective = individual_state
		if effective ~= "true_override" and effective ~= "false_override" then
			effective = group_state
		end

		local forced_on = effective == "true_override"
			or (fs.hb_show_when_debuffed and mod.unit_has_active_debuff(unit, t))

		if not forced_on then
			content.draw_hb = false
		end
	end

	-- force-on in the training grounds skips the hide-after-no-damage logic (useful for testing)
	local skip_hide_after_no_damage = fs.force_on_in_training or false

	-- enemies with an active debuff keep their healthbar visible to track DOTs
	if not skip_hide_after_no_damage and fs.hb_show_when_debuffed and mod.unit_has_active_debuff(unit, t) then
		skip_hide_after_no_damage = true
	end

	-- per enemy type / individual "always show" overrides also skip the hide-after-no-damage logic
	local enemy_individual = breed and breed.name
	if not skip_hide_after_no_damage then
		if fs.breed_type_healthbar_always_show and fs.breed_type_healthbar_always_show[breed_type] then
			skip_hide_after_no_damage = true
		end
		if fs.breed_healthbar_always_show and fs.breed_healthbar_always_show[enemy_individual] then
			skip_hide_after_no_damage = true
		end
	end

	if not skip_hide_after_no_damage then
		if fs.horde_hide_after_no_damage and mod.is_horde_group(breed_type) and time_since_last_damage > 5 then
			content.draw_hb = false
		end

		if fs.hide_after_no_damage and not mod.is_horde_group(breed_type) and time_since_last_damage > 5 then
			content.draw_hb = false
		end
	end

	if not marker.is_inside_frustum then
		content.draw_hb = false
	end

	if fs.hb_damage_show_only_latest then
		if table_contains(mod.latest_damaged_enemies, unit) then
			if is_alive and healthbar_enabled_for(unit, breed, breed_type, t) then
				content.draw_hb = true
			else
				content.draw_hb = false
			end
		else
			content.draw_hb = false
		end
	end

	if not fs.healthbar_enable then
		content.draw_hb = false
		return
	end

	if content.draw_hb and line_of_sight_progress > 0 then
		apply_built_scale(widget, marker.scale)
	elseif not is_alive then
		apply_built_scale(widget, marker.scale)
		content.hb_built = false
	else
		content.hb_built = false
	end
end

mod._cleanup_unit_health_data = function(unit)
	previous_damage_taken[unit] = nil
	last_damaged_time[unit] = nil
	peak_cluster_max_by_rep[unit] = nil

	if mod.hit_positions then
		mod.hit_positions[unit] = nil
	end
end

local table_clear = table.clear

mod._clear_unit_health_data = function()
	table_clear(previous_damage_taken)
	table_clear(last_damaged_time)
	table_clear(peak_cluster_max_by_rep)
end

return template
