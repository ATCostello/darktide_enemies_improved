local mod = get_mod("enemies_improved")

local UIWidget = require("scripts/managers/ui/ui_widget")

local fs = mod.frame_settings

local _create_definition = function(template, scenegraph_id)
	local size = { fs.hb_size_width, fs.hb_size_height }
	local bar_width = size[1]
	local bar_height = size[2]

	local initial_text_scale = fs.text_scale or 1
	local initial_font_size = 16 * initial_text_scale

	local bar_offset = { -bar_width * 0.5, 0, 0 }

	local function text_slot_visible(content, only_meatgrinder)
		if not fs.hb_enable_text then
			return false
		end

		if only_meatgrinder and not content.is_in_shooting_range then
			return false
		end

		return true
	end

	local icon_style = {
		vertical_alignment = "center",
		horizontal_alignment = "center",
		offset = { -bar_width * 0.5, 0, 4 },
		default_offset = { -bar_width * 0.5, 0, 4 },
		size = { 24, 24 },
		default_size = { 24, 24 },
		color = { 200, 255, 200, 0 },
		default_alpha = 255,
	}

	return UIWidget.create_definition({
		-- METAL FRAME (back plate)
		{
			pass_type = "texture",
			style_id = "frame",
			value = fs.frame_type,
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1] - 2 - (1 * fs.hb_padding_scale), bar_offset[2], 0 },
				default_offset = { bar_offset[1] - 2 - (1 * fs.hb_padding_scale), bar_offset[2], 0 },
				size = {
					bar_width + 4 + (2 * fs.hb_padding_scale),
					bar_height + 4 + (2 * fs.hb_padding_scale),
				},
				default_size = {
					bar_width + 4 + (2 * fs.hb_padding_scale),
					bar_height + 4 + (2 * fs.hb_padding_scale),
				},
				color = { 185, 180, 180, 180 },
				default_alpha = 185,
			},
			change_function = function(content, style)
				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_bar_height = content.scaled_bar_height or 0

				--style.size[1] = scaled_bar_width + 10 + 1 * fs.hb_padding_scale
				--style.size[2] = scaled_bar_height + 6 + 1 * fs.hb_padding_scale
			end,
			visibility_function = function(content)
				if (content.draw_hb == nil or content.draw_hb == true) and fs.hb_enable_bar and fs.frame_type ~= "" then
					return true
				else
					return false
				end
			end,
		}, -- METAL FRAME (back plate)
		{
			pass_type = "rect",
			style_id = "health_max",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 1 },
				default_offset = { bar_offset[1], bar_offset[2], 1 },
				size = { bar_width, bar_height },
				default_size = { bar_width, bar_height },
				color = { 200, 0, 0, 0 },
				default_alpha = 200,
			},
			change_function = function(content, style)
				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_bar_height = content.scaled_bar_height or 0

				style.size[1] = scaled_bar_width
				style.size[2] = scaled_bar_height
			end,
			visibility_function = function(content)
				if (content.draw_hb == nil or content.draw_hb == true) and fs.hb_enable_bar then
					return true
				else
					return false
				end
			end,
		}, -- GHOST DAMAGE
		{
			pass_type = "rect",
			style_id = "ghost_bar",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 2 },
				default_offset = { bar_offset[1], bar_offset[2], 2 },
				size = { bar_width, bar_height },
				default_size = { bar_width, bar_height },
				color = { 255, 120, 40, 40 },
				default_alpha = 255,
			},

			change_function = function(content, style)
				local health_fraction = content.health_fraction or 0
				local health_ghost_fraction = content.health_ghost_fraction or 0

				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_health_width = scaled_bar_width * health_fraction
				local scaled_ghost_width = scaled_bar_width * health_ghost_fraction

				style.size[1] = scaled_ghost_width
				style.offset[1] = -scaled_bar_width * 0.5
			end,

			visibility_function = function(content)
				if
					content.hb_built
					and fs.hb_enable_bar
					and fs.hb_toggle_ghostbar
					and content.health_fraction
					and content.health_ghost_fraction
					and content.health_ghost_fraction > content.health_fraction
				then
					return true
				else
					return false
				end
			end,
		}, -- CURRENT HEALTH (main bar)
		{
			pass_type = "texture",
			value = "content/ui/materials/hud/backgrounds/default_square",
			style_id = "current_health",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 3 },
				default_offset = { bar_offset[1], bar_offset[2], 3 },
				size = { bar_width, bar_height },
				default_size = { bar_width, bar_height },
				color = { 255, 170, 30, 30 },
				default_alpha = 255,
			},
			change_function = function(content, style)
				local health_fraction = content.health_fraction or 0

				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_health_width = scaled_bar_width * health_fraction

				style.size[1] = scaled_health_width
				style.offset[1] = -scaled_bar_width * 0.5
			end,

			visibility_function = function(content)
				if (content.draw_hb == nil or content.draw_hb == true) and fs.hb_enable_bar then
					return true
				else
					return false
				end
			end,
		}, -- CURRENT TOUGHNESS
		{
			pass_type = "texture",
			value = "content/ui/materials/hud/backgrounds/boss_toughness_fill", --boss_health_fill, boss_toughness_fill
			style_id = "current_toughness",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 3 },
				default_offset = { bar_offset[1], bar_offset[2], 3 },
				size = { bar_width, bar_height },
				default_size = { bar_width, bar_height },
				color = { 255, 50, 150, 255 },
				default_alpha = 255,
			},
			change_function = function(content, style)
				local toughness_fraction = content.toughness_fraction or 0

				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_toughness_width = scaled_bar_width * toughness_fraction

				style.size[1] = scaled_toughness_width
				style.offset[1] = -scaled_bar_width * 0.5
			end,

			visibility_function = function(content)
				if
					(content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and fs.toughness_enabled
					and (content.current_toughness and content.current_toughness > 0)
				then
					return true
				else
					return false
				end
			end,
		},
		{
			pass_type = "texture_uv",
			value = "content/ui/materials/bars/heavy/fill_electric", --boss_health_fill, boss_toughness_fill
			style_id = "current_toughness_electric",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 3 },
				default_offset = { bar_offset[1], bar_offset[2], 3 },
				size = { bar_width, bar_height },
				default_size = { bar_width, bar_height },
				color = { 255, 50, 150, 255 },
				default_alpha = 255,
				material_values = {
					progression = 0,
				},
			},
			change_function = function(content, style)
				local toughness_fraction = content.toughness_fraction or 0

				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_toughness_width = scaled_bar_width * toughness_fraction

				style.size[1] = scaled_toughness_width
				style.offset[1] = -scaled_bar_width * 0.5
			end,

			visibility_function = function(content)
				if
					(content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and fs.toughness_electric
					and content.hb_built
					and fs.toughness_enabled
					and (content.current_toughness and content.current_toughness > 0)
				then
					return true
				else
					return false
				end
			end,
		},
		{
			pass_type = "texture_uv",
			value = "content/ui/materials/bars/heavy/frame_effect_electric", --boss_health_fill, boss_toughness_fill
			style_id = "current_toughness_electric2",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 3 },
				default_offset = { bar_offset[1], bar_offset[2], 3 },
				size = { bar_width, bar_height },
				default_size = { bar_width, bar_height },
				color = { 255, 255, 255, 255 },
				default_alpha = 255,
				material_values = {
					progression = 0,
				},
			},
			change_function = function(content, style)
				local toughness_fraction = content.toughness_fraction or 0

				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_toughness_width = scaled_bar_width * toughness_fraction

				style.size[1] = scaled_toughness_width
				style.offset[1] = -scaled_bar_width * 0.5

				style.material_values.progression = content.progress or 0
			end,

			visibility_function = function(content)
				if
					(content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and fs.toughness_electric
					and content.hb_built
					and fs.toughness_enabled
					and (content.current_toughness and content.current_toughness > 0)
				then
					return true
				else
					return false
				end
			end,
		},
		-- toughness end cap bar
		{
			pass_type = "rect",
			style_id = "toughness_end",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 3 },
				default_offset = { bar_offset[1], bar_offset[2], 3 },
				size = { 2, bar_height },
				default_size = { 2, bar_height },
				color = { 225, 255, 255, 255 },
				default_alpha = 225,
			},
			change_function = function(content, style)
				local toughness_fraction = content.toughness_fraction or 0

				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_toughness_width = scaled_bar_width * toughness_fraction
				local scale = content.scale or 1
				local scaled_bar_height = content.scaled_bar_height or style.default_size[2]

				style.offset[1] = -scaled_bar_width * 0.5 + scaled_toughness_width
				style.size[2] = scaled_bar_height
				style.size[1] = 2 * scale
			end,
			visibility_function = function(content)
				if
					(content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and fs.hb_endcaps_enabled
					and content.hb_built
					and fs.toughness_enabled
					and (content.current_toughness and content.current_toughness > 0)
				then
					return true
				else
					return false
				end
			end,
		},
		-- health end cap bar
		{
			pass_type = "rect",
			style_id = "health_end",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 3 },
				default_offset = { bar_offset[1], bar_offset[2], 3 },
				size = { 2, bar_height },
				default_size = { 2, bar_height },
				color = { 225, 255, 255, 255 },
				default_alpha = 225,
			},
			change_function = function(content, style)
				local health_fraction = content.health_fraction or 0

				local scaled_bar_width = content.scaled_bar_width or 0
				local scaled_health_width = scaled_bar_width * health_fraction
				local scale = content.scale or 1
				local scaled_bar_height = content.scaled_bar_height or style.default_size[2]

				style.offset[1] = -scaled_bar_width * 0.5 + scaled_health_width
				style.size[2] = scaled_bar_height
				style.size[1] = 2 * scale
			end,
			visibility_function = function(content)
				-- with the toughness bar off the health endcap goes back to always showing, but it still respects the toggle and the healthbar being hidden
				if
					(content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and fs.hb_endcaps_enabled
					and content.hb_built
					and (
						not fs.toughness_enabled
						or (
							(content.health_fraction and content.health_fraction < 1)
							and (content.current_toughness and content.current_toughness <= 0)
						)
					)
				then
					return true
				else
					return false
				end
			end,
		},
		-- SEGMENT BAR 25%
		{
			pass_type = "rect",
			style_id = "health_segment_25",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1] + (bar_width * 0.25) - 5, bar_offset[2], 4 },
				default_offset = { bar_offset[1] + (bar_width * 0.25) - 5, bar_offset[2], 4 },
				size = { 5, bar_height },
				default_size = { 5, bar_height },
				color = { 200, 0, 0, 0 },
				default_alpha = 200,
			},
			visibility_function = function(content)
				if
					(content.draw_hb == nil or content.draw_hb == true)
					and content.hb_built
					and fs.hb_enable_bar
					and fs.healthbar_segments_enable
				then
					return true
				else
					return false
				end
			end,
		},

		-- SEGMENT BAR 50%
		{
			pass_type = "rect",
			style_id = "health_segment_50",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1] + (bar_width * 0.50) - 2.5, bar_offset[2], 4 },
				default_offset = { bar_offset[1] + (bar_width * 0.50) - 2.5, bar_offset[2], 4 },
				size = { 5, bar_height },
				default_size = { 5, bar_height },
				color = { 200, 0, 0, 0 },
				default_alpha = 200,
			},
			visibility_function = function(content)
				if
					(content.draw_hb == nil or content.draw_hb == true)
					and content.hb_built
					and fs.hb_enable_bar
					and fs.healthbar_segments_enable
				then
					return true
				else
					return false
				end
			end,
		},
		-- SEGMENT BAR 75%
		{
			pass_type = "rect",
			style_id = "health_segment_75",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1] + (bar_width * 0.75) - 2.5, bar_offset[2], 4 },
				default_offset = { bar_offset[1] + (bar_width * 0.75) - 2.5, bar_offset[2], 4 },
				size = { 5, bar_height },
				default_size = { 5, bar_height },
				color = { 200, 0, 0, 0 },
				default_alpha = 200,
			},
			visibility_function = function(content)
				if
					(content.draw_hb == nil or content.draw_hb == true)
					and content.hb_built
					and fs.hb_enable_bar
					and fs.healthbar_segments_enable
				then
					return true
				else
					return false
				end
			end,
		},

		-- SHADOW
		{
			pass_type = "texture",
			style_id = "shading1",
			value = "content/ui/materials/frames/inner_shadow_medium",
			value_id = "shading1",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 5 },
				default_offset = { bar_offset[1], bar_offset[2], 5 },
				size = { bar_width, bar_height },
				default_size = { bar_width, bar_height },
				color = { 200, 80, 80, 80 },
				default_alpha = 200,
			},
			visibility_function = function(content)
				if (content.draw_hb == nil or content.draw_hb == true) and fs.hb_enable_bar then
					return true
				else
					return false
				end
			end,
		}, -- TOP EDGE HIGHLIGHT
		{
			pass_type = "texture",
			style_id = "highlight1",
			value = "content/ui/materials/scrollbars/scrollbar_metal_highlight",
			value_id = "highlight1",
			style = {
				vertical_alignment = "center",
				offset = { bar_offset[1], bar_offset[2], 6 },
				default_offset = { bar_offset[1], bar_offset[2], 6 },
				size = { bar_width, bar_height },
				default_size = { bar_width, bar_height },
				color = { 100, 255, 255, 255 },
				default_alpha = 100,
			},
			visibility_function = function(content)
				if (content.draw_hb == nil or content.draw_hb == true) and fs.hb_enable_bar then
					return true
				else
					return false
				end
			end,
		},
		-- ICON BACKGROUND
		{
			pass_type = "texture",
			style_id = "icon_background",
			value = "content/ui/materials/frames/talents/talent_icon_container",
			value_id = "icon_background_shape_value",
			style = {
				vertical_alignment = "center",
				horizontal_alignment = "center",
				offset = { -bar_width * 0.5, 0, 3 },
				default_offset = { -bar_width * 0.5, 0, 3 },

				size = { 35, 35 },
				default_size = { 35, 35 },

				color = { 255, 15, 15, 15 },
				default_alpha = 255,

				material_values = {
					frame = "content/ui/textures/frames/horde/hex_frame_horde",
					icon_mask = "content/ui/textures/frames/horde/hex_frame_horde_mask",
					intensity = 0,
					saturation = 0.65,
				},
			},
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true) and fs.hb_enable_bar and content.icon_enabled
			end,
		},
		{ -- icon glow
			pass_type = "texture",
			style_id = "icon_background1",
			value = "content/ui/materials/base/ui_default_base",
			style = {
				vertical_alignment = "center",
				horizontal_alignment = "center",
				offset = { -bar_width * 0.5, 0, 2 },
				default_offset = { -bar_width * 0.5, 0, 2 },

				size = { 40, 40 },
				default_size = { 40, 40 },

				color = { 0, 255, 180, 80 },
				default_alpha = 0,
				blend_mode = "add",
				scale_to_material = true,

				material_values = {
					texture_map = "content/ui/textures/frames/horde/hex_frame_horde_glow",
				},
			},
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true) and fs.hb_enable_bar and content.icon_enabled
			end,
		},
		-- ELITE ICON
		{
			pass_type = "texture",
			style_id = "icon_elite",
			value = "content/ui/materials/hud/interactions/icons/enemy_priority",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_elite
			end,
		}, -- BOSS ICON
		{
			pass_type = "texture",
			style_id = "icon_boss",
			value = "content/ui/materials/icons/difficulty/flat/difficulty_skull_damnation",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_boss
			end,
		},
		{ -- DAEMONHOST ICON
			pass_type = "texture",
			style_id = "icon_witch",
			value = "content/ui/materials/hud/icons/speaker",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_witch
			end,
		},
		{ -- CAPTAIN ICON
			pass_type = "texture",
			style_id = "icon_captain",
			value = "content/ui/materials/icons/difficulty/flat/difficulty_skull_auric",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_captain
			end,
		},
		{ -- Ranged elites
			pass_type = "texture",
			style_id = "icon_elite_ranged",
			value = "content/ui/materials/icons/circumstances/assault_01",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_elite_ranged
			end,
		},
		{ -- specialists
			pass_type = "texture",
			style_id = "icon_special",
			value = "content/ui/materials/icons/difficulty/flat/difficulty_skull_uprising",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_special
			end,
		},
		{ -- shield
			pass_type = "texture",
			style_id = "icon_shield",
			value = "content/ui/materials/hud/interactions/icons/void_shield",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_shield
			end,
		},
		{ -- disablers
			pass_type = "texture",
			style_id = "icon_disabler",
			value = "content/ui/materials/icons/generic/exclamation_mark",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_disabler
			end,
		},
		{ -- snipers
			pass_type = "texture",
			style_id = "icon_sniper",
			value = "content/ui/materials/icons/weapons/actions/ads",
			style = icon_style,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and fs.hb_enable_bar
					and content.icon_enabled
					and content.icon_sniper
			end,
		}, -- header text
		{
			pass_type = "text",
			style_id = "header_text",
			value = "",
			value_id = "header_text",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				text_horizontal_alignment = "left",
				text_vertical_alignment = "top",
				offset = { -bar_width * 0.5, -bar_height - 8 * fs.text_scale * fs.hb_gap_padding_scale, 1 },
				default_offset = { -bar_width * 0.5, -bar_height - 8 * fs.text_scale * fs.hb_gap_padding_scale, 1 },
				font_type = mod.font_type,
				font_size = initial_font_size,
				default_font_size = initial_font_size,
				text_color = fs.main_colour or { 220, 220, 220, 220 },
				default_text_color = fs.main_colour or { 220, 220, 220, 220 },

				size = {
					500,
					bar_height + 4 + (2 * fs.hb_padding_scale),
				},
				default_size = {
					500,
					bar_height + 4 + (2 * fs.hb_padding_scale),
				},

				default_alpha = 255,
				drop_shadow = true,
			},
			change_function = function(content, style)
				local scale = content.distance_scale or 1

				style.font_size = initial_font_size * scale
			end,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and text_slot_visible(content, fs.hb_text_top_left_01_only_meatgrinder)
			end,
		}, -- Health text
		{
			pass_type = "text",
			style_id = "health_counter",
			value = "",
			value_id = "health_counter",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				text_horizontal_alignment = "left",
				text_vertical_alignment = "bottom",
				offset = { -bar_width * 0.5, ((bar_height + 16) * fs.text_scale) * fs.hb_gap_padding_scale, 1 },
				default_offset = { -bar_width * 0.5, ((bar_height + 16) * fs.text_scale) * fs.hb_gap_padding_scale, 1 },
				font_type = mod.font_type,
				font_size = initial_font_size,
				default_font_size = initial_font_size,
				text_color = fs.main_colour or { 220, 220, 220, 220 },
				default_text_color = fs.main_colour or { 220, 220, 220, 220 },

				size = {
					500,
					bar_height + 4 + (2 * fs.hb_padding_scale),
				},
				default_size = {
					500,
					bar_height + 4 + (2 * fs.hb_padding_scale),
				},

				drop_shadow = true,
				default_alpha = 255,
			},
			change_function = function(content, style)
				local scale = content.distance_scale or 1

				style.font_size = initial_font_size * scale
			end,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and text_slot_visible(content, fs.hb_text_bottom_left_01_only_meatgrinder)
			end,
		},
		{ -- armour types
			pass_type = "text",
			style_id = "armour_type",
			value = "",
			value_id = "armour_type",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				text_horizontal_alignment = "left",
				text_vertical_alignment = "bottom",
				offset = { -bar_width * 0.5, ((bar_height + 34) * fs.text_scale) * fs.hb_gap_padding_scale, 1 },
				default_offset = { -bar_width * 0.5, ((bar_height + 34) * fs.text_scale) * fs.hb_gap_padding_scale, 1 },
				font_type = mod.font_type,
				font_size = initial_font_size,
				default_font_size = initial_font_size,
				text_color = fs.secondary_colour or { 220, 220, 220, 220 },
				default_text_color = fs.secondary_colour or { 220, 220, 220, 220 },

				size = {
					500,
					bar_height + 4 + (2 * fs.hb_padding_scale),
				},
				default_size = {
					500,
					bar_height + 4 + (2 * fs.hb_padding_scale),
				},

				drop_shadow = true,
				default_alpha = 255,
			},
			change_function = function(content, style)
				local scale = content.distance_scale or 1

				style.font_size = initial_font_size * scale
			end,
			visibility_function = function(content)
				return (content.draw_hb == nil or content.draw_hb == true)
					and text_slot_visible(content, fs.hb_text_bottom_left_02_only_meatgrinder)
			end,
		},
		-- readable damage numbers
		{
			pass_type = "logic",
			style_id = "readable_damage_numbers",
			value = template.readable_damage_number_function,
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				text_horizontal_alignment = "left",
				text_vertical_alignment = "bottom",
				offset = { -bar_width * 0.5, bar_height + 50 * fs.text_scale * fs.hb_gap_padding_scale, 1 },
				default_offset = { -bar_width * 0.5, bar_height + 50 * fs.text_scale * fs.hb_gap_padding_scale, 1 },
				font_type = mod.font_type,
				font_size = 16,
				default_font_size = 16,
				text_color = fs.secondary_colour or { 220, 220, 220, 220 },
				default_text_color = fs.secondary_colour or { 220, 220, 220, 220 },
				size = { bar_width * 4 * fs.text_scale, 20 },
				default_size = { bar_width * 4 * fs.text_scale, 20 },

				drop_shadow = true,
				default_alpha = 255,
			},
			change_function = function(content, style)
				if content.scale then
					if fs.hb_text_bottom_left_02 == "nothing" and fs.hb_text_bottom_left_01 == "nothing" then
						style.offset[2] = (size[2] + 12) * fs.hb_gap_padding_scale * content.scale
					elseif fs.hb_text_bottom_left_02 == "nothing" and fs.hb_text_bottom_left_01 ~= "nothing" then
						style.offset[2] = (size[2] + 34) * fs.hb_gap_padding_scale * content.scale
					else
						style.offset[2] = (size[2] + 50) * fs.hb_gap_padding_scale * content.scale
					end
				end
			end,
			visibility_function = function(content)
				if
					content.dn_built
					and (fs.show_dn_in_range_only and content.is_in_shooting_range or not fs.show_dn_in_range_only)
				then
					return true
				else
					return false
				end
			end,
		},
		-- damage numbers
		{
			pass_type = "logic",
			style_id = "damage_numbers",
			value = template.damage_number_function,
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				text_horizontal_alignment = "left",
				text_vertical_alignment = "bottom",
				offset = {
					-size[1] * 0.5,
					-size[2] * 0.7,
					1,
				},
				font_type = mod.font_type,
				font_size = 30,
				text_color = { 220, 220, 220, 220 },
				default_text_color = { 220, 220, 220, 220 },
				size = { 600, size[2] },
				default_alpha = 255,
			},
			visibility_function = function(content)
				if
					content.dn_built
					and (fs.show_dn_in_range_only and content.is_in_shooting_range or not fs.show_dn_in_range_only)
				then
					return true
				else
					return false
				end
			end,
		},
	}, scenegraph_id)
end

return {
	create_definition = _create_definition,
}
