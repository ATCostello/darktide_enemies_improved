local mod = get_mod("enemies_improved")
mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/enemies_improved_localization")

local Managers_player = Managers.player
local Managers_ui = Managers.ui
local next = next

-----------------------------------------------------------------------
-- Marker Distance * Fade
-----------------------------------------------------------------------
mod.world_to_screen = function(self, world_markers, world_pos)
	local camera = self:_get_camera()

	if not camera then
		return nil
	end

	return Camera.world_to_screen(camera, world_pos)
end

mod.apply_marker_fade = function(self)
	local fs = mod.frame_settings
	local markers_by_id = mod._markers_by_id
	local world_markers

	if markers_by_id then
		world_markers = mod._world_markers
	else
		local ui_manager = Managers_ui
		local hud = ui_manager and ui_manager:get_hud()
		world_markers = hud and hud:element("HudElementWorldMarkers")
		markers_by_id = world_markers and world_markers._markers_by_id
		mod._world_markers = world_markers
	end

	if not world_markers or not markers_by_id then
		return
	end

	local player = Managers_player:local_player(1)
	if not player then
		return
	end

	local player_unit = player.player_unit
	if not player_unit or not mod.detect_alive(player_unit) then
		return
	end

	local camera = world_markers:_get_camera()
	if not camera then
		return
	end

	local sqrt = math.sqrt
	local clamp = math.clamp
	local abs = math.abs

	local cam_pos = Camera.world_position(camera)
	local cam_rot = Camera.world_rotation(camera)
	local cam_forward = Quaternion.forward(cam_rot)

	local wp = Unit.world_position(player_unit, 1)
	if not wp then
		return
	end

	local px, py, pz = wp.x, wp.y, wp.z
	local cx, cy, cz = cam_pos.x, cam_pos.y, cam_pos.z
	local fx, fy, fz = cam_forward.x, cam_forward.y, cam_forward.z

	local draw_distance_base = fs.draw_distance

	local STACK_FADE_FACTOR = 0.9
	local DEPTH_THRESHOLD = 0.05
	local MAX_STACK_DIST_SQ = 100
	local MAX_DEPTH_STACK = 100

	local ALIGNMENT_NEAR = 0.96
	local ALIGNMENT_FAR = 0.96

	local global_opacity = fs.global_opacity or 1

	if fs.adjust_ads_opacity then
		global_opacity = fs.global_opacity
				and ((fs.is_ads and fs.global_opacity * fs.ads_opacity_mult) or fs.global_opacity)
			or (fs.is_ads and 1 * fs.ads_opacity_mult)
			or 1

		if global_opacity > 1 then
			global_opacity = 1
		end
		if global_opacity < 0 then
			global_opacity = 0
		end
	end

	local marker_list = mod._marker_list or {}
	mod._marker_list = marker_list

	for i = #marker_list, 1, -1 do
		marker_list[i] = nil
	end

	-- BUILD MARKER LIST
	for marker_id, marker in next, markers_by_id do
		if marker and marker.unit and mod.detect_alive(marker.unit) then
			local t = marker.type
			if t == "enemies_improved" or t == "enemy_utility_debuff" then
				local wp = Unit.world_position(marker.unit, 1)

				local x, y, z = wp.x, wp.y, wp.z

				local dx = x - px
				local dy = y - py
				local dz = z - pz

				local dist_sq = dx * dx + dy * dy + dz * dz

				local tx = x - cx
				local ty = y - cy
				local tz = z - cz

				local depth = tx * fx + ty * fy + tz * fz

				local idx = #marker_list + 1
				local entry = marker_list[idx] or {}
				entry.marker = marker
				entry.x, entry.y, entry.z = x, y, z
				entry.dist_sq = dist_sq
				entry.depth = depth

				local draw_distance = draw_distance_base
				local cache_entry = mod.enemy_cache[marker.unit]
				if cache_entry and cache_entry.breed_name then
					if fs.breed_dist_enabled[cache_entry.breed_name] then
						local ind_dist = fs.breed_dist_value[cache_entry.breed_name]
						if ind_dist then
							draw_distance = ind_dist
						end
					end
				end
				entry.fade_distance = draw_distance

				marker_list[idx] = entry
			end
		end
	end

	-- SORT
	table.sort(marker_list, function(a, b)
		return a.depth < b.depth
	end)

	-- MAIN LOOP
	for i = 1, #marker_list do
		local data = marker_list[i]
		local marker = data.marker

		local draw_distance = data.fade_distance or draw_distance_base
		local fade_start = draw_distance * 0.9
		local fade_end = draw_distance
		local DIST_FADE_START_SQ = fade_start * fade_start
		local DIST_FADE_END_SQ = fade_end * fade_end

		local fade

		if data.dist_sq >= (DIST_FADE_END_SQ - 0.01) then
			fade = 0
		elseif data.dist_sq > DIST_FADE_START_SQ then
			local t = (data.dist_sq - DIST_FADE_START_SQ) / (DIST_FADE_END_SQ - DIST_FADE_START_SQ)
			fade = (1 - t) * (1 - t)
		else
			fade = 1
		end

		local depth_fade = 1

		for j = 1, i - 1 do
			local front = marker_list[j]

			local dx = front.x - data.x
			local dy = front.y - data.y
			local dz = front.z - data.z

			local dist_sq_between = dx * dx + dy * dy + dz * dz

			if dist_sq_between < MAX_STACK_DIST_SQ then
				local ftx = front.x - cx
				local fty = front.y - cy
				local ftz = front.z - cz

				local dtx = data.x - cx
				local dty = data.y - cy
				local dtz = data.z - cz

				local front_len_sq = ftx * ftx + fty * fty + ftz * ftz
				local data_len_sq = dtx * dtx + dty * dty + dtz * dtz

				if front_len_sq > 0 and data_len_sq > 0 then
					local inv_front_len = 1 / sqrt(front_len_sq)
					local inv_data_len = 1 / sqrt(data_len_sq)

					local alignment = (ftx * dtx + fty * dty + ftz * dtz) * (inv_front_len * inv_data_len)

					local depth_delta = data.depth - front.depth

					if depth_delta > DEPTH_THRESHOLD and depth_delta < MAX_DEPTH_STACK then
						local t = clamp(depth_delta / MAX_DEPTH_STACK, 0, 1)
						local required_alignment = ALIGNMENT_NEAR + (ALIGNMENT_FAR - ALIGNMENT_NEAR) * t

						if alignment > required_alignment then
							local scaled = 1 - (1 - STACK_FADE_FACTOR) * (1 - t) * (1 - t)
							depth_fade = depth_fade * scaled
						end
					end
				end
			end
		end

		local final_alpha = clamp(fade * depth_fade * global_opacity, 0, 1)
		local widget = marker.widget

		if widget then
			if marker.type == "enemies_improved" then
				marker._ei_fade_alpha = final_alpha
				widget.alpha_multiplier = (marker.alpha_multiplier or 1) * final_alpha
			elseif abs((marker._last_alpha or 1) - final_alpha) >= 0.02 then
				marker._last_alpha = final_alpha
				marker.alpha_multiplier = final_alpha

				if widget.style then
					for key, style_data in next, widget.style do
						if key ~= "damage_numbers" then
							if style_data.default_alpha then
								local a = style_data.default_alpha * final_alpha
								if style_data.color then
									style_data.color[1] = a
								end
								if style_data.text_color then
									style_data.text_color[1] = a
								end
							end
						end
					end
				end
			end
		end
	end
end
