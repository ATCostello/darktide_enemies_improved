local mod = get_mod("enemies_improved")
mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/enemies_improved_localization")
local next = next
local string_find = string.find
local string_gsub = string.gsub

local _in_settings_update = false

-----------------------------------------------------------------------
-- Settings changed
-----------------------------------------------------------------------

-- REQUIRES "_type_" AS THAT IS WHERE THE SPECIFIC ENEMY GROUP NAME IS PLACED...
local enemy_type_settings = {
	["outline_type_enable"] = "dont_override",
	["outline_type_colour_R"] = 50,
	["outline_type_colour_G"] = 10,
	["outline_type_colour_B"] = 0,

	["healthbar_type_enable"] = "dont_override",
	["healthbar_type_colour_R"] = 255,
	["healthbar_type_colour_G"] = 0,
	["healthbar_type_colour_B"] = 0,
	["healthbar_type_always_show"] = false,

	["healthbar_icon_type_enable"] = true,
	["healthbar_icon_type_scale"] = 1,
	["healthbar_icon_type_glow_intensity"] = 1,
	["healthbar_icon_type_colour_R"] = 200,
	["healthbar_icon_type_colour_G"] = 150,
	["healthbar_icon_type_colour_B"] = 0,

	["debuff_type_enable"] = "dont_override",

	["healthbar_type_y_offset"] = 0,
	["healthbar_type_y_offset_enabled"] = false,

	["debuff_type_show_on_body_override"] = false,
	["marker_type_enable"] = "dont_override",

	["healthbar_type_show_dps"] = "dont_override",

	["healthbar_type_custom_name"] = "",

	["reset_type_to_default"] = false,
}

-- REQUIRES "_individual_" AS THAT IS WHERE THE SPECIFIC ENEMY NAME IS PLACED...
local enemy_override_settings = {

	["markers_individual_toggle"] = "dont_override",
	["healthbar_individual_enable"] = false,
	["healthbar_individual_force"] = "dont_override",
	["healthbar_individual_always_show"] = false,
	["healthbar_individual_colour_R"] = 255,
	["healthbar_individual_colour_G"] = 0,
	["healthbar_individual_colour_B"] = 0,

	["outline_individual_enable"] = "dont_override",
	["outline_individual_colour_R"] = 255,
	["outline_individual_colour_G"] = 50,
	["outline_individual_colour_B"] = 10,

	["distance_individual_enable"] = false,
	["distance_individual_value"] = 30,

	["outline_distance_individual_enable"] = false,
	["outline_distance_individual_value"] = 30,

	["debuff_individual_enable"] = "dont_override",

	["healthbar_individual_y_offset"] = 0,
	["healthbar_individual_y_offset_enabled"] = false,

	["debuff_individual_show_on_body_override"] = false,

	["healthbar_individual_show_dps"] = "dont_override",

	["healthbar_individual_custom_name"] = "",

	["reset_individual_to_default"] = false,
}

local is_override_setting = function(setting_name)
	return setting_name == "marker_type_enable"
		or setting_name == "markers_individual_toggle"
		or setting_name == "outline_type_enable"
		or setting_name == "healthbar_type_enable"
		or setting_name == "debuff_type_enable"
		or setting_name == "outline_individual_enable"
		or setting_name == "healthbar_individual_force"
		or setting_name == "debuff_individual_enable"
		or setting_name == "healthbar_type_show_dps"
		or setting_name == "healthbar_individual_show_dps"
end

local migrate_override_value = function(setting_name)
	local v = mod:get(setting_name)
	if v == true then
		mod:set(setting_name, "true_override")
	elseif v == false then
		mod:set(setting_name, "dont_override")
	end
end

-- The old single "horde" group was split into "melee_horde" and "ranged_horde". Copy any
-- existing _horde_ group override onto both new groups, then drop the stale key.
local migrate_horde_group_overrides = function()
	for setting_name in next, enemy_type_settings do
		if setting_name ~= "reset_type_to_default" and string_find(setting_name, "_type_", 1, true) then
			local old_key = setting_name:gsub("_type_", "_horde_")
			local old_value = mod:get(old_key)

			if old_value ~= nil then
				local melee_key = setting_name:gsub("_type_", "_melee_horde_")
				local ranged_key = setting_name:gsub("_type_", "_ranged_horde_")

				if mod:get(melee_key) == nil then
					mod:set(melee_key, old_value)
				end

				if mod:get(ranged_key) == nil then
					mod:set(ranged_key, old_value)
				end

				mod:set(old_key, nil)
			end
		end
	end
end

mod.migrate_override_settings = function()
	migrate_horde_group_overrides()

	for setting_name in next, enemy_type_settings do
		if is_override_setting(setting_name) then
			migrate_override_value(setting_name)

			for _, options in next, mod.breed_types do
				local breed = options.value
				if breed and breed ~= "select" then
					migrate_override_value((setting_name:gsub("_type_", "_" .. breed .. "_")))
				end
			end
		end
	end

	for setting_name in next, enemy_override_settings do
		if is_override_setting(setting_name) then
			migrate_override_value(setting_name)

			for _, options in next, mod.breed_names do
				local enemy = options.value
				if enemy and enemy ~= "select" then
					migrate_override_value((setting_name:gsub("_individual_", "_" .. enemy .. "_")))
				end
			end
		end
	end

	if type(mod:get("debuff_horde_global_enable")) ~= "boolean" then
		local legacy = mod:get("debuff_horde_enable")
		if type(legacy) == "boolean" then
			mod:set("debuff_horde_global_enable", legacy)
			mod:set("debuff_horde_enable", nil)
		else
			mod:set("debuff_horde_global_enable", false)
		end
	end

	-- the text alignment dropdown used to store "middle", which is not a valid engine
	-- alignment (the engine only understands "center"). Normalise any legacy value.
	if mod:get("hb_text_alignment") == "middle" then
		mod:set("hb_text_alignment", "center")
	end
end

local clear_group_overrides = function(enemy_type)
	for setting_name in next, enemy_type_settings do
		if setting_name ~= "reset_type_to_default" then
			mod:set((setting_name:gsub("_type_", "_" .. enemy_type .. "_")), nil)
		end
	end
end

local clear_individual_overrides = function(enemy_type)
	for setting_name in next, enemy_override_settings do
		if setting_name ~= "reset_individual_to_default" then
			mod:set((setting_name:gsub("_individual_", "_" .. enemy_type .. "_")), nil)
		end
	end
end

mod.reset_type_to_default = function(enemy_type)
	clear_group_overrides(enemy_type)

	local reset_message = mod.custom_localize("reset_type_to_default_message") or ""
	mod:notify(reset_message:gsub("_type_", "_" .. enemy_type .. "_"))

	mod.init_healthbar_defaults()
end

mod.reset_individual_to_default = function(enemy_type)
	clear_individual_overrides(enemy_type)

	local reset_message = mod.custom_localize("reset_individual_to_default_message") or ""
	mod:notify(reset_message:gsub("_individual_", "_" .. enemy_type .. "_"))

	mod.init_healthbar_defaults()
end

mod.reset_all_overrides = function()
	for _, options in next, mod.breed_types do
		local breed = options.value
		if breed and breed ~= "select" then
			clear_group_overrides(breed)
		end
	end

	for _, options in next, mod.breed_names do
		local enemy = options.value
		if enemy and enemy ~= "select" then
			clear_individual_overrides(enemy)
		end
	end

	local reset_message = mod.custom_localize("reset_all_to_default_message") or ""
	mod:notify(reset_message)
	
	mod.init_healthbar_defaults()

	for setting_name in next, enemy_type_settings do
		mod.update_dmf_settings_colours(setting_name)
	end

	for setting_name in next, enemy_override_settings do
		mod.update_dmf_settings_colours(setting_name)
	end
end

local BreedQueries = require("scripts/utilities/breed_queries")
local minion_breeds = BreedQueries.minion_breeds_by_name()

mod.breed_colour_preset_table = function(preset)
	if preset == "red" then
		return {
			melee_horde = { 255, 255, 40, 40 },
			ranged_horde = { 255, 255, 40, 40 },
			elite = { 255, 255, 40, 40 },
			captain = { 255, 255, 40, 40 },
			disabler = { 255, 255, 40, 40 },
			witch = { 255, 255, 40, 40 },
			monster = { 255, 255, 40, 40 },
			sniper = { 255, 255, 40, 40 },
			far = { 255, 255, 40, 40 },
			special = { 255, 255, 40, 40 },
			enemy = { 255, 255, 40, 40 },
			shield = { 255, 255, 40, 40 },
		}
	end

	-- "colourful" and any unknown / nil preset
	return {
		melee_horde = { 255, 150, 60, 60 },
		ranged_horde = { 255, 150, 60, 60 },
		elite = { 255, 0, 120, 255 },
		captain = { 255, 255, 140, 0 },
		disabler = { 255, 255, 255, 0 },
		witch = { 255, 255, 0, 180 },
		monster = { 255, 180, 0, 255 },
		sniper = { 255, 255, 0, 0 },
		far = { 255, 0, 255, 120 },
		special = { 255, 40, 230, 230 },
		enemy = { 255, 200, 200, 200 },
		shield = { 255, 200, 200, 200 },
	}
end

mod.set_breed_colours = function()
	local bc = mod.BREED_COLOURS
	if not bc then
		bc = {
			melee_horde = { 255, 150, 60, 60 },
			ranged_horde = { 255, 150, 60, 60 },
			elite = { 255, 0, 120, 255 },
			captain = { 255, 255, 140, 0 },
			disabler = { 255, 255, 255, 0 },
			witch = { 255, 255, 0, 180 },
			monster = { 255, 180, 0, 255 },
			sniper = { 255, 255, 0, 0 },
			far = { 255, 0, 255, 120 },
			special = { 255, 40, 230, 230 },
			enemy = { 255, 200, 200, 200 },
			shield = { 255, 200, 200, 200 },
		}
		mod.BREED_COLOURS = bc
	end
	local preset = mod:get("healthbar_colour_preset")
	if preset == "red" then
		bc.melee_horde[1], bc.melee_horde[2], bc.melee_horde[3], bc.melee_horde[4] = 255, 255, 40, 40
		bc.ranged_horde[1], bc.ranged_horde[2], bc.ranged_horde[3], bc.ranged_horde[4] = 255, 255, 40, 40
		bc.elite[1], bc.elite[2], bc.elite[3], bc.elite[4] = 255, 255, 40, 40
		bc.captain[1], bc.captain[2], bc.captain[3], bc.captain[4] = 255, 255, 40, 40
		bc.disabler[1], bc.disabler[2], bc.disabler[3], bc.disabler[4] = 255, 255, 40, 40
		bc.witch[1], bc.witch[2], bc.witch[3], bc.witch[4] = 255, 255, 40, 40
		bc.monster[1], bc.monster[2], bc.monster[3], bc.monster[4] = 255, 255, 40, 40
		bc.sniper[1], bc.sniper[2], bc.sniper[3], bc.sniper[4] = 255, 255, 40, 40
		bc.far[1], bc.far[2], bc.far[3], bc.far[4] = 255, 255, 40, 40
		bc.special[1], bc.special[2], bc.special[3], bc.special[4] = 255, 255, 40, 40
		bc.enemy[1], bc.enemy[2], bc.enemy[3], bc.enemy[4] = 255, 255, 40, 40
		bc.shield[1], bc.shield[2], bc.shield[3], bc.shield[4] = 255, 255, 40, 40
	elseif preset == "colourful" then
		bc.melee_horde[1], bc.melee_horde[2], bc.melee_horde[3], bc.melee_horde[4] = 255, 150, 60, 60
		bc.ranged_horde[1], bc.ranged_horde[2], bc.ranged_horde[3], bc.ranged_horde[4] = 255, 150, 60, 60
		bc.elite[1], bc.elite[2], bc.elite[3], bc.elite[4] = 255, 0, 120, 255
		bc.captain[1], bc.captain[2], bc.captain[3], bc.captain[4] = 255, 255, 140, 0
		bc.disabler[1], bc.disabler[2], bc.disabler[3], bc.disabler[4] = 255, 255, 255, 0
		bc.witch[1], bc.witch[2], bc.witch[3], bc.witch[4] = 255, 255, 0, 180
		bc.monster[1], bc.monster[2], bc.monster[3], bc.monster[4] = 255, 180, 0, 255
		bc.sniper[1], bc.sniper[2], bc.sniper[3], bc.sniper[4] = 255, 255, 0, 0
		bc.far[1], bc.far[2], bc.far[3], bc.far[4] = 255, 0, 255, 120
		bc.special[1], bc.special[2], bc.special[3], bc.special[4] = 255, 40, 230, 230
		bc.enemy[1], bc.enemy[2], bc.enemy[3], bc.enemy[4] = 255, 200, 200, 200
		bc.shield[1], bc.shield[2], bc.shield[3], bc.shield[4] = 255, 200, 200, 200
	else
		bc.melee_horde[1], bc.melee_horde[2], bc.melee_horde[3], bc.melee_horde[4] = 255, 150, 60, 60
		bc.ranged_horde[1], bc.ranged_horde[2], bc.ranged_horde[3], bc.ranged_horde[4] = 255, 150, 60, 60
		bc.elite[1], bc.elite[2], bc.elite[3], bc.elite[4] = 255, 0, 120, 255
		bc.captain[1], bc.captain[2], bc.captain[3], bc.captain[4] = 255, 255, 140, 0
		bc.disabler[1], bc.disabler[2], bc.disabler[3], bc.disabler[4] = 255, 255, 255, 0
		bc.witch[1], bc.witch[2], bc.witch[3], bc.witch[4] = 255, 255, 0, 180
		bc.monster[1], bc.monster[2], bc.monster[3], bc.monster[4] = 255, 180, 0, 255
		bc.sniper[1], bc.sniper[2], bc.sniper[3], bc.sniper[4] = 255, 255, 0, 0
		bc.far[1], bc.far[2], bc.far[3], bc.far[4] = 255, 0, 255, 120
		bc.special[1], bc.special[2], bc.special[3], bc.special[4] = 255, 40, 230, 230
		bc.enemy[1], bc.enemy[2], bc.enemy[3], bc.enemy[4] = 255, 200, 200, 200
		bc.shield[1], bc.shield[2], bc.shield[3], bc.shield[4] = 255, 200, 200, 200
	end
end

mod.healthbar_colour_preset_changed = function()
	mod.set_breed_colours()
	if not mod.BREED_COLOURS_DEFAULT then
		mod.BREED_COLOURS_DEFAULT = table.clone(mod.BREED_COLOURS)
	end

	mod.BREED_COLOURS_DEFAULT = table.clone(mod.BREED_COLOURS)

	for breed, color in next, mod.BREED_COLOURS do
		local r = color[2]
		local g = color[3]
		local b = color[4]

		mod:set("healthbar_" .. breed .. "_colour_R", r)
		mod:set("healthbar_" .. breed .. "_colour_G", g)
		mod:set("healthbar_" .. breed .. "_colour_B", b)
	end
end

mod.init_healthbar_defaults = function()
	mod.set_breed_colours()
	if not mod.BREED_COLOURS_DEFAULT then
		mod.BREED_COLOURS_DEFAULT = table.clone(mod.BREED_COLOURS)
	end

	if mod:get("healthbar_shield_enable") == nil then
		mod:set("healthbar_shield_enable", "false_override")
	end

	-- bar colours
	for breed, color in next, mod.BREED_COLOURS_DEFAULT do
		local r = color[2]
		local g = color[3]
		local b = color[4]

		-- only set if not already saved
		if mod:get("healthbar_" .. breed .. "_colour_R") == nil then
			mod:set("healthbar_" .. breed .. "_colour_R", r)
			mod:set("healthbar_" .. breed .. "_colour_G", g)
			mod:set("healthbar_" .. breed .. "_colour_B", b)
		end
	end

	-- icon settings
	for breed, settings in next, mod.ICON_SETTINGS_DEFAULT do
		if mod:get("healthbar_icon_" .. breed .. "_enable") == nil then
			mod:set("healthbar_icon_" .. breed .. "_enable", settings.enabled)
		end
		if mod:get("healthbar_icon_" .. breed .. "_scale") == nil then
			mod:set("healthbar_icon_" .. breed .. "_scale", settings.scale)
		end
		if mod:get("healthbar_icon_" .. breed .. "_glow_intensity") == nil then
			mod:set("healthbar_icon_" .. breed .. "_glow_intensity", settings.glow_intensity)
		end
	end

	-- icon colours
	for breed, color in next, mod.ICON_COLOURS_DEFAULT do
		local r = color[2]
		local g = color[3]
		local b = color[4]

		-- only set if not already saved
		if mod:get("healthbar_icon_" .. breed .. "_colour_R") == nil then
			mod:set("healthbar_icon_" .. breed .. "_colour_R", r)
			mod:set("healthbar_icon_" .. breed .. "_colour_G", g)
			mod:set("healthbar_icon_" .. breed .. "_colour_B", b)
		end
	end

	-- individual override colours
	for _, options in next, mod.breed_names do
		local enemy_individual = options.value

		if enemy_individual then
			local breed_settings = minion_breeds[enemy_individual]

			if breed_settings then
				local tags = breed_settings.tags
				local breed_type = mod.find_breed_category_by_tags(tags, enemy_individual)

				--if breed_settings.name == "renegade_vanguard" or breed_settings.name == "cultist_vanguard" then
				--	breed_type = "elite"
				--end

				-- healthbar
				for breed, color in next, mod.BREED_COLOURS_DEFAULT do
					if breed_type == breed then
						local r = color[2]
						local g = color[3]
						local b = color[4]

						-- only set if not already saved
						if mod:get("healthbar_" .. enemy_individual .. "_colour_R") == nil then
							mod:set("healthbar_" .. enemy_individual .. "_colour_R", r)
							mod:set("healthbar_" .. enemy_individual .. "_colour_G", g)
							mod:set("healthbar_" .. enemy_individual .. "_colour_B", b)
						end
					end
				end

				-- outlines
				for breed, color in next, mod.OUTLINE_COLOURS_DEFAULT do
					if breed_type == breed then
						local r = color[2]
						local g = color[3]
						local b = color[4]

						-- only set if not already saved
						if mod:get("outline_" .. enemy_individual .. "_colour_R") == nil then
							mod:set("outline_" .. enemy_individual .. "_colour_R", r)
							mod:set("outline_" .. enemy_individual .. "_colour_G", g)
							mod:set("outline_" .. enemy_individual .. "_colour_B", b)
						end
					end
				end
			end
		end
	end
end

mod.update_breed_colours = function()
	mod.set_breed_colours()

	-- BREED GROUPS
	for breed, default_color in next, mod.BREED_COLOURS do
		local r = mod:get("healthbar_" .. breed .. "_colour_R")
		local g = mod:get("healthbar_" .. breed .. "_colour_G")
		local b = mod:get("healthbar_" .. breed .. "_colour_B")
		local a = default_color[1] or 255

		if r and g and b then
			mod.BREED_COLOURS[breed] = { a, r, g, b }
		end
	end

	-- INDIVIDUAL HEALTHBAR OVERRIDES
	for _, options in next, mod.breed_names do
		local enemy_individual = options.value

		if enemy_individual then
			local r = mod:get("healthbar_" .. enemy_individual .. "_colour_R")
			local g = mod:get("healthbar_" .. enemy_individual .. "_colour_G")
			local b = mod:get("healthbar_" .. enemy_individual .. "_colour_B")
			local a = 255

			if r and g and b then
				mod.BREED_COLOURS_OVERRIDE[enemy_individual] = { a, r, g, b }
			end
		end
	end

	-- INDIVIDUAL OUTLINE OVERRIDES
	for _, options in next, mod.breed_names do
		local enemy_individual = options.value

		if enemy_individual then
			r = mod:get("outline_" .. enemy_individual .. "_colour_R")
			g = mod:get("outline_" .. enemy_individual .. "_colour_G")
			b = mod:get("outline_" .. enemy_individual .. "_colour_B")
			local a = 255

			if r and g and b then
				mod.OUTLINE_COLOURS_OVERRIDE[enemy_individual] = { a, r, g, b }
			end
		end
	end
end

mod.update_breed_icons = function()
	-- settings
	for breed, settings in next, mod.ICON_SETTINGS do
		local enabled = mod:get("healthbar_icon_" .. breed .. "_enable")
		local scale = mod:get("healthbar_icon_" .. breed .. "_scale")
		local glow_intensity = mod:get("healthbar_icon_" .. breed .. "_glow_intensity")

		mod.ICON_SETTINGS[breed].enabled = enabled
		mod.ICON_SETTINGS[breed].scale = scale
		mod.ICON_SETTINGS[breed].glow_intensity = glow_intensity
		mod.ICON_SETTINGS[breed].default_glow_intensity = glow_intensity
	end

	-- colours
	for breed, default_color in next, mod.ICON_COLOURS do
		local r = mod:get("healthbar_icon_" .. breed .. "_colour_R")
		local g = mod:get("healthbar_icon_" .. breed .. "_colour_G")
		local b = mod:get("healthbar_icon_" .. breed .. "_colour_B")
		local a = default_color[1] or 255

		if r and g and b then
			mod.ICON_COLOURS[breed][1] = a
			mod.ICON_COLOURS[breed][2] = r
			mod.ICON_COLOURS[breed][3] = g
			mod.ICON_COLOURS[breed][4] = b
		end
	end
end

-- set on game load...
mod.load_debuff_colours = function()
	-- colours
	for group_name, style in next, mod.debuff_styles do
		local r = mod:get("debuff_group_" .. group_name .. "_colour_R")
		local g = mod:get("debuff_group_" .. group_name .. "_colour_G")
		local b = mod:get("debuff_group_" .. group_name .. "_colour_B")
		local a = 255

		if style and style.colour and r and g and b then
			style.colour[1] = a
			style.colour[2] = r
			style.colour[3] = g
			style.colour[4] = b
		end
	end
end

-- update ui sliders to current group...
mod.update_debuff_colours = function(group_name)
	mod:set("debuff_group_colour_R", mod.debuff_styles[group_name].colour[2])
	mod:set("debuff_group_colour_G", mod.debuff_styles[group_name].colour[3])
	mod:set("debuff_group_colour_B", mod.debuff_styles[group_name].colour[4])

	mod.update_dmf_settings_colours("debuff_group_colour_R")
end

-- set group specific settings when sliders change...
mod.set_debuff_colours = function(group_name)
	local r = mod:get("debuff_group_colour_R")
	local g = mod:get("debuff_group_colour_G")
	local b = mod:get("debuff_group_colour_B")
	local a = 255

	mod:set("debuff_group_" .. group_name .. "_colour_R", r)
	mod:set("debuff_group_" .. group_name .. "_colour_G", g)
	mod:set("debuff_group_" .. group_name .. "_colour_B", b)

	if mod.debuff_styles[group_name] and r and g and b then
		mod.debuff_styles[group_name].colour[1] = a
		mod.debuff_styles[group_name].colour[2] = r
		mod.debuff_styles[group_name].colour[3] = g
		mod.debuff_styles[group_name].colour[4] = b
	end
end

mod.update_settings_values = function(setting_id)
	-- GROUP OVERRIDES
	local selected_enemy_type = mod:get("enemy_group")
	if not selected_enemy_type then
		return
	end

	local reset_string = "reset_type_to_default"
	local reset_setting_id = reset_string:gsub("_type_", "_" .. selected_enemy_type .. "_")

	-- Set the enemy type widgets when a group is selected
	for setting_name, default_value in next, enemy_type_settings do
		local type_value = mod:get(setting_name)

		local enemy_type = setting_name:gsub("_type_", "_" .. selected_enemy_type .. "_")
		local enemy_type_value = mod:get(enemy_type)

		if enemy_type_value == nil then
			enemy_type_value = default_value
		end

		-- STORE VALUES WHEN CHANGED
		if setting_id == setting_name then
			if enemy_type_value ~= type_value then
				--mod:error("set " .. tostring(enemy_type) .. " to " .. tostring(type_value))
				mod:set(enemy_type, type_value)
			end
		end

		-- SET UI VALUES WHEN DROPDOWN IS SELECTED...
		if setting_id == "enemy_group" or mod:get(reset_setting_id) == true or setting_id == nil then
			if type_value ~= enemy_type_value then
				--mod:error("LOADED VALUES: " .. tostring(setting_name) .. " to " .. tostring(enemy_type_value))
				mod:set(setting_name, enemy_type_value)
			end
		end
	end

	-- INDIVIDUAL OVERRIDES
	local selected_enemy_individual = mod:get("individual_overrides")
	if not selected_enemy_individual then
		return
	end

	local reset_string = "reset_individual_to_default"
	local reset_setting_id = reset_string:gsub("_individual_", "_" .. selected_enemy_individual .. "_")

	-- Set the enemy individual widgets when a new enemy is selected
	for setting_name, default_value in next, enemy_override_settings do
		local individual_value = mod:get(setting_name)

		local enemy_individual = setting_name:gsub("_individual_", "_" .. selected_enemy_individual .. "_")
		local enemy_individual_value = mod:get(enemy_individual)

		if enemy_individual_value == nil then
			enemy_individual_value = default_value
		end

		-- STORE VALUES WHEN CHANGED
		if setting_id == setting_name then
			if enemy_individual_value ~= individual_value then
				--mod:error("set " .. tostring(enemy_individual) .. " to " .. tostring(individual_value))
				mod:set(enemy_individual, individual_value)
			end
		end

		-- SET UI VALUES WHEN DROPDOWN IS SELECTED...
		if setting_id == "individual_overrides" or mod:get(reset_setting_id) == true or setting_id == nil then
			if individual_value ~= enemy_individual_value then
				--mod:error("LOADED VALUES: " .. tostring(setting_name) .. " to " .. tostring(enemy_individual_value))
				mod:set(setting_name, enemy_individual_value)
			end
		end
	end
end

mod.update_dmf_settings_colours = function(setting_id)
	-- Only trigger for color settings
	if
		string.find(setting_id, "_colour_R")
		or string.find(setting_id, "_colour_G")
		or string.find(setting_id, "_colour_B")
	then
		local dmf = get_mod("DMF")
		local mod_name = mod:get_name()

		-- extract base key (e.g. "marker_colour")
		local base_key = string.gsub(setting_id, "_R$", "")
		base_key = string.gsub(base_key, "_G$", "")
		base_key = string.gsub(base_key, "_B$", "")

		local old_title = mod.custom_localize(base_key)
		local new_title = nil

		-- Recompute localization table
		local updated_localization = mod.apply_colours()

		-- GET CURRENT UPDATED VALUE FROM UPDATED_LOCALIZATION
		for id, data in next, updated_localization do
			if id == base_key then
				local lang = Managers.localization:language()
				local text = data[lang] or data.en

				new_title = text
			end
		end

		if not new_title then
			return
		end

		-- OVERRIDE CURRENT DISPLAYED TEXT VALUES ON THE SETTINGS PAGES IN DMF
		for i, mod_data in next, dmf.options_widgets_data do
			if mod_data[1] and mod_data[1].mod_name == mod_name then
				for j = 1, #mod_data do
					if mod_data[j].setting_id == base_key then
						mod_data[j].title = new_title
						break
					end
				end
			end
		end

		local view = Managers.ui:view_instance("dmf_options_view")

		if
			view
			and view._settings_category_widgets
			and view._settings_category_widgets[mod.custom_localize("mod_name")]
		then
			for _, data in next, view._settings_category_widgets[mod.custom_localize("mod_name")] do
				local widget = data.widget
				if not widget or not widget.content.text then
					break
				end

				local clean = string.gsub(new_title, "{#.-}", "")
				local clean2 = string.gsub(widget.content.text, "{#.-}", "")

				if clean == clean2 then
					if widget.content.entry then
						widget.content.entry.display_name = new_title
					end
					widget.content.text = new_title
					break
				end
			end
		end
	end
end

mod.update_debuff_toggles = function(debuff_name, toggle_state)
	if toggle_state then
		mod.debuffs[debuff_name] = mod.default_debuffs[debuff_name]
	else
		mod.debuffs[debuff_name] = nil
	end
end

mod.load_toggled_debuffs_state = function()
	for _, debuff in next, mod.default_debuffs do
		local debuff_toggle_setting_string = debuff.name .. "_toggle_state"
		local debuff_setting = mod:get(debuff_toggle_setting_string)

		if debuff_setting ~= nil then
			mod.update_debuff_toggles(debuff.name, debuff_setting)
		elseif mod.default_disabled_debuffs[debuff.name] then
			mod.update_debuff_toggles(debuff.name, false)
		end
	end
end

mod.on_setting_changed = function(setting_id)
	if _in_settings_update then
		return
	end
	_in_settings_update = true

	local ok, err = pcall(function()
		mod._on_setting_changed_impl(setting_id)
	end)

	_in_settings_update = false

	if not ok then
		mod:error("on_setting_changed error: " .. tostring(err))
	end
end

mod._on_setting_changed_impl = function(setting_id)
	local fs = mod.frame_settings

	if setting_id == "debuff_toggles" then
		local selected_option = mod:get("debuff_toggles")
		local debuff_toggle_setting_string = selected_option .. "_toggle_state"
		local setting = mod:get(debuff_toggle_setting_string)

		if setting ~= nil then
			mod:set("debuff_selected_enable", setting)
		else
			mod:set("debuff_selected_enable", not mod.default_disabled_debuffs[selected_option])
		end
	end

	if setting_id == "debuff_selected_enable" then
		local selected_option = mod:get("debuff_toggles")
		local selected_toggle_state = mod:get("debuff_selected_enable")
		local debuff_toggle_setting_string = selected_option .. "_toggle_state"

		mod:set(debuff_toggle_setting_string, selected_toggle_state)

		mod.update_debuff_toggles(selected_option, selected_toggle_state)
	end

	if setting_id == "debuff_group_selected" then
		mod.update_debuff_colours(mod:get("debuff_group_selected"))
	end

	if
		setting_id == "debuff_group_colour_R"
		or setting_id == "debuff_group_colour_G"
		or setting_id == "debuff_group_colour_B"
	then
		mod.set_debuff_colours(mod:get("debuff_group_selected"))
	end

	local selected_enemy_type = mod:get("enemy_group")
	if not selected_enemy_type then
		return
	end

	mod.update_settings_values(setting_id)

	local reset_string = "reset_type_to_default"
	local reset_setting_id = reset_string:gsub("_type_", "_" .. selected_enemy_type .. "_")

	-- HANDLE GROUP RESET TO DEFAULT LOGIC...
	if mod:get(reset_setting_id) == true then
		mod.reset_type_to_default(selected_enemy_type)
		mod.update_settings_values(reset_setting_id)
	end

	local selected_enemy_individual = mod:get("individual_overrides")
	local reset_string_individual = "reset_individual_to_default"
	local reset_setting_id_individual = reset_string:gsub("_individual_", "_" .. selected_enemy_individual .. "_")

	-- HANDLE INDIVIDUAL RESET TO DEFAULT LOGIC...
	if mod:get(reset_setting_id_individual) == true then
		--mod.reset_individual_to_default(selected_enemy_individual)
		--mod.update_settings_values(reset_setting_id_individual)
	end

	if setting_id == "healthbar_colour_preset" then
		mod.healthbar_colour_preset_changed()
	end

	mod.update_breed_colours()

	-- Only rebuild outlines when outline-related settings changed
	if
		setting_id == "outlines_enable"
		or string_find(setting_id, "outline_")
		or setting_id == "enemy_group"
		or setting_id == "individual_overrides"
	then
		local outline_settings = require("scripts/settings/outline/outline_settings")
		mod.apply_enemy_outlines(outline_settings)
		mod.remove_all_enemy_outlines()
	end

	-- update breed settings
	mod.update_breed_icons()

	-- clear all caches to reload data with new values
	mod.clear_caches()

	mod.font_type = mod:get("font_type")
	fs.text_scale = mod:get("text_scale")

	if mod:get(reset_setting_id) == true then
		mod:set(reset_setting_id, false)
	end
	if mod:get(reset_setting_id_individual) == true then
		mod:set(reset_setting_id_individual, false)
	end

	-- update colours when the dropdown selectors are changed...
	if setting_id == "individual_overrides" or setting_id == "enemy_group" then
		-- GROUPS
		if setting_id == "enemy_group" then
			for setting_name, default_value in next, enemy_type_settings do
				mod.update_dmf_settings_colours(setting_name)
			end
		end

		if setting_id == "individual_overrides" then
			for setting_name, default_value in next, enemy_override_settings do
				mod.update_dmf_settings_colours(setting_name)
			end
		end
	end

	mod.update_dmf_settings_colours(setting_id)
end

local CLOSING_SETTINGS_VIEWS = {
	dmf_options_view = true,
	options_view = true,
	enemies_improved_editor = true,
}

mod.refresh_settings_close = function()
	mod.clear_caches()
	mod.build_frame_settings()
	mod.remove_all_enemy_outlines()
end

mod:hook_safe(CLASS.UIViewHandler, "close_view", function(self, view_name, ...)
	if CLOSING_SETTINGS_VIEWS[view_name] then
		mod.refresh_settings_close()
	end
end)

local strip_color_codes_and_glyphs = function(s)
	if type(s) ~= "string" then
		return s
	end

	s = s:gsub("{#[^}]+}", "")
	s = s:gsub("{#reset%(%)}", "")
	s = s:gsub("[^\1-\127]", "")
	s = s:gsub("%s%s+", " ")
	s = s:match("^%s*(.-)%s*$")

	return s
end

-- save scroll position
-- Author: Alfthebigheaded
local last_scroll_amount = 0
local last_category = nil

local function is_my_category(self)
	return self._selected_category == mod.custom_localize("mod_name")
		or self._selected_category == mod.custom_localize("mod_name_pizazz")
end

mod:hook_safe(CLASS.BaseView, "on_exit", function(self)
	last_category = nil
end)

mod:hook_safe(CLASS.BaseView, "update", function(self)
	if self.view_name ~= "dmf_options_view" then
		return
	end

	local grid = self._navigation_grids
	if not (grid and grid[2] and grid[2]._scrollbar_widget) then
		return
	end

	local scrollbar_widget = grid[2]._scrollbar_widget
	local current_category = self._selected_category
	local in_my_category = is_my_category(self)

	--  Detect category switch into my mod
	if in_my_category and (last_category ~= current_category or last_category == nil) then
		scrollbar_widget.content.scroll_value = last_scroll_amount
		scrollbar_widget.content.value = last_scroll_amount
	end

	--  Always track scroll while inside my mod
	if in_my_category then
		if grid[2]._scroll_progress and last_scroll_amount ~= grid[2]._scroll_progress then
			last_scroll_amount = grid[2]._scroll_progress
		end
	end

	last_category = current_category
end)

-----------------------------------------------------------------------
-- Native settings API (editor)
-----------------------------------------------------------------------
mod.settings_api = mod.setting_schema
		and mod:io_dofile("enemies_improved/scripts/mods/enemies_improved/utils/settings_api")
	or nil
