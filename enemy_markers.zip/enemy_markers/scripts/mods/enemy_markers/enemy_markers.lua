local mod = get_mod("enemy_markers")

mod:io_dofile("enemy_markers/scripts/mods/enemy_markers/enemy_markers_localization")
local EnemyMarkersTemplate = mod:io_dofile("enemy_markers/scripts/mods/enemy_markers/enemy_markers_template")
local EnemyHealthbarTemplate = mod:io_dofile("enemy_markers/scripts/mods/enemy_markers/enemy_healthbar_template")
local EnemyDebuffTemplate = mod:io_dofile("enemy_markers/scripts/mods/enemy_markers/enemy_debuff_template")
local EnemyUtilityDebuffTemplate =
	mod:io_dofile("enemy_markers/scripts/mods/enemy_markers/enemy_utility_debuff_template")
local HudElementWorldMarkers = require("scripts/ui/hud/elements/world_markers/hud_element_world_markers")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIScenegraph = require("scripts/managers/ui/ui_scenegraph")
local HudElementSmartTagging = require("scripts/ui/hud/elements/smart_tagging/hud_element_smart_tagging")
local Component = require("scripts/utilities/component")
local MechanismManager = require("scripts/managers/mechanism/mechanism_manager")

mod.frame_settings = {}
mod._broadphase_results = {}

mod.enemy_cache = {}
mod.enemy_markers = {}
mod.enemy_healthbars = {}
mod.enemy_debuffs = {}
mod.enemy_utility_debuffs = {}

mod.marked_dead = {}
mod.source_unit_cache = mod.source_unit_cache or {}

local MAX_ENEMIES_PER_FRAME = 500
local _enemy_units_temp = {}
local _last_enemy_index = 0

local HORDE_CLUSTER_RADIUS_SQ = 30 ^ 2
local HORDE_MIN_UNITS_FOR_CLUSTER = 20
local _horde_clusters = {}
local _horde_cluster_by_unit = {}

local COLOUR_LOOKUP = {
	Gold = { 255, 232, 188, 109 },
	Silver = { 255, 187, 198, 201 },
	Steel = { 255, 161, 166, 169 },
	Black = { 255, 35, 31, 32 },
	Brass = { 255, 226, 199, 126 },
	Terminal = Color.terminal_background(200, true),
	Default = { 255, 161, 166, 169 },
}

local Managers_player = Managers.player
local Managers_state = Managers.state
local Managers_event = Managers.event
local Managers_ui = Managers.ui
local Managers_time = Managers.time
local Unit_alive = Unit.alive
local ScriptUnit_extension = ScriptUnit.extension
local ScriptUnit_has_extension = ScriptUnit.has_extension
local table_clear = table.clear
local math_lerp = math.lerp
local math_min = math.min
local math_max = math.max
local next = next
local pairs = pairs

-- Marker fade settings
local DIST_FADE_START = 10 -- meters where fade begins
local DIST_FADE_END = 50 -- full fade at draw distance
local MIN_ALPHA = 0.1 -- never fully invisible

-----------------------------------------------------------------------
-- preload resources + reset caches on game state change
-----------------------------------------------------------------------
mod.on_game_state_changed = function(state, state_name)
	mod.on_game_state_changed = function(state, state_name)
		-- ensure packages are loaded
		Managers.package:load("packages/ui/views/inventory_view/inventory_view", "enemy_markers", nil, true)
		Managers.package:load(
			"packages/ui/views/inventory_weapons_view/inventory_weapons_view",
			"enemy_markers",
			nil,
			true
		)
		Managers.package:load(
			"packages/ui/views/inventory_background_view/inventory_background_view",
			"enemy_markers",
			nil,
			true
		)
		Managers.package:load(
			"packages/ui/views/inventory_weapon_details_view/inventory_weapon_details_view",
			"enemy_markers",
			nil,
			true
		)
		Managers.package:load("packages/ui/hud/player_weapon/player_weapon", "enemy_markers", nil, true)
		Managers.package:load(
			"packages/ui/views/inventory_weapon_marks_view/inventory_weapon_marks_view",
			"enemy_markers",
			nil,
			true
		)
		Managers.package:load(
			"packages/ui/views/cosmetics_inspect_view/cosmetics_inspect_view",
			"enemy_markers",
			nil,
			true
		)
		Managers.package:load(
			"packages/ui/views/masteries_overview_view/masteries_overview_view",
			"enemy_markers",
			nil,
			true
		)
		Managers.package:load("packages/ui/views/mastery_view/mastery_view", "enemy_markers", nil, true)
		Managers.package:load("packages/ui/views/dlc_purchase_view/dlc_purchase_view", "enemy_markers", nil, true)

		Managers.package:load("packages/ui/views/talent_builder_view/ogryn", "enemy_markers", nil, true)
		Managers.package:load("packages/ui/views/talent_builder_view/talent_builder_view", "enemy_markers", nil, true)

		Managers.package:load(
			"packages/ui/views/inventory_weapon_details_view/inventory_weapon_details_view",
			"enemy_markers",
			nil,
			true
		)

		-- empty caches
		mod.clear_caches()
	end
end

mod.on_all_mods_loaded = function()
	mod.clear_caches()

	mod.init_healthbar_colour_defaults()
	mod.update_breed_colors()
end

mod:hook_safe(CLASS.HudElementWorldMarkers, "init", function(self)
	-- add new marker templates to templates table
	self._marker_templates[EnemyMarkersTemplate.name] = EnemyMarkersTemplate
	self._marker_templates[EnemyHealthbarTemplate.name] = EnemyHealthbarTemplate
	self._marker_templates[EnemyDebuffTemplate.name] = EnemyDebuffTemplate
	self._marker_templates[EnemyUtilityDebuffTemplate.name] = EnemyUtilityDebuffTemplate

	-- clear caches on markers init
	mod.clear_caches()
end)

-----------------------------------------------------------------------
-- Hook into the markers update to recalculate enemies.
-----------------------------------------------------------------------
mod:hook_safe(CLASS.HudElementWorldMarkers, "update", function(self, dt, t)
	-- throttle updates...
	local update_interval = 0.03 -- 1 is 1 second... do the maths ;)
	update_time = (update_time or 0) + dt

	if update_time > update_interval then
		update_time = 0

		-- Update enemies/markers for this frame
		mod.update_enemies(dt, t)
	end

	-- Hide default health bars (all damage_indicator variants except our custom one)
	local markers = self._markers
	if not markers or #markers == 0 then
		return
	end

	mod.markers = self._markers_by_type

	for i = 1, #markers do
		local marker = markers[i]
		local template = marker and marker.template

		if template then
			local name = template.name
			if name and name ~= "enemy_healthbar" and string.find(name, "damage_indicator", 1, true) then
				marker.draw = false
				marker.alpha_multiplier = 0
			end
		end
	end

	-- Apply distance / stacking fade to all active markers
	mod.apply_marker_fade()
end)

-----------------------------------------------------------------------
-- Frame settings builder
-----------------------------------------------------------------------

local function build_frame_settings(mod, dt)
	local fs = mod.frame_settings

	fs.dt = dt or 0

	-- ADS detection
	local is_ads = false
	local player = Managers_player:local_player(1)
	if player then
		local unit = player.player_unit
		if unit and Unit_alive(unit) then
			local ude = ScriptUnit_extension(unit, "unit_data_system")
			if ude then
				local af = ude:read_component("alternate_fire")
				is_ads = af and af.is_active or false
			end
		end
	end

	fs.is_ads = is_ads

	-- Draw distance
	fs.draw_distance = mod:get("draw_distance")

	-- Feature toggles
	fs.enable = fs.enable or {}
	local enable = fs.enable

	-- GENERAL
	enable.outlines = mod:get("outlines_enable")

	-- MARKERS
	enable.markers = mod:get("markers_enable")
	enable.markers_horde = mod:get("marker_horde_enable") or false

	-- HEALTHBARS
	enable.healthbar = mod:get("healthbar_enable")
	enable.hb_horde = mod:get("hb_horde_enable") or false
	enable.horde_clusters = mod:get("hb_horde_clusters_enable") or false
	enable.healthbar_type_icon = mod:get("healthbar_type_icon_enable") or false

	-- SPECIAL ATTACKS
	enable.marker_specials = mod:get("marker_specials_enable")
	enable.outline_specials = mod:get("outline_specials_enable")
	enable.outline_specials_flash = mod:get("outline_specials_flash")

	-- DEBUFFS
	enable.debuff = mod:get("debuff_enable")
end

mod.enable_enemy_outlines = function(unit, entry)
	if not Unit.alive(unit) then
		return
	end

	local has_outline_system = Managers.state.extension:has_system("outline_system")
	if not has_outline_system then
		return
	end

	local outline_system = Managers.state.extension:system("outline_system")

	-- get breed category
	local breed_name
	if entry and entry.unit_data_ext then
		local breed = entry.unit_data_ext:breed()
		breed_name = mod.find_breed_category(breed)
	end

	if not breed_name then
		breed_name = "enemy"
	end

	local new_outline = "enemies_" .. breed_name

	-- Do not enable outline if breed isn't allowed...
	local enabled = mod:get("outline_" .. breed_name .. "_enable")
	if enabled == false then
		return
	end

	-- only update if changed
	if entry.outline_name ~= new_outline then
		-- remove old
		if entry.outline_name then
			outline_system:remove_outline(unit, entry.outline_name)
		end

		-- add new
		outline_system:add_outline(unit, new_outline)

		entry.outline_name = new_outline
	end
end

mod.disable_enemy_outlines = function(unit)
	if Unit.alive(unit) then
		local has_outline_system = Managers.state.extension:has_system("outline_system")

		if has_outline_system then
			local outline_system = Managers.state.extension:system("outline_system")
			-- Force outline visible
			outline_system:remove_outline(unit, "enemies_improved")
		end
	end
end

mod.pulse_enemy_outline = function(entry)
	local unit = entry.unit
	local fs = mod.frame_settings

	local update_interval = 0.05
	entry.t = (entry.t or 0) + fs.dt

	if entry.special_attack_imminent and entry.t > update_interval then
		entry.t = 0

		if not entry.alert_outline then
			local has_outline_system = Managers.state.extension:has_system("outline_system")

			if has_outline_system then
				local outline_system = Managers.state.extension:system("outline_system")
				-- Force outline visible
				outline_system:add_outline(unit, "enemies_improved_alert")
				entry.alert_outline = true
			end
		elseif entry.alert_outline and fs.enable.outline_specials_flash then
			local has_outline_system = Managers.state.extension:has_system("outline_system")

			if has_outline_system then
				local outline_system = Managers.state.extension:system("outline_system")
				-- Force outline visible
				outline_system:remove_outline(unit, "enemies_improved_alert")
				entry.alert_outline = false
			end
		end
	elseif not entry.special_attack_imminent and entry.alert_outline then
		local has_outline_system = Managers.state.extension:has_system("outline_system")

		if has_outline_system then
			local outline_system = Managers.state.extension:system("outline_system")
			-- Force outline visible
			outline_system:remove_outline(unit, "enemies_improved_alert")
			entry.alert_outline = false
		end
	end
end

-----------------------------------------------------------------------
-- Enemy scanning
-----------------------------------------------------------------------

mod.scan_enemies = function()
	local local_player = Managers_player:local_player(1)
	if not local_player then
		return
	end

	local player_unit = local_player.player_unit
	if not player_unit or not Unit_alive(player_unit) then
		return
	end

	local extension_manager = Managers_state.extension
	if not extension_manager then
		return
	end

	local broadphase_system = extension_manager:system("broadphase_system")
	local side_system = extension_manager:system("side_system")
	if not broadphase_system or not side_system then
		return
	end

	local side = side_system.side_by_unit[player_unit]
	if not side then
		return
	end

	local broadphase = broadphase_system.broadphase
	local from_pos = Unit.world_position(player_unit, 1)
	local enemy_side_names = side:relation_side_names("enemy")
	local range = mod.frame_settings.draw_distance or 50

	local results = mod._broadphase_results
	table_clear(results)

	local num_hits = broadphase.query(broadphase, from_pos, range, results, enemy_side_names)

	local cache = mod.enemy_cache

	-- mark unseen
	for _, data in pairs(cache) do
		data.seen = false
	end

	for i = 1, num_hits do
		local unit = results[i]

		if Unit_alive(unit) then
			local entry = cache[unit]

			if not entry then
				cache[unit] = {
					unit = unit,
					seen = true,

					dead = false,

					-- cache extensions
					health_ext = ScriptUnit_has_extension(unit, "health_system"),
					unit_data_ext = ScriptUnit_has_extension(unit, "unit_data_system"),
					behavior_ext = ScriptUnit_has_extension(unit, "behavior_system"),

					-- specialist tracking
					is_specialist = mod.is_specialist_unit(unit),
					is_horde = mod.is_horde(unit),
					special_attack_event = nil,
					special_attack_imminent = false,
					special_attack_timer = 0,

					-- outlines
					alert_outline = false,
					outline_name = nil,
				}
			else
				entry.seen = true
			end
		end
	end
end

-----------------------------------------------------------------------
-- Horde clustering helpers
-----------------------------------------------------------------------

-- Build clusters from a compact list of units
local function _build_horde_clusters(units, num_units)
	table_clear(_horde_clusters)
	table_clear(_horde_cluster_by_unit)

	local candidates = {}
	local c_count = 0

	for i = 1, num_units do
		local unit = units[i]
		if Unit_alive(unit) then
			local unit_data_extension = ScriptUnit_has_extension(unit, "unit_data_system")
			local breed = unit_data_extension and unit_data_extension:breed()
			local tags = breed and breed.tags

			if tags and (tags.horde or tags.roamer) then
				local pos = Unit.world_position(unit, 1)
				c_count = c_count + 1
				candidates[c_count] = {
					unit = unit,
					breed_name = breed.name,
					pos = pos,
				}
			end
		end
	end

	if c_count < HORDE_MIN_UNITS_FOR_CLUSTER then
		return
	end

	-- Simple clustering by (breed_name, distance)
	local used = {}

	for i = 1, c_count do
		if not used[i] then
			local seed = candidates[i]
			local breed_name = seed.breed_name
			local pos_i = seed.pos

			local units_in_cluster = { seed.unit }
			local sum_x, sum_y = pos_i.x, pos_i.y
			local base_z = pos_i.z + 1.8

			local count = 1

			for j = i + 1, c_count do
				if not used[j] then
					local cand = candidates[j]
					if cand.breed_name == breed_name then
						local pos_j = cand.pos
						local dx = pos_j.x - pos_i.x
						local dy = pos_j.y - pos_i.y
						local dz = pos_j.z - pos_i.z
						local dist_sq = dx * dx + dy * dy + dz * dz

						if dist_sq ~= dist_sq or dist_sq == math.huge or dist_sq == -math.huge then
							-- NaN or inf, skip this candidate
						else
							if dist_sq <= HORDE_CLUSTER_RADIUS_SQ then
								used[j] = true
								units_in_cluster[#units_in_cluster + 1] = cand.unit
								sum_x = sum_x + pos_j.x
								sum_y = sum_y + pos_j.y
								count = count + 1
							end
						end
					end
				end
			end

			if count >= HORDE_MIN_UNITS_FOR_CLUSTER then
				local inv = 1 / count
				local center = {
					x = sum_x * inv,
					y = sum_y * inv,
					z = base_z,
				}

				-- Sum health across cluster members
				local total_current = 0
				local total_max = 0

				for _, u in ipairs(units_in_cluster) do
					local he = ScriptUnit_has_extension(u, "health_system")
					if he then
						total_current = total_current + (he:current_health() or 0)
						total_max = total_max + (he:max_health() or 0)
					end
				end

				local idx = #_horde_clusters + 1
				local rep_unit = units_in_cluster[1]

				_horde_clusters[idx] = {
					breed_name = breed_name,
					units = units_in_cluster,
					center = center,
					total_current = total_current,
					total_max = total_max,
					rep_unit = rep_unit,
				}

				for _, u in ipairs(units_in_cluster) do
					_horde_cluster_by_unit[u] = idx
				end
			end
		end
	end
end

mod.get_horde_cluster_for_unit = function(unit)
	local idx = _horde_cluster_by_unit[unit]
	return idx and _horde_clusters[idx] or nil
end

-----------------------------------------------------------------------
-- Enemy markers
-----------------------------------------------------------------------

mod.get_time = function()
	local tm = Managers.time
	if tm then
		return tm:time("gameplay")
	end

	return 0
end

mod.ts = function()
	return string.format("[%.3f]", mod.get_time())
end

-- better than audio cues - but only works on local games due to event_names not being known locally :(
mod.special_attack_animations = {

	----------------------------------------------------------------
	-- CHAOS HOUND
	----------------------------------------------------------------
	chaos_hound = {
		attack_leap = {
			attack = "leap_attack",
			damage_time = 1.05,
			duration = 2.8,
		},
		attack_pounce = {
			attack = "pounce_attack",
			damage_time = 1.25,
			duration = 3.1,
		},
		attack_leap_start = {
			attack = "attack_leap_start",
			damage_time = 1.05,
			duration = 2.8,
		},
		attack_leap_short = {
			attack = "attack_leap_short",
			damage_time = 1.05,
			duration = 2.8,
		},
	},

	----------------------------------------------------------------
	-- CHAOS MUTANT
	----------------------------------------------------------------
	chaos_mutant = {
		attack_charge = {
			attack = "charge_attack",
			damage_time = 1.35,
			duration = 3.4,
		},

		attack_grab = {
			attack = "grab_attack",
			damage_time = 1.45,
			duration = 3.2,
		},

		attack_throw = {
			attack = "throw_attack",
			damage_time = 1.9,
			duration = 3.6,
		},
	},

	----------------------------------------------------------------
	-- CHAOS TRAPPER
	----------------------------------------------------------------
	chaos_trapper = {
		attack_netgun = {
			attack = "netgun_attack",
			damage_time = 0.95,
			duration = 2.3,
		},
	},

	----------------------------------------------------------------
	-- RENEGADE SNIPER
	----------------------------------------------------------------
	renegade_sniper = {
		attack_shoot = {
			attack = "shoot",
			damage_time = 0.82,
			duration = 1.9,
		},
	},

	----------------------------------------------------------------
	-- CHAOS GRENADIER
	----------------------------------------------------------------
	chaos_grenadier = {
		attack_throw_grenade = {
			attack = "grenade_throw",
			damage_time = 0.9,
			duration = 2.2,
		},
	},

	----------------------------------------------------------------
	-- POXBURSTER
	----------------------------------------------------------------
	chaos_poxwalker_bomber = {
		attack_explode = {
			attack = "suicide_attack",
			damage_time = 1.5,
			duration = 2.8,
		},
	},

	----------------------------------------------------------------
	-- MAULER
	----------------------------------------------------------------
	chaos_mauler = {
		attack_01 = {
			attack = "melee_combo",
			damage_time = 0.92,
			duration = 2.4,
		},

		attack_02 = {
			attack = "melee_combo",
			damage_time = 1.1,
			duration = 2.6,
		},
	},

	----------------------------------------------------------------
	-- RAGER
	----------------------------------------------------------------
	chaos_rager = {
		attack_01 = {
			attack = "frenzy_combo",
			damage_time = 0.4,
			duration = 1.2,
		},

		attack_02 = {
			attack = "frenzy_combo",
			damage_time = 0.55,
			duration = 1.3,
		},

		attack_03 = {
			attack = "frenzy_combo",
			damage_time = 0.7,
			duration = 1.5,
		},
	},

	----------------------------------------------------------------
	-- CHAOS OGRYN EXECUTOR (CRUSHER)
	----------------------------------------------------------------
	chaos_ogryn_executor = {

		attack_01 = {
			attack = "melee_attack_cleave",
			damage_time = 1.471,
			duration = 3.103,
		},

		attack_02 = {
			attack = "melee_attack_cleave",
			damage_time = 1.310,
			duration = 2.873,
		},

		attack_07 = {
			attack = "melee_attack_cleave",
			damage_time = 1.655,
			duration = 3.678,
		},

		attack_08 = {
			attack = "melee_attack_cleave",
			damage_time = 1.586,
			duration = 3.310,
		},

		attack_move_01 = {
			attack = "moving_melee_attack_cleave",
			damage_time = 1.531,
			duration = 2.840,
		},
	},

	----------------------------------------------------------------
	-- CHAOS OGRYN BULWARK
	----------------------------------------------------------------
	chaos_ogryn_bulwark = {

		attack_push = {
			attack = "melee_attack_push",
			damage_time = 0.93,
			duration = 2,
		},

		attack_01 = {
			attack = "melee_attack_sweep",
			damage_time = 1.2,
			duration = 3,
		},
	},

	----------------------------------------------------------------
	-- CHAOS SPAWN
	----------------------------------------------------------------
	chaos_spawn = {

		attack_01 = {
			attack = "melee_combo",
			damage_time = 0.84,
			duration = 2.4,
		},

		attack_02 = {
			attack = "melee_combo",
			damage_time = 1.02,
			duration = 2.7,
		},

		attack_grab = {
			attack = "grab_attack",
			damage_time = 1.4,
			duration = 3.5,
		},
	},

	----------------------------------------------------------------
	-- PLAGUE OGRYN
	----------------------------------------------------------------
	chaos_plague_ogryn = {

		attack_01 = {
			attack = "combo_attack",
			damage_time = 0.96,
			duration = 2.73,
		},

		attack_02 = {
			attack = "combo_attack",
			damage_time = 1.1,
			duration = 2.88,
		},

		attack_03 = {
			attack = "combo_attack",
			damage_time = 1.24,
			duration = 3.01,
		},

		attack_slam = {
			attack = "slam_attack",
			damage_time = 1.5,
			duration = 3.5,
		},

		attack_charge = {
			attack = "charge_attack",
			damage_time = 2.0,
			duration = 4.2,
		},
	},

	----------------------------------------------------------------
	-- BEAST OF NURGLE
	----------------------------------------------------------------
	chaos_beast_of_nurgle = {

		attack_tongue = {
			attack = "tongue_grab",
			damage_time = 1.8,
			duration = 3.6,
		},

		attack_eat = {
			attack = "eat_attack",
			damage_time = 2.2,
			duration = 4,
		},
	},
}

-- local games only. rpc_minion_anim_event is the networked version, but only provides event_id, which I cant find out how to get event_name from
--[[mod:hook(Unit, "animation_event", function(func, unit, event, ...)
	local result = func(unit, event, ...)

	if not unit or not Unit_alive(unit) then
		return result
	end

	local entry = mod.enemy_cache[unit]
	if not entry then
		return result
	end

	-------------------------------------------------
	-- Get breed
	-------------------------------------------------
	local breed_name

	if entry.unit_data_ext then
		local breed = entry.unit_data_ext:breed()
		breed_name = breed and breed.name
	end

	if not breed_name then
		return result
	end

	-------------------------------------------------
	-- Lookup attack event
	-------------------------------------------------
	local breed_table = mod.special_attack_animations[breed_name]

	if not breed_table then
		return result
	end

	local attack_data = breed_table[event]

	if attack_data then
		if event then
			entry.special_attack_event = event
			entry.special_attack_imminent = true

			local now = mod.get_time()

			if attack_data.damage_time then
				entry.special_attack_timer = now + 1.5
			else
				entry.special_attack_timer = now + 1.5
			end

		end
	end

	return result
end)]]

mod.special_attack_events = {
	-- Trapper / Netgunner
	["wwise/events/minions/play_weapon_netgunner_wind_up"] = true,
	--["wwise/events/minions/play_netgunner_run_foley_special"] = true,

	-- Sniper
	["wwise/events/weapon/play_special_sniper_flash"] = true,
	["wwise/events/weapon/play_combat_weapon_las_sniper"] = true,
	["wwise/events/weapon/play_weapon_longlas_minion"] = true,

	-- Mutant Charger
	["wwise/events/minions/play_enemy_mutant_charger"] = true,
	["wwise/events/minions/play_minion_special_mutant_charger_spawn"] = true,

	-- Chaos Hound / leap
	["wwise/events/minions/play_enemy_chaos_hound_vce_leap"] = true,
	["wwise/events/minions/play_enemy_chaos_hound"] = true,
	["wwise/events/minions/play_chaos_hound_armoured_vce_leap"] = true,

	-- Poxwalker Bomber
	["wwise/events/minions/play_minion_special_poxwalker_bomber_spawn"] = true,
	["wwise/events/minions/play_explosion_bomber"] = true,
	["wwise/events/minions/play_minion_poxwalker_bomber"] = true,
	["wwise/events/minions/play_enemy_combat_poxwalker_bomber"] = true,
	["wwise/events/minions/play_minion_poxwalker_bomber_footstep_boots_heavy"] = true,

	-- Plague Ogryn Charge
	["wwise/events/minions/play_enemy_plague_ogryn_vce_charge"] = true,

	-- Chaos Ogryn special attack vocal (heavy specials)
	["wwise/events/minions/play_enemy_chaos_ogryn_armoured_executor_a__special_attack_vce"] = true,

	-- renegade executor
	["wwise/events/minions/play_enemy_traitor_executor__special_attack_vce"] = true,

	-- General rares / specials
	["wwise/events/minions/play_traitor_guard_grenadier"] = true,
	["wwise/events/minions/play_enemy_daemonhost"] = true,
	["wwise/events/minions/play_enemy_traitor_berzerker"] = true,
}

local function extract_locals(level_base)
	local level = level_base
	local res = {}
	local return_value = nil

	while debug.getinfo(level) ~= nil do
		local v = 1

		while true do
			local name, value = debug.getlocal(level, v)

			if not name then
				break
			end

			res[name] = value

			-- check for specifics...
			-- Check for exact unit (Works for grabbing sniper unit from the weapon sound)
			if value and type(value) == "userdata" and name and name == "unit" then
				return_value = value
			end
			v = v + 1
		end

		level = level + 1
	end

	dbg_locals = res

	return return_value
end

mod.handle_special_attacks = function(event_name, source_unit)
	if mod.special_attack_events[event_name] then
		local unit = nil

		-- Try to get uni from sourceunit
		if type(source_unit) == "userdata" and Unit.alive(source_unit) then
			unit = source_unit
		else
			local flow_unit = Application.flow_callback_context_unit()
			if flow_unit and type(flow_unit) == "userdata" and Unit.alive(flow_unit) then
				unit = flow_unit
			end
		end

		-- If not, try to get from local debugs
		if
			event_name
				== ("wwise/events/minions/play_weapon_netgunner_wind_up" or "wwise/events/weapon/play_special_sniper_flash")
			and not unit
		then
			local name, value = debug.getlocal(8, 1)
			unit = value._unit
		end

		-- if not, try to get from all locals
		if not unit then
			unit = extract_locals(1)
		end

		extract_locals(1)

		--mod:echo(string.format("%s [SOUND ATTACK DETECTED] %s -> %s", mod.ts(), unit, event_name))

		if unit and Unit_alive(unit) then
			entry = mod.enemy_cache[unit]

			if entry then
				entry.special_attack_event = event_name
				entry.special_attack_imminent = true

				local now = mod.get_time()

				entry.special_attack_timer = now + 1.5
			end
		end
	end
end

mod:hook_safe(WwiseWorld, "trigger_resource_event", function(wwise_world, event_name, source)
	mod.handle_special_attacks(event_name, source)
end)

mod:hook_safe(
	WwiseWorld,
	"trigger_resource_external_event",
	function(_wwise_world, event_name, source, path, format, source_id)
		mod.handle_special_attacks(event_name, source)
	end
)

function string.starts(String, Start)
	return string.sub(String, 1, string.len(Start)) == Start
end

mod.remove_dead = function()
	local units_to_remove = {}

	dbg_mod = mod

	-- Go through each marker type and clear caches.
	local function iterate_types_removal(unit)
		local found_unit_marker = mod.enemy_markers[unit]
			or mod.enemy_healthbars[unit]
			or mod.enemy_debuffs[unit]
			or mod.enemy_utility_debuffs[unit]
			or nil

		-- try to find unit match from marker list..
		for _, markers in pairs(mod.markers) do
			for i = 1, #markers do
				local marker = markers[i]
				if marker and marker.unit == unit then
					if _ == "enemy_markers" then
						Managers.event:trigger("remove_world_marker", marker.id)
						found_unit_marker = marker.id
					elseif _ == "enemy_healthbars" then
						Managers.event:trigger("remove_world_marker", marker.id)
						found_unit_marker = marker.id
					elseif _ == "enemy_debuff" then
						Managers.event:trigger("remove_world_marker", marker.id)
						found_unit_marker = marker.id
					elseif _ == "enemy_utility_debuff" then
						Managers.event:trigger("remove_world_marker", marker.id)
						found_unit_marker = marker.id
					end
				end
			end
		end

		if found_unit_marker then
			table.insert(units_to_remove, unit)
		end
	end

	-- Detect if dead
	for unit, data in pairs(mod.enemy_cache) do
		if not HEALTH_ALIVE[unit] or not Unit.alive(unit) or string.starts(tostring(unit), "[Unit (deleted)") then
			iterate_types_removal(unit)
		else
			local health_extension = ScriptUnit.has_extension(unit, "health_system")
			if health_extension then
				local health_percent = health_extension:current_health_percent()
				if health_percent <= 0 then
					iterate_types_removal(unit)
				end
			end
		end
	end

	-- Remove dead enemies from the cache after processing
	for _, unit in ipairs(units_to_remove) do
		mod.marked_dead[unit] = true
		mod.enemy_healthbars[unit] = nil
		mod.enemy_debuffs[unit] = nil
		mod.enemy_utility_debuffs[unit] = nil
		mod.enemy_markers[unit] = nil
		mod.enemy_cache[unit] = nil
	end
end

mod.is_horde = function(unit)
	if Unit.alive(unit) then
		local tags = mod.get_breed_tags(unit)
		local is_horde = tags and (tags.horde or tags.roamer) or false

		return is_horde or false
	else
		return false
	end
end

mod.update_enemy_outlines = function(entry)
	local unit = entry.unit

	local fs = mod.frame_settings
	if not (fs.enable and fs.enable.outlines) then
		return
	end

	if (fs.enable.outlines_horde and entry.is_horde) or (fs.enable.outlines and not entry.is_horde) then
		mod.enable_enemy_outlines(unit, entry)
	end
end

-------------------------------------------------------------------
-- Special attack detection
-------------------------------------------------------------------
mod.update_special_attack_detection = function(entry)
	local unit = entry.unit
	local ui_manager = Managers_ui
	local hud = ui_manager and ui_manager:get_hud()
	local world_markers = hud and hud:element("HudElementWorldMarkers")
	local markers_by_id = world_markers and world_markers._markers_by_id

	-- remove special_attack_imminent if over the timer...
	if entry.is_specialist and entry.special_attack_imminent then
		local now = mod.get_time()

		if entry.special_attack_timer and now >= entry.special_attack_timer then
			entry.special_attack_imminent = false
			entry.special_attack_timer = nil
		end

		-- update marker status...
		for _, markers in pairs(mod.markers) do
			for i = 1, #markers do
				local marker = markers[i]
				if marker.unit == unit then
					if _ == "enemy_markers" then
						if entry and marker then
							marker.special_attack_imminent = entry.special_attack_imminent
							marker.is_specialist = entry.is_specialist
						end
					end
				end
			end
		end
	end
end

-------------------------------------------------------------------
-- Enemy Markers
-------------------------------------------------------------------
mod.update_enemy_markers = function(entry, t)
	local unit = entry.unit

	local fs = mod.frame_settings
	if not (fs.enable and fs.enable.markers) then
		return
	end

	-- skip horde markers if not enabled
	if entry.is_horde and not fs.enable.markers_horde then
		return
	end

	-- add enemy markers if doesn't already exist
	if not mod.enemy_markers[unit] and not mod.marked_dead[unit] then
		Managers.event:trigger("add_world_marker_unit", EnemyMarkersTemplate.name, unit, function(marker_id)
			mod.enemy_markers[unit] = marker_id
		end)
	end
end

-----------------------------------------------------------------------
-- Enemy healthbars
-----------------------------------------------------------------------

mod.update_enemy_healthbars = function(entry)
	local unit = entry.unit

	local fs = mod.frame_settings
	if not (fs.enable and fs.enable.healthbar) then
		return
	end

	-- skip horde if not enabled
	if (mod.is_horde(unit) and not fs.enable.hb_horde) and (mod.is_horde(unit) and not fs.enable.horde_clusters) then
		return
	end

	if not mod.enemy_healthbars[unit] and not mod.marked_dead[unit] then
		local cluster = fs.enable.horde_clusters and mod.get_horde_cluster_for_unit(unit) or nil

		-- If this unit is part of a horde cluster, only give a healthbar to the representative
		if cluster then
			if cluster.rep_unit ~= unit then
				goto continue_healthbar_loop
			end
		end

		Managers_event:trigger("add_world_marker_unit", "enemy_healthbar", unit, function(marker_id)
			mod.enemy_healthbars[unit] = marker_id
		end)
		::continue_healthbar_loop::
	end
end

-----------------------------------------------------------------------
-- Enemy debuffs
-----------------------------------------------------------------------

mod.update_enemy_debuffs = function(entry)
	local unit = entry.unit

	local fs = mod.frame_settings
	if not (fs.enable and fs.enable.debuff) then
		return
	end

	-- only add debuffs for living enemies that are not dead and removed
	if not mod.enemy_debuffs[unit] and not mod.marked_dead[unit] then
		Managers_event:trigger("add_world_marker_unit", "enemy_debuff", unit, function(debuff_id)
			mod.enemy_debuffs[unit] = debuff_id
		end)
	end
end

mod.update_enemy_utility_debuffs = function(entry)
	local unit = entry.unit

	local fs = mod.frame_settings
	if not (fs.enable and fs.enable.debuff) then
		return
	end

	if not mod.enemy_utility_debuffs[unit] and not mod.marked_dead[unit] then
		Managers_event:trigger("add_world_marker_unit", EnemyUtilityDebuffTemplate.name, unit, function(marker_id)
			mod.enemy_utility_debuffs[unit] = marker_id
		end)
	end
end

-----------------------------------------------------------------------
-- Cache clearing
-----------------------------------------------------------------------

mod.clear_caches = function()
	table_clear(mod.enemy_markers)
	table_clear(mod.enemy_healthbars)
	table_clear(mod.enemy_debuffs)
	table_clear(mod.enemy_cache)
	table_clear(mod.marked_dead)
	table_clear(mod.enemy_utility_debuffs)

	table_clear(_enemy_units_temp)
	table_clear(_horde_clusters)
	table_clear(_horde_cluster_by_unit)
end

-----------------------------------------------------------------------
-- Marker Distance
-----------------------------------------------------------------------

mod.apply_marker_fade = function()
	local ui_manager = Managers_ui
	local hud = ui_manager and ui_manager:get_hud()
	local world_markers = hud and hud:element("HudElementWorldMarkers")

	if not world_markers then
		return
	end

	local markers_by_id = world_markers._markers_by_id
	if not markers_by_id then
		return
	end

	local player = Managers_player:local_player(1)
	if not player then
		return
	end

	local player_unit = player.player_unit
	if not player_unit or not Unit_alive(player_unit) then
		return
	end

	local player_pos = Unit.world_position(player_unit, 1)

	-- Optional stacking tracking
	local screen_positions = {}

	for marker_id, marker in pairs(markers_by_id) do
		if marker and marker.unit and Unit_alive(marker.unit) then
			if
				marker.template
				and (
					marker.template.name == EnemyMarkersTemplate.name
					or marker.template.name == EnemyHealthbarTemplate.name
					or marker.template.name == EnemyDebuffTemplate.name
					or marker.template.name == EnemyUtilityDebuffTemplate.name
				)
			then
				--------------------------------------------------
				-- DISTANCE FADE
				--------------------------------------------------
				local unit_pos = Unit.world_position(marker.unit, 1)

				local dx = unit_pos.x - player_pos.x
				local dy = unit_pos.y - player_pos.y
				local dz = unit_pos.z - player_pos.z

				local dist = math.sqrt(dx * dx + dy * dy + dz * dz)

				local fade = 1

				if dist > DIST_FADE_START then
					local t = math.clamp((dist - DIST_FADE_START) / (DIST_FADE_END - DIST_FADE_START), 0, 1)
					fade = 1 - t
				end

				fade = math.max(fade, MIN_ALPHA)

				marker.alpha_multiplier = math.clamp(fade, MIN_ALPHA, 1)

				local final_alpha = math.clamp(fade, MIN_ALPHA, 1)

				local widget = marker.widget

				if widget and widget.style then
					for _, style in pairs(widget.style) do
						local base_alpha = 255

						if style.default_alpha then
							base_alpha = style.default_alpha
						end
						if style.color then
							style.color[1] = base_alpha * final_alpha
						end
						if style.text_color then
							style.text_color[1] = base_alpha * final_alpha
						end
					end
				end
			end
		end
	end
end

mod.update_horde_clusters = function(temp, to_process)
	local fs = mod.frame_settings

	if fs.enable.horde_clusters then
		local CLUSTER_UPDATE_INTERVAL = 0.05
		_cluster_t = (_cluster_t or 0) + fs.dt

		if _cluster_t > CLUSTER_UPDATE_INTERVAL then
			_cluster_t = 0
			_build_horde_clusters(temp, to_process)
		end
	else
		table_clear(_horde_clusters)
		table_clear(_horde_cluster_by_unit)
	end
end
-----------------------------------------------------------------------
-- Main update orchestration
-----------------------------------------------------------------------

mod.update_enemies = function(dt, t)
	build_frame_settings(mod, dt or 0)
	local fs = mod.frame_settings
	local enable = fs.enable

	if not (enable.markers or enable.healthbar or enable.debuff) then
		return
	end

	mod.scan_enemies()

	if not next(mod.enemy_cache) then
		return
	end

	local temp = _enemy_units_temp
	local count = 0

	for unit, _ in pairs(mod.enemy_cache) do
		count = count + 1
		temp[count] = unit
	end

	if count == 0 then
		return
	end

	-- rotate index so we don't always process the same subset first
	_last_enemy_index = (_last_enemy_index % count) + 1

	local to_process = math_min(count, MAX_ENEMIES_PER_FRAME)

	-- select a rotating window of units into first to_process entries
	if to_process < count then
		local idx = _last_enemy_index
		for i = 1, to_process do
			if idx > count then
				idx = 1
			end
			-- swap into front
			temp[i], temp[idx] = temp[idx], temp[i]
			idx = idx + 1
		end
	end

	-- trim any extra entries in temp
	for i = to_process + 1, count do
		temp[i] = nil
	end

	-- update horde clusters...
	if enable.healthbar and enable.horde_clusters then
		mod.update_horde_clusters(temp, to_process)
	end

	-- go through enemy_cache and perform updates...
	for i = 1, to_process do
		local unit = temp[i]
		if mod.enemy_cache[unit] then
			local entry = mod.enemy_cache[unit]

			if enable.markers then
				mod.update_enemy_markers(entry, t)
			end

			if enable.outlines then
				mod.update_enemy_outlines(entry)
			end

			if enable.healthbar then
				mod.update_enemy_healthbars(entry)
			end

			if enable.debuff then
				mod.update_enemy_debuffs(entry)
				mod.update_enemy_utility_debuffs(entry)
			end

			mod.update_special_attack_detection(entry)

			if enable.outline_specials then
				mod.pulse_enemy_outline(entry)
			end
		end
	end

	mod.remove_dead()
end

-----------------------------------------------------------------------
-- Specialist detection
-----------------------------------------------------------------------

local SPECIALIST_TAGS = {
	special = true,
	disabler = true,
	monster = true,
	elite = true,
}

mod.is_specialist_unit = function(unit)
	local tags = mod.get_breed_tags(unit)

	if not tags then
		return false
	end

	for tag, enabled in pairs(SPECIALIST_TAGS) do
		if enabled and tags[tag] then
			return true
		end
	end

	return false
end

-- OUTLINES
local function apply_enemy_outlines(settings)
	for _, entry in ipairs(mod.breed_types) do
		local breed = entry.value

		-- skip placeholder
		if breed ~= "SELECTANENEMYTYPE" then
			local enabled = mod:get("outline_" .. breed .. "_enable")
			if enabled == nil then
				enabled = true
			end

			if enabled then
				local r = (mod:get("outline_" .. breed .. "_colour_R") or 255) / 255
				local g = (mod:get("outline_" .. breed .. "_colour_G") or 100) / 255
				local b = (mod:get("outline_" .. breed .. "_colour_B") or 0) / 255

				settings.MinionOutlineExtension["enemies_" .. breed] = {
					priority = 2,
					material_layers = {
						"minion_outline_combat_ability",
						"minion_outline_combat_ability_reversed_depth",
					},
					color = { r, g, b },
					visibility_check = function()
						return true
					end,
				}
			else
				-- remove if disabled
				settings.MinionOutlineExtension["enemies_" .. breed] = nil
			end
		end
	end

	-- SPECIAL ATTACK OUTLINE
	local sr = (mod:get("outline_specials_colour_R") or 255) / 255
	local sg = (mod:get("outline_specials_colour_G") or 0) / 255
	local sb = (mod:get("outline_specials_colour_B") or 0) / 255

	settings.MinionOutlineExtension.enemies_improved_alert = {
		priority = 1,
		material_layers = {
			"minion_outline_combat_ability",
			"minion_outline_combat_ability_reversed_depth",
		},
		color = { sr, sg, sb },
		visibility_check = function()
			return true
		end,
	}
end

mod:hook_require("scripts/settings/outline/outline_settings", function(settings)
	apply_enemy_outlines(settings)
end)

-----------------------------------------------------------------------
-- Settings changed
-----------------------------------------------------------------------

-- list of settings to monitor PER enemy type, needs to be updated if more types are added...
-- REQUIRES "_type_" AS THAT IS WHERE THE SPECIFIC ENEMY GROUP NAME IS PLACED...
local enemy_type_settings = {
	["outline_type_enable"] = true,
	["outline_type_colour_R"] = 150,
	["outline_type_colour_G"] = 75,
	["outline_type_colour_B"] = 0,

	["healthbar_type_enable"] = true,
	["healthbar_type_colour_R"] = 255,
	["healthbar_type_colour_G"] = 0,
	["healthbar_type_colour_B"] = 0,
}

mod.init_healthbar_colour_defaults = function()
	for breed, color in pairs(mod.BREED_COLORS) do
		local r = color[2]
		local g = color[3]
		local b = color[4]

		-- only set if not already saved
		if mod:get("healthbar_" .. breed .. "_colour_R") == nil then
			mod:set("healthbar_" .. breed .. "_colour_R", r)
			mod:set("healthbar_" .. breed .. "_colour_G", g)
			mod:set("healthbar_" .. breed .. "_colour_B", b)
		end
	end
end

mod.update_breed_colors = function()
	for breed, default_color in pairs(mod.BREED_COLORS) do
		local r = mod:get("healthbar_" .. breed .. "_colour_R")
		local g = mod:get("healthbar_" .. breed .. "_colour_G")
		local b = mod:get("healthbar_" .. breed .. "_colour_B")
		local a = default_color[1] or 255

		if r and g and b then
			mod.BREED_COLORS[breed] = { a, r, g, b }
		end
	end
end

mod.on_setting_changed = function(setting_id)
	-- Set the enemy type widgets when a group is selected
	for setting_name, default_value in pairs(enemy_type_settings) do
		local selected_enemy_type = mod:get("enemy_group")
		if not selected_enemy_type then
			return
		end

		local type_value = mod:get(setting_name)
		local enemy_type = setting_name:gsub("_type_", "_" .. selected_enemy_type .. "_")
		local enemy_type_value = mod:get(enemy_type)

		if enemy_type_value == nil then
			enemy_type_value = default_value
		end

		-- STORE VALUES WHEN CHANGED
		if setting_id == setting_name then
			if enemy_type_value ~= type_value then
				mod:error("set " .. tostring(enemy_type) .. " to " .. tostring(type_value))
				mod:set(enemy_type, type_value)
			end
		end

		-- SET UI VALUES WHEN DROPDOWN IS SELECTED...
		if setting_id == "enemy_group" then
			if type_value ~= enemy_type_value then
				mod:error("LOADED VALUES: " .. tostring(setting_name) .. " to " .. tostring(enemy_type_value))
				mod:set(setting_name, enemy_type_value)
			end
		end
	end

	-- rebuild outlines
	local outline_settings = require("scripts/settings/outline/outline_settings")
	apply_enemy_outlines(outline_settings)

	-- update breed colors from settings
	mod.update_breed_colors()

	-- clear all caches to reload data with new values
	mod.clear_caches()
end

mod.get_breed_tags = function(unit)
	if not HEALTH_ALIVE[unit] then
		return nil
	end

	local unit_data_extension = ScriptUnit_has_extension(unit, "unit_data_system")

	if not unit_data_extension then
		return nil
	end

	local breed = unit_data_extension:breed()

	if breed then
		return breed.tags
	end

	return nil
end

-- Tags are ordered from priority (Top to bottom)
-- so first match is what will be returned.
-- breed points to the breed tags list, get from mod.get_breed_tags(unit)
mod.find_breed_category = function(breed)
	if breed then
		local tags = breed.tags or {}
		if tags.horde or tags.roamer then
			return "horde"
		elseif tags.monster then
			return "monster"
		elseif tags.captain then
			return "captain"
		elseif tags.disabler then
			return "disabler"
		elseif tags.witch then
			return "witch"
		elseif tags.special and tags.sniper then
			return "sniper"
		elseif tags.elite and tags.far or tags.special and tags.far then
			return "far"
		elseif tags.elite then
			return "elite"
		elseif tags.special then
			return "special"
		else
			return "enemy"
		end
	end
end
